import { v as Button } from "../ssr.js";
import { router, useForm } from "@inertiajs/react";
import { jsx, jsxs } from "react/jsx-runtime";
import { Upload } from "lucide-react";
//#region resources/js/components/admin/content-image.tsx
/** Replace or reset an editorial image (home hero, story). */
function ContentImage({ slot, image, isCustom }) {
	const form = useForm({ image: null });
	return /* @__PURE__ */ jsxs("div", {
		className: "flex flex-col gap-4 sm:flex-row",
		children: [/* @__PURE__ */ jsx("div", {
			className: "arch aspect-[3/4] w-36 shrink-0 bg-sand",
			children: /* @__PURE__ */ jsx("img", {
				src: image.src,
				alt: "",
				className: "h-full w-full object-cover"
			})
		}), /* @__PURE__ */ jsxs("form", {
			className: "flex-1 space-y-3",
			onSubmit: (e) => {
				e.preventDefault();
				form.post(`/admin/content/images/${slot}`, {
					forceFormData: true,
					preserveScroll: true,
					onSuccess: () => form.reset()
				});
			},
			children: [
				/* @__PURE__ */ jsx("p", {
					className: "text-sm text-stone",
					children: "Portrait photographs work best (3:4), at least 800 px wide. JPG, PNG or WebP."
				}),
				/* @__PURE__ */ jsxs("label", {
					className: "flex cursor-pointer items-center gap-2 rounded-md border border-dashed border-stone/40 px-4 py-3 text-sm hover:border-ink",
					children: [
						/* @__PURE__ */ jsx(Upload, {
							className: "size-4 text-stone",
							"aria-hidden": "true"
						}),
						form.data.image ? form.data.image.name : "Choose a new photograph",
						/* @__PURE__ */ jsx("input", {
							type: "file",
							accept: "image/jpeg,image/png,image/webp",
							className: "sr-only",
							onChange: (e) => form.setData("image", e.target.files?.[0] ?? null)
						})
					]
				}),
				form.errors.image && /* @__PURE__ */ jsx("p", {
					className: "text-sm text-clay",
					role: "alert",
					children: form.errors.image
				}),
				/* @__PURE__ */ jsxs("div", {
					className: "flex gap-2",
					children: [/* @__PURE__ */ jsx(Button, {
						type: "submit",
						size: "sm",
						loading: form.processing,
						disabled: !form.data.image,
						children: "Upload"
					}), isCustom && /* @__PURE__ */ jsx(Button, {
						type: "button",
						size: "sm",
						variant: "ghost",
						onClick: () => router.delete(`/admin/content/images/${slot}`, { preserveScroll: true }),
						children: "Use the original photograph"
					})]
				})
			]
		})]
	});
}
//#endregion
export { ContentImage as t };
