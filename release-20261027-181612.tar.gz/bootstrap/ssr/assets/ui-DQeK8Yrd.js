import { t as cn } from "./utils-BqvNF826.js";
import { t as Badge } from "./badge-ChM6xC7L.js";
import { Head, Link } from "@inertiajs/react";
import { Fragment, jsx, jsxs } from "react/jsx-runtime";
//#region resources/js/components/admin/ui.tsx
function PageHeader({ title, description, actions, back }) {
	return /* @__PURE__ */ jsxs("div", {
		className: "mb-8",
		children: [
			/* @__PURE__ */ jsx(Head, { title: `${title} — Admin` }),
			back && /* @__PURE__ */ jsxs(Link, {
				href: back.href,
				className: "mb-3 inline-block text-sm text-stone hover:text-ink",
				children: ["← ", back.label]
			}),
			/* @__PURE__ */ jsxs("div", {
				className: "flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between",
				children: [/* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx("h1", {
					className: "font-display text-3xl sm:text-4xl",
					children: title
				}), description && /* @__PURE__ */ jsx("div", {
					className: "mt-2 max-w-2xl text-stone",
					children: description
				})] }), actions && /* @__PURE__ */ jsx("div", {
					className: "flex flex-wrap gap-2",
					children: actions
				})]
			})
		]
	});
}
function Panel({ title, description, actions, children, className, padded = true }) {
	return /* @__PURE__ */ jsxs("section", {
		className: cn("rounded-lg border border-line bg-white", className),
		children: [(title || actions) && /* @__PURE__ */ jsxs("header", {
			className: "flex flex-wrap items-start justify-between gap-3 border-b border-line px-5 py-4",
			children: [/* @__PURE__ */ jsxs("div", { children: [title && /* @__PURE__ */ jsx("h2", {
				className: "font-medium",
				children: title
			}), description && /* @__PURE__ */ jsx("p", {
				className: "mt-0.5 text-sm text-stone",
				children: description
			})] }), actions]
		}), /* @__PURE__ */ jsx("div", {
			className: cn(padded && "p-5"),
			children
		})]
	});
}
/** Horizontally scrollable table on small screens. */
function Table({ children, className }) {
	return /* @__PURE__ */ jsx("div", {
		className: "overflow-x-auto",
		children: /* @__PURE__ */ jsx("table", {
			className: cn("w-full text-left text-sm", className),
			children
		})
	});
}
var th = "px-4 py-3 text-xs font-medium text-stone whitespace-nowrap border-b border-line bg-panel/60";
var td = "px-4 py-3 border-b border-line align-middle";
function EmptyState({ title, children }) {
	return /* @__PURE__ */ jsxs("div", {
		className: "px-6 py-14 text-center",
		children: [/* @__PURE__ */ jsx("p", {
			className: "font-medium",
			children: title
		}), children && /* @__PURE__ */ jsx("div", {
			className: "mt-2 text-sm text-stone",
			children
		})]
	});
}
var ORDER_TONES = {
	PENDING_CONFIRMATION: "warning",
	CONFIRMED: "info",
	PROCESSING: "info",
	READY_TO_SHIP: "info",
	SHIPPED: "dark",
	DELIVERED: "success",
	CANCELLED: "neutral",
	FAILED_DELIVERY: "danger",
	RETURNED: "danger"
};
var PAYMENT_TONES = {
	pending: "neutral",
	collected: "success",
	not_collected: "warning",
	refunded: "danger"
};
function OrderStatusBadge({ status, label }) {
	return /* @__PURE__ */ jsx(Badge, {
		tone: ORDER_TONES[status] ?? "neutral",
		children: label
	});
}
function PaymentBadge({ status, label }) {
	return /* @__PURE__ */ jsx(Badge, {
		tone: PAYMENT_TONES[status] ?? "neutral",
		children: label
	});
}
function ProductStatusBadge({ status, label }) {
	return /* @__PURE__ */ jsx(Badge, {
		tone: status === "published" ? "success" : status === "draft" ? "warning" : "neutral",
		children: label
	});
}
function Pagination({ page }) {
	if (page.last_page <= 1) return null;
	return /* @__PURE__ */ jsxs("nav", {
		"aria-label": "Pages",
		className: "flex flex-wrap items-center justify-between gap-3 px-4 py-3 text-sm",
		children: [/* @__PURE__ */ jsxs("p", {
			className: "text-stone",
			children: [
				page.from,
				"–",
				page.to,
				" of ",
				page.total
			]
		}), /* @__PURE__ */ jsx("div", {
			className: "flex flex-wrap gap-1",
			children: page.links.map((link, i) => link.url ? /* @__PURE__ */ jsx(Link, {
				href: link.url,
				preserveScroll: true,
				"aria-current": link.active ? "page" : void 0,
				className: cn("inline-flex h-8 min-w-8 items-center justify-center rounded-md px-2.5 hover:bg-panel", link.active && "bg-ink text-ivory hover:bg-ink"),
				children: cleanLabel(link.label)
			}, i) : /* @__PURE__ */ jsx("span", {
				className: "inline-flex h-8 min-w-8 items-center justify-center px-2.5 text-stone/50",
				children: cleanLabel(link.label)
			}, i))
		})]
	});
}
function cleanLabel(label) {
	return label.replace("&laquo; Previous", "‹ Previous").replace("Next &raquo;", "Next ›").replace(/&[a-z]+;/g, "");
}
function Stat({ label, value, hint, href }) {
	const body = /* @__PURE__ */ jsxs(Fragment, { children: [
		/* @__PURE__ */ jsx("p", {
			className: "text-sm text-stone",
			children: label
		}),
		/* @__PURE__ */ jsx("p", {
			className: "mt-2 font-display text-3xl tabular-nums",
			children: value
		}),
		hint && /* @__PURE__ */ jsx("p", {
			className: "mt-1 text-xs text-stone",
			children: hint
		})
	] });
	return href ? /* @__PURE__ */ jsx(Link, {
		href,
		className: "block rounded-lg border border-line bg-white p-5 transition-colors hover:border-stone/50",
		children: body
	}) : /* @__PURE__ */ jsx("div", {
		className: "rounded-lg border border-line bg-white p-5",
		children: body
	});
}
//#endregion
export { Panel as a, Stat as c, th as d, Pagination as i, Table as l, OrderStatusBadge as n, PaymentBadge as o, PageHeader as r, ProductStatusBadge as s, EmptyState as t, td as u };
