import { t as cn } from "./utils-BqvNF826.js";
import "react";
import { jsx, jsxs } from "react/jsx-runtime";
import { Accordion } from "radix-ui";
import { Plus } from "lucide-react";
//#region resources/js/components/ui/accordion.tsx
var Accordion$1 = Accordion.Root;
function AccordionItem({ className, ...props }) {
	return /* @__PURE__ */ jsx(Accordion.Item, {
		className: cn("border-b border-line", className),
		...props
	});
}
function AccordionTrigger({ className, children, ...props }) {
	return /* @__PURE__ */ jsx(Accordion.Header, {
		className: "flex",
		children: /* @__PURE__ */ jsxs(Accordion.Trigger, {
			className: cn("group flex flex-1 items-center justify-between gap-6 py-5 text-left text-[1.05rem] font-medium transition-colors hover:text-aloe", className),
			...props,
			children: [children, /* @__PURE__ */ jsx(Plus, {
				className: "size-5 shrink-0 text-dune transition-transform duration-250 group-data-[state=open]:rotate-45",
				"aria-hidden": "true"
			})]
		})
	});
}
function AccordionContent({ className, children, ...props }) {
	return /* @__PURE__ */ jsx(Accordion.Content, {
		className: "overflow-hidden data-[state=closed]:animate-accordion-up data-[state=open]:animate-accordion-down",
		...props,
		children: /* @__PURE__ */ jsx("div", {
			className: cn("pb-6 text-stone", className),
			children
		})
	});
}
//#endregion
export { AccordionTrigger as i, AccordionContent as n, AccordionItem as r, Accordion$1 as t };
