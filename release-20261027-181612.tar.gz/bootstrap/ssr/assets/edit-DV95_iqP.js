import { c as Checkbox, i as Textarea, n as Label, t as Input, v as Button } from "../ssr.js";
import { a as Panel, r as PageHeader } from "./ui-DQeK8Yrd.js";
import { t as Field } from "./field-BVcOZvwI.js";
import { useForm } from "@inertiajs/react";
import { Fragment, jsx, jsxs } from "react/jsx-runtime";
//#region resources/js/pages/admin/pages/edit.tsx
function PageEdit({ page }) {
	const form = useForm({
		title: page.title,
		body: page.body,
		seo_title: page.seo_title ?? "",
		seo_description: page.seo_description ?? "",
		is_published: page.is_published,
		needs_review: page.needs_review
	});
	const submit = (e) => {
		e.preventDefault();
		form.put(`/admin/pages/${page.id}`, { preserveScroll: true });
	};
	const placeholders = (form.data.body.match(/\[[^\]]+\]/g) ?? []).length;
	return /* @__PURE__ */ jsxs(Fragment, { children: [/* @__PURE__ */ jsx(PageHeader, {
		back: {
			href: "/admin/pages",
			label: "Policy pages"
		},
		title: page.title,
		actions: /* @__PURE__ */ jsx(Button, {
			asChild: true,
			variant: "secondary",
			size: "sm",
			children: /* @__PURE__ */ jsx("a", {
				href: page.url,
				target: "_blank",
				rel: "noopener",
				children: "View page"
			})
		})
	}), /* @__PURE__ */ jsxs("form", {
		onSubmit: submit,
		noValidate: true,
		className: "space-y-6",
		children: [/* @__PURE__ */ jsx(Panel, { children: /* @__PURE__ */ jsxs("div", {
			className: "space-y-4",
			children: [
				/* @__PURE__ */ jsx(Field, {
					label: "Title",
					name: "title",
					error: form.errors.title,
					required: true,
					children: (p) => /* @__PURE__ */ jsx(Input, {
						...p,
						value: form.data.title,
						onChange: (e) => form.setData("title", e.target.value),
						maxLength: 120
					})
				}),
				/* @__PURE__ */ jsx(Field, {
					label: "Text",
					name: "body",
					error: form.errors.body,
					required: true,
					hint: /* @__PURE__ */ jsxs(Fragment, { children: [
						"Headings start with ",
						/* @__PURE__ */ jsx("code", { children: "##" }),
						", lists with ",
						/* @__PURE__ */ jsx("code", { children: "-" }),
						", bold with ",
						/* @__PURE__ */ jsx("code", { children: "**text**" }),
						".",
						placeholders > 0 && /* @__PURE__ */ jsxs("strong", {
							className: "ml-1 text-dune-deep",
							children: [placeholders, " placeholder(s) in [brackets] still to complete."]
						})
					] }),
					children: (p) => /* @__PURE__ */ jsx(Textarea, {
						...p,
						rows: 24,
						className: "font-mono text-sm",
						value: form.data.body,
						onChange: (e) => form.setData("body", e.target.value)
					})
				}),
				/* @__PURE__ */ jsxs("div", {
					className: "grid gap-4 sm:grid-cols-2",
					children: [/* @__PURE__ */ jsx(Field, {
						label: "Search title",
						name: "seo_title",
						error: form.errors.seo_title,
						optional: true,
						children: (p) => /* @__PURE__ */ jsx(Input, {
							...p,
							value: form.data.seo_title,
							onChange: (e) => form.setData("seo_title", e.target.value),
							maxLength: 70
						})
					}), /* @__PURE__ */ jsx(Field, {
						label: "Search description",
						name: "seo_description",
						error: form.errors.seo_description,
						optional: true,
						children: (p) => /* @__PURE__ */ jsx(Input, {
							...p,
							value: form.data.seo_description,
							onChange: (e) => form.setData("seo_description", e.target.value),
							maxLength: 170
						})
					})]
				}),
				/* @__PURE__ */ jsxs("div", {
					className: "flex flex-wrap gap-6",
					children: [/* @__PURE__ */ jsxs("div", {
						className: "flex items-center gap-2.5",
						children: [/* @__PURE__ */ jsx(Checkbox, {
							id: "published",
							checked: form.data.is_published,
							onCheckedChange: (v) => form.setData("is_published", v === true)
						}), /* @__PURE__ */ jsx(Label, {
							htmlFor: "published",
							className: "font-normal",
							children: "Published"
						})]
					}), /* @__PURE__ */ jsxs("div", {
						className: "flex items-center gap-2.5",
						children: [/* @__PURE__ */ jsx(Checkbox, {
							id: "review",
							checked: form.data.needs_review,
							onCheckedChange: (v) => form.setData("needs_review", v === true)
						}), /* @__PURE__ */ jsx(Label, {
							htmlFor: "review",
							className: "font-normal",
							children: "Still needs review"
						})]
					})]
				})
			]
		}) }), /* @__PURE__ */ jsx("div", {
			className: "flex justify-end",
			children: /* @__PURE__ */ jsx(Button, {
				type: "submit",
				loading: form.processing,
				children: "Save page"
			})
		})]
	})] });
}
//#endregion
export { PageEdit as default };
