import { t as cn } from "./utils-BqvNF826.js";
import { t as useShared } from "./use-shared-BMnpkZPP.js";
import { a as Panel, d as th, i as Pagination, l as Table, r as PageHeader, t as EmptyState, u as td } from "./ui-DQeK8Yrd.js";
import { n as formatDateTime } from "./date-x_Fsbx42.js";
import { Link } from "@inertiajs/react";
import { Fragment, jsx, jsxs } from "react/jsx-runtime";
//#region resources/js/pages/admin/inventory/history.tsx
function InventoryHistory({ variant, movements }) {
	const { store } = useShared();
	return /* @__PURE__ */ jsxs(Fragment, { children: [/* @__PURE__ */ jsx(PageHeader, {
		back: {
			href: "/admin/inventory",
			label: "Stock"
		},
		title: variant.name,
		description: `${variant.sku ? `SKU ${variant.sku}. ` : ""}${variant.stock} in stock now.`
	}), /* @__PURE__ */ jsxs(Panel, {
		padded: false,
		children: [movements.data.length === 0 ? /* @__PURE__ */ jsx(EmptyState, { title: "No stock changes yet." }) : /* @__PURE__ */ jsxs(Table, { children: [/* @__PURE__ */ jsx("thead", { children: /* @__PURE__ */ jsxs("tr", { children: [
			/* @__PURE__ */ jsx("th", {
				className: th,
				children: "When"
			}),
			/* @__PURE__ */ jsx("th", {
				className: th,
				children: "Reason"
			}),
			/* @__PURE__ */ jsx("th", {
				className: cn(th, "text-right"),
				children: "Change"
			}),
			/* @__PURE__ */ jsx("th", {
				className: cn(th, "text-right"),
				children: "After"
			}),
			/* @__PURE__ */ jsx("th", {
				className: th,
				children: "By"
			})
		] }) }), /* @__PURE__ */ jsx("tbody", { children: movements.data.map((m) => /* @__PURE__ */ jsxs("tr", { children: [
			/* @__PURE__ */ jsx("td", {
				className: cn(td, "whitespace-nowrap text-stone"),
				children: formatDateTime(m.created_at, store.timezone)
			}),
			/* @__PURE__ */ jsxs("td", {
				className: td,
				children: [
					m.reason,
					m.order_reference && /* @__PURE__ */ jsx(Link, {
						href: `/admin/orders/${m.order_reference}`,
						className: "ml-1 underline underline-offset-4",
						children: m.order_reference
					}),
					m.note && /* @__PURE__ */ jsx("span", {
						className: "block text-xs text-stone",
						children: m.note
					})
				]
			}),
			/* @__PURE__ */ jsx("td", {
				className: cn(td, "text-right tabular-nums", m.change < 0 ? "text-clay" : "text-aloe"),
				children: m.change > 0 ? `+${m.change}` : m.change
			}),
			/* @__PURE__ */ jsx("td", {
				className: cn(td, "text-right tabular-nums"),
				children: m.stock_after
			}),
			/* @__PURE__ */ jsx("td", {
				className: cn(td, "text-stone"),
				children: m.user ?? (m.order_reference ? "Customer order" : "—")
			})
		] }, m.id)) })] }), /* @__PURE__ */ jsx(Pagination, { page: movements })]
	})] });
}
//#endregion
export { InventoryHistory as default };
