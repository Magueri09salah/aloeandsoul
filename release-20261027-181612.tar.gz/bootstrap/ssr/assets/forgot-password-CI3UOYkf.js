import { t as Input, v as Button } from "../ssr.js";
import { t as Field } from "./field-BVcOZvwI.js";
import { Head, Link, useForm } from "@inertiajs/react";
import { jsx, jsxs } from "react/jsx-runtime";
//#region resources/js/pages/admin/auth/forgot-password.tsx
function ForgotPassword({ status }) {
	const form = useForm({ email: "" });
	const submit = (e) => {
		e.preventDefault();
		form.post("/admin/forgot-password");
	};
	return /* @__PURE__ */ jsxs("div", {
		className: "rounded-lg border border-line bg-white p-8",
		children: [
			/* @__PURE__ */ jsx(Head, { title: "Reset password — Admin" }),
			/* @__PURE__ */ jsx("h1", {
				className: "font-display text-3xl",
				children: "Reset your password"
			}),
			/* @__PURE__ */ jsx("p", {
				className: "mt-2 text-sm text-stone",
				children: "Enter your email address. If it belongs to an admin account, we’ll send a reset link."
			}),
			status && /* @__PURE__ */ jsx("p", {
				className: "mt-4 rounded-md bg-[#DDE7DA] px-3 py-2 text-sm text-[#2E4A31]",
				role: "status",
				children: status
			}),
			/* @__PURE__ */ jsxs("form", {
				onSubmit: submit,
				className: "mt-6 space-y-5",
				noValidate: true,
				children: [/* @__PURE__ */ jsx(Field, {
					label: "Email",
					name: "email",
					error: form.errors.email,
					required: true,
					children: (p) => /* @__PURE__ */ jsx(Input, {
						...p,
						type: "email",
						autoComplete: "username",
						autoFocus: true,
						value: form.data.email,
						onChange: (e) => form.setData("email", e.target.value)
					})
				}), /* @__PURE__ */ jsx(Button, {
					type: "submit",
					className: "w-full",
					loading: form.processing,
					children: "Send reset link"
				})]
			}),
			/* @__PURE__ */ jsx(Link, {
				href: "/admin/login",
				className: "mt-6 inline-block text-sm underline underline-offset-4",
				children: "Back to sign in"
			})
		]
	});
}
//#endregion
export { ForgotPassword as default };
