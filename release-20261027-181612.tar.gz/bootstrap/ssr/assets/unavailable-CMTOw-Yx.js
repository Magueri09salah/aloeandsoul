import { v as Button } from "../ssr.js";
import { Link } from "@inertiajs/react";
import { jsx, jsxs } from "react/jsx-runtime";
//#region resources/js/pages/product/unavailable.tsx
function ProductUnavailable({ name, category }) {
	return /* @__PURE__ */ jsxs("section", {
		className: "container-page max-w-2xl py-24 text-center",
		children: [
			/* @__PURE__ */ jsxs("h1", {
				className: "font-display text-display-sm",
				children: [name, " is no longer available"]
			}),
			/* @__PURE__ */ jsx("p", {
				className: "mt-4 text-lg text-stone",
				children: "This product has been discontinued. You may find something similar in the same collection."
			}),
			/* @__PURE__ */ jsxs("div", {
				className: "mt-8 flex flex-wrap justify-center gap-3",
				children: [/* @__PURE__ */ jsx(Button, {
					asChild: true,
					children: /* @__PURE__ */ jsxs(Link, {
						href: `/shop/${category.slug}`,
						children: ["Browse ", category.name]
					})
				}), /* @__PURE__ */ jsx(Button, {
					asChild: true,
					variant: "secondary",
					children: /* @__PURE__ */ jsx(Link, {
						href: "/contact",
						children: "Ask us"
					})
				})]
			})
		]
	});
}
//#endregion
export { ProductUnavailable as default };
