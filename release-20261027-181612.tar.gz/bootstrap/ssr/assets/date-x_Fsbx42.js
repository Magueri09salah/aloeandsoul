//#region resources/js/lib/date.ts
var DEFAULT_TZ = "Africa/Casablanca";
function formatDate(iso, timeZone = DEFAULT_TZ) {
	if (!iso) return "—";
	return new Intl.DateTimeFormat("en-GB", {
		day: "numeric",
		month: "short",
		year: "numeric",
		timeZone
	}).format(new Date(iso));
}
function formatDateTime(iso, timeZone = DEFAULT_TZ) {
	if (!iso) return "—";
	return new Intl.DateTimeFormat("en-GB", {
		day: "numeric",
		month: "short",
		year: "numeric",
		hour: "2-digit",
		minute: "2-digit",
		timeZone
	}).format(new Date(iso));
}
//#endregion
export { formatDateTime as n, formatDate as t };
