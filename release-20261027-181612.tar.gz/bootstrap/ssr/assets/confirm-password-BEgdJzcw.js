import { t as Input, v as Button } from "../ssr.js";
import { t as Field } from "./field-BVcOZvwI.js";
import { Head, useForm } from "@inertiajs/react";
import { jsx, jsxs } from "react/jsx-runtime";
//#region resources/js/pages/admin/auth/confirm-password.tsx
function ConfirmPassword() {
	const form = useForm({ password: "" });
	const submit = (e) => {
		e.preventDefault();
		form.post("/admin/user/confirm-password", { onFinish: () => form.reset() });
	};
	return /* @__PURE__ */ jsxs("div", {
		className: "rounded-lg border border-line bg-white p-8",
		children: [
			/* @__PURE__ */ jsx(Head, { title: "Confirm password — Admin" }),
			/* @__PURE__ */ jsx("h1", {
				className: "font-display text-3xl",
				children: "Confirm your password"
			}),
			/* @__PURE__ */ jsx("p", {
				className: "mt-2 text-sm text-stone",
				children: "For your security, please confirm your password to continue."
			}),
			/* @__PURE__ */ jsxs("form", {
				onSubmit: submit,
				className: "mt-6 space-y-5",
				noValidate: true,
				children: [/* @__PURE__ */ jsx(Field, {
					label: "Password",
					name: "password",
					error: form.errors.password,
					required: true,
					children: (p) => /* @__PURE__ */ jsx(Input, {
						...p,
						type: "password",
						autoComplete: "current-password",
						autoFocus: true,
						value: form.data.password,
						onChange: (e) => form.setData("password", e.target.value)
					})
				}), /* @__PURE__ */ jsx(Button, {
					type: "submit",
					className: "w-full",
					loading: form.processing,
					children: "Confirm"
				})]
			})
		]
	});
}
//#endregion
export { ConfirmPassword as default };
