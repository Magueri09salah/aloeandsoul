import { n as plural, t as cn } from "./utils-BqvNF826.js";
import { t as useShared } from "./use-shared-BMnpkZPP.js";
import { _ as SheetContent, c as Checkbox, f as Motif, g as Sheet, n as Label, r as Select, t as Input, v as Button } from "../ssr.js";
import { n as ProductCard } from "./product-card-Czb8w07c.js";
import { t as Breadcrumbs } from "./breadcrumbs-D6WOVEz0.js";
import { Link, router, usePage } from "@inertiajs/react";
import { useState } from "react";
import { Fragment, jsx, jsxs } from "react/jsx-runtime";
import { SlidersHorizontal } from "lucide-react";
//#region resources/js/pages/shop/index.tsx
var SORTS = [
	{
		value: "featured",
		label: "Featured"
	},
	{
		value: "newest",
		label: "Newest"
	},
	{
		value: "price_asc",
		label: "Price, low to high"
	},
	{
		value: "price_desc",
		label: "Price, high to low"
	},
	{
		value: "name",
		label: "Name, A to Z"
	}
];
function Shop({ category, categories, products, filters, breadcrumbs }) {
	const { url } = usePage();
	const path = url.split("?")[0] ?? "/shop";
	const [sheetOpen, setSheetOpen] = useState(false);
	const apply = (next) => {
		const merged = {
			...filters,
			...next
		};
		const query = {};
		if (merged.q) query.q = merged.q;
		if (merged.availability) query.availability = merged.availability;
		if (merged.on_sale) query.on_sale = "1";
		if (merged.min_price) query.min_price = merged.min_price;
		if (merged.max_price) query.max_price = merged.max_price;
		if (merged.sort && merged.sort !== "featured") query.sort = merged.sort;
		router.get(path, query, {
			preserveScroll: true,
			preserveState: true,
			replace: true
		});
	};
	const activeCount = [
		filters.q,
		filters.availability,
		filters.on_sale || null,
		filters.min_price,
		filters.max_price
	].filter(Boolean).length;
	return /* @__PURE__ */ jsxs(Fragment, { children: [
		/* @__PURE__ */ jsx("header", {
			className: "relative overflow-hidden",
			style: { backgroundColor: category?.tint ?? "var(--color-sand)" },
			children: /* @__PURE__ */ jsxs("div", {
				className: "container-page relative py-10 lg:py-16",
				children: [
					/* @__PURE__ */ jsx(Breadcrumbs, { items: breadcrumbs }),
					/* @__PURE__ */ jsxs("div", {
						className: "mt-6 max-w-2xl",
						children: [
							/* @__PURE__ */ jsx("h1", {
								className: "font-display text-display",
								children: category?.name ?? "All products"
							}),
							(category?.description ?? category?.tagline) && /* @__PURE__ */ jsx("p", {
								className: "mt-4 text-lg text-ink/80",
								children: category?.description ?? category?.tagline
							}),
							!category && /* @__PURE__ */ jsx("p", {
								className: "mt-4 text-lg text-ink/80",
								children: "Wellness, beauty, hygiene, fitness and nutrition, chosen by the founder."
							})
						]
					}),
					/* @__PURE__ */ jsx("div", {
						className: "pointer-events-none absolute top-1/2 right-6 hidden w-56 -translate-y-1/2 text-dune/70 md:block lg:right-16 lg:w-72",
						children: /* @__PURE__ */ jsx(Motif, { name: category?.motif ?? "circle" })
					})
				]
			})
		}),
		/* @__PURE__ */ jsx("nav", {
			"aria-label": "Categories",
			className: "border-b border-line",
			children: /* @__PURE__ */ jsxs("ul", {
				className: "container-page flex gap-2 overflow-x-auto py-4 [scrollbar-width:none]",
				children: [/* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsx(CategoryPill, {
					href: "/shop",
					active: !category,
					children: "All"
				}) }), categories.map((c) => /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsx(CategoryPill, {
					href: `/shop/${c.slug}`,
					active: category?.slug === c.slug,
					tint: c.tint,
					children: c.name
				}) }, c.slug))]
			})
		}),
		/* @__PURE__ */ jsxs("div", {
			className: "container-page grid gap-10 py-10 lg:grid-cols-[15rem_1fr] lg:gap-12",
			children: [/* @__PURE__ */ jsx("aside", {
				className: "hidden lg:block",
				"aria-label": "Filters",
				children: /* @__PURE__ */ jsx(FilterPanel, {
					filters,
					onApply: apply
				})
			}), /* @__PURE__ */ jsxs("section", {
				"aria-labelledby": "results-heading",
				children: [
					/* @__PURE__ */ jsxs("div", {
						className: "flex flex-wrap items-center justify-between gap-3 border-b border-line pb-4",
						children: [/* @__PURE__ */ jsx("h2", {
							id: "results-heading",
							className: "text-stone",
							"aria-live": "polite",
							children: filters.q ? /* @__PURE__ */ jsxs(Fragment, { children: [
								plural(products.meta.total, "result"),
								" for ",
								/* @__PURE__ */ jsxs("span", {
									className: "text-ink",
									children: [
										"“",
										filters.q,
										"”"
									]
								})
							] }) : plural(products.meta.total, "product")
						}), /* @__PURE__ */ jsxs("div", {
							className: "flex items-center gap-2",
							children: [
								/* @__PURE__ */ jsxs(Button, {
									variant: "secondary",
									size: "sm",
									className: "lg:hidden",
									onClick: () => setSheetOpen(true),
									children: [
										/* @__PURE__ */ jsx(SlidersHorizontal, { "aria-hidden": "true" }),
										"Filter",
										activeCount > 0 ? ` (${activeCount})` : ""
									]
								}),
								/* @__PURE__ */ jsx("label", {
									htmlFor: "sort",
									className: "sr-only",
									children: "Sort by"
								}),
								/* @__PURE__ */ jsx(Select, {
									id: "sort",
									value: filters.sort,
									onChange: (e) => apply({ sort: e.target.value }),
									className: "h-9 w-auto rounded-full text-sm",
									children: SORTS.map((s) => /* @__PURE__ */ jsx("option", {
										value: s.value,
										children: s.label
									}, s.value))
								})
							]
						})]
					}),
					products.data.length === 0 ? /* @__PURE__ */ jsxs("div", {
						className: "py-20 text-center",
						children: [
							/* @__PURE__ */ jsx("p", {
								className: "font-display text-3xl",
								children: "No products match."
							}),
							/* @__PURE__ */ jsx("p", {
								className: "mt-3 text-stone",
								children: activeCount > 0 ? "Try removing a filter or searching for something else." : "New products are on their way. Please come back soon."
							}),
							activeCount > 0 && /* @__PURE__ */ jsx(Button, {
								variant: "secondary",
								className: "mt-6",
								onClick: () => router.get(path),
								children: "Clear filters"
							})
						]
					}) : /* @__PURE__ */ jsx("div", {
						className: "mt-8 grid grid-cols-2 gap-x-4 gap-y-10 sm:grid-cols-3 sm:gap-x-6",
						children: products.data.map((p, i) => /* @__PURE__ */ jsx(ProductCard, {
							product: p,
							priority: i < 2,
							sizes: "(min-width: 1024px) 22vw, (min-width: 640px) 33vw, 50vw"
						}, p.id))
					}),
					products.meta.last_page > 1 && /* @__PURE__ */ jsxs("nav", {
						"aria-label": "Pages",
						className: "mt-14 flex flex-wrap items-center justify-center gap-1",
						children: [
							products.links.prev && /* @__PURE__ */ jsx(Link, {
								href: products.links.prev,
								preserveScroll: false,
								className: "mr-2 rounded-full px-4 py-2 hover:bg-sand",
								rel: "prev",
								children: "Previous"
							}),
							products.links.pages.map((p) => /* @__PURE__ */ jsx(Link, {
								href: p.url,
								"aria-current": p.page === products.meta.current_page ? "page" : void 0,
								className: cn("inline-flex size-10 items-center justify-center rounded-full tabular-nums hover:bg-sand", p.page === products.meta.current_page && "bg-ink text-ivory hover:bg-ink"),
								children: p.page
							}, p.page)),
							products.links.next && /* @__PURE__ */ jsx(Link, {
								href: products.links.next,
								className: "ml-2 rounded-full px-4 py-2 hover:bg-sand",
								rel: "next",
								children: "Next"
							})
						]
					})
				]
			})]
		}),
		/* @__PURE__ */ jsx(Sheet, {
			open: sheetOpen,
			onOpenChange: setSheetOpen,
			children: /* @__PURE__ */ jsx(SheetContent, {
				side: "bottom",
				title: "Filter",
				children: /* @__PURE__ */ jsx("div", {
					className: "overflow-y-auto px-5 pt-4 pb-8",
					children: /* @__PURE__ */ jsx(FilterPanel, {
						filters,
						onApply: (next) => {
							apply(next);
							setSheetOpen(false);
						},
						instant: false
					})
				})
			})
		})
	] });
}
function CategoryPill({ href, active, tint, children }) {
	return /* @__PURE__ */ jsxs(Link, {
		href,
		"aria-current": active ? "page" : void 0,
		className: cn("inline-flex h-10 items-center gap-2 rounded-full border px-4 text-sm whitespace-nowrap transition-colors", active ? "border-ink bg-ink text-ivory" : "border-line bg-white hover:border-ink"),
		children: [tint && /* @__PURE__ */ jsx("span", {
			className: "size-2.5 rounded-full",
			style: { backgroundColor: tint },
			"aria-hidden": "true"
		}), children]
	});
}
function FilterPanel({ filters, onApply, instant = true }) {
	const { store } = useShared();
	const [draft, setDraft] = useState({
		q: filters.q ?? "",
		min_price: filters.min_price ?? "",
		max_price: filters.max_price ?? "",
		availability: filters.availability,
		on_sale: filters.on_sale
	});
	const submit = (e) => {
		e.preventDefault();
		onApply({
			q: draft.q.trim() || null,
			min_price: draft.min_price.trim() || null,
			max_price: draft.max_price.trim() || null,
			availability: draft.availability,
			on_sale: draft.on_sale
		});
	};
	const toggle = (next) => {
		setDraft((d) => ({
			...d,
			...next
		}));
		if (instant) onApply(next);
	};
	return /* @__PURE__ */ jsxs("form", {
		onSubmit: submit,
		className: "space-y-8",
		children: [
			/* @__PURE__ */ jsxs("div", {
				className: "space-y-2",
				children: [/* @__PURE__ */ jsx(Label, {
					htmlFor: "filter-q",
					children: "Search"
				}), /* @__PURE__ */ jsx(Input, {
					id: "filter-q",
					type: "search",
					value: draft.q,
					maxLength: 100,
					onChange: (e) => setDraft({
						...draft,
						q: e.target.value
					}),
					placeholder: "Product name"
				})]
			}),
			/* @__PURE__ */ jsxs("fieldset", {
				className: "space-y-3",
				children: [
					/* @__PURE__ */ jsx("legend", {
						className: "mb-3 text-sm font-medium",
						children: "Availability"
					}),
					/* @__PURE__ */ jsxs("div", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ jsx(Checkbox, {
							id: "filter-stock",
							checked: draft.availability === "in_stock",
							onCheckedChange: (v) => toggle({ availability: v === true ? "in_stock" : null })
						}), /* @__PURE__ */ jsx(Label, {
							htmlFor: "filter-stock",
							className: "font-normal",
							children: "In stock only"
						})]
					}),
					/* @__PURE__ */ jsxs("div", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ jsx(Checkbox, {
							id: "filter-sale",
							checked: draft.on_sale,
							onCheckedChange: (v) => toggle({ on_sale: v === true })
						}), /* @__PURE__ */ jsx(Label, {
							htmlFor: "filter-sale",
							className: "font-normal",
							children: "On sale"
						})]
					})
				]
			}),
			/* @__PURE__ */ jsxs("fieldset", { children: [/* @__PURE__ */ jsxs("legend", {
				className: "mb-3 text-sm font-medium",
				children: [
					"Price (",
					store.currency,
					")"
				]
			}), /* @__PURE__ */ jsxs("div", {
				className: "flex items-center gap-2",
				children: [
					/* @__PURE__ */ jsx("label", {
						htmlFor: "filter-min",
						className: "sr-only",
						children: "Minimum price"
					}),
					/* @__PURE__ */ jsx(Input, {
						id: "filter-min",
						inputMode: "decimal",
						placeholder: "Min",
						value: draft.min_price,
						onChange: (e) => setDraft({
							...draft,
							min_price: e.target.value
						})
					}),
					/* @__PURE__ */ jsx("span", {
						"aria-hidden": "true",
						className: "text-stone",
						children: "–"
					}),
					/* @__PURE__ */ jsx("label", {
						htmlFor: "filter-max",
						className: "sr-only",
						children: "Maximum price"
					}),
					/* @__PURE__ */ jsx(Input, {
						id: "filter-max",
						inputMode: "decimal",
						placeholder: "Max",
						value: draft.max_price,
						onChange: (e) => setDraft({
							...draft,
							max_price: e.target.value
						})
					})
				]
			})] }),
			/* @__PURE__ */ jsx(Button, {
				type: "submit",
				variant: "secondary",
				className: "w-full",
				children: "Apply"
			})
		]
	});
}
//#endregion
export { Shop as default };
