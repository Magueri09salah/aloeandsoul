import { a as ConfirmDialog, c as Checkbox, i as Textarea, l as Switch, n as Label, r as Select, t as Input, v as Button } from "../ssr.js";
import { a as Panel, r as PageHeader, s as ProductStatusBadge } from "./ui-DQeK8Yrd.js";
import { n as FormErrorSummary, t as Field } from "./field-BVcOZvwI.js";
import { router, useForm } from "@inertiajs/react";
import { useState } from "react";
import { Fragment, jsx, jsxs } from "react/jsx-runtime";
import { ArrowDown, ArrowUp, ExternalLink, Plus, Trash2, Upload } from "lucide-react";
//#region resources/js/pages/admin/products/form.tsx
var emptyVariant = () => ({
	id: null,
	name: "",
	sku: "",
	price: "",
	sale_price: "",
	stock: 0,
	track_stock: true,
	low_stock_threshold: "",
	is_active: true
});
function ProductForm({ product, categories, defaultCategoryId, currency }) {
	const form = useForm({
		name: product?.name ?? "",
		slug: product?.slug ?? "",
		category_id: String(product?.category_id ?? defaultCategoryId ?? categories[0]?.id ?? ""),
		summary: product?.summary ?? "",
		description: product?.description ?? "",
		specifications: product?.specifications ?? [],
		option_label: product?.option_label ?? "",
		is_featured: product?.is_featured ?? false,
		is_bestseller: product?.is_bestseller ?? false,
		sort_order: product?.sort_order ?? 0,
		seo_title: product?.seo_title ?? "",
		seo_description: product?.seo_description ?? "",
		variants: product?.variants.length ? product.variants.map((v) => ({
			...v,
			name: v.name ?? "",
			sku: v.sku ?? "",
			low_stock_threshold: v.low_stock_threshold ?? ""
		})) : [emptyVariant()]
	});
	const submit = (e) => {
		e.preventDefault();
		if (product) form.put(`/admin/products/${product.id}`, { preserveScroll: true });
		else form.post("/admin/products");
	};
	const err = (key) => form.errors[key];
	const setVariant = (i, patch) => form.setData("variants", form.data.variants.map((v, j) => j === i ? {
		...v,
		...patch
	} : v));
	const multi = form.data.variants.length > 1;
	return /* @__PURE__ */ jsxs(Fragment, { children: [/* @__PURE__ */ jsx(PageHeader, {
		back: {
			href: "/admin/products",
			label: "Products"
		},
		title: product ? product.name : "New product",
		description: product && /* @__PURE__ */ jsxs("span", {
			className: "flex flex-wrap items-center gap-2",
			children: [/* @__PURE__ */ jsx(ProductStatusBadge, {
				status: product.status,
				label: product.status_label
			}), product.url && /* @__PURE__ */ jsxs("a", {
				href: product.url,
				target: "_blank",
				rel: "noopener",
				className: "inline-flex items-center gap-1 text-sm underline underline-offset-4",
				children: ["View in shop ", /* @__PURE__ */ jsx(ExternalLink, {
					className: "size-3.5",
					"aria-hidden": "true"
				})]
			})]
		})
	}), /* @__PURE__ */ jsxs("div", {
		className: "grid gap-6 lg:grid-cols-3",
		children: [/* @__PURE__ */ jsxs("form", {
			onSubmit: submit,
			noValidate: true,
			className: "space-y-6 lg:col-span-2",
			id: "product-form",
			children: [
				/* @__PURE__ */ jsx(FormErrorSummary, { errors: { general: err("general") } }),
				/* @__PURE__ */ jsx(Panel, {
					title: "Basics",
					children: /* @__PURE__ */ jsxs("div", {
						className: "space-y-5",
						children: [
							/* @__PURE__ */ jsx(Field, {
								label: "Name",
								name: "name",
								error: err("name"),
								required: true,
								children: (p) => /* @__PURE__ */ jsx(Input, {
									...p,
									value: form.data.name,
									onChange: (e) => form.setData("name", e.target.value),
									maxLength: 160
								})
							}),
							/* @__PURE__ */ jsxs("div", {
								className: "grid gap-5 sm:grid-cols-2",
								children: [/* @__PURE__ */ jsx(Field, {
									label: "Category",
									name: "category_id",
									error: err("category_id"),
									required: true,
									children: (p) => /* @__PURE__ */ jsx(Select, {
										...p,
										value: form.data.category_id,
										onChange: (e) => form.setData("category_id", e.target.value),
										children: categories.map((c) => /* @__PURE__ */ jsx("option", {
											value: c.id,
											children: c.name
										}, c.id))
									})
								}), /* @__PURE__ */ jsx(Field, {
									label: "Web address",
									name: "slug",
									error: err("slug"),
									hint: "Leave empty to create it from the name.",
									optional: true,
									children: (p) => /* @__PURE__ */ jsx(Input, {
										...p,
										value: form.data.slug,
										onChange: (e) => form.setData("slug", e.target.value),
										maxLength: 180,
										placeholder: "aloe-vera-gel"
									})
								})]
							}),
							/* @__PURE__ */ jsx(Field, {
								label: "Short summary",
								name: "summary",
								error: err("summary"),
								hint: "One line shown under the name. Describe what it is, without health claims.",
								optional: true,
								children: (p) => /* @__PURE__ */ jsx(Input, {
									...p,
									value: form.data.summary,
									onChange: (e) => form.setData("summary", e.target.value),
									maxLength: 255
								})
							}),
							/* @__PURE__ */ jsx(Field, {
								label: "Description",
								name: "description",
								error: err("description"),
								hint: "Use the official product information. You can use **bold**, *italic* and lists (- item). Do not promise to treat, cure or prevent any condition.",
								children: (p) => /* @__PURE__ */ jsx(Textarea, {
									...p,
									rows: 8,
									value: form.data.description,
									onChange: (e) => form.setData("description", e.target.value)
								})
							}),
							/* @__PURE__ */ jsxs("fieldset", { children: [
								/* @__PURE__ */ jsx("legend", {
									className: "text-sm font-medium",
									children: "Details table"
								}),
								/* @__PURE__ */ jsx("p", {
									className: "mt-1 text-sm text-stone",
									children: "For example Volume: 1 litre, or Flavour: Vanilla."
								}),
								/* @__PURE__ */ jsxs("div", {
									className: "mt-3 space-y-2",
									children: [form.data.specifications.map((s, i) => /* @__PURE__ */ jsxs("div", {
										className: "flex gap-2",
										children: [
											/* @__PURE__ */ jsx(Input, {
												"aria-label": `Detail ${i + 1} label`,
												"aria-invalid": err(`specifications.${i}.label`) ? true : void 0,
												placeholder: "Label",
												value: s.label,
												onChange: (e) => form.setData("specifications", form.data.specifications.map((x, j) => j === i ? {
													...x,
													label: e.target.value
												} : x)),
												className: "max-w-48"
											}),
											/* @__PURE__ */ jsx(Input, {
												"aria-label": `Detail ${i + 1} value`,
												"aria-invalid": err(`specifications.${i}.value`) ? true : void 0,
												placeholder: "Value",
												value: s.value,
												onChange: (e) => form.setData("specifications", form.data.specifications.map((x, j) => j === i ? {
													...x,
													value: e.target.value
												} : x))
											}),
											/* @__PURE__ */ jsx(Button, {
												type: "button",
												variant: "ghost",
												size: "icon",
												"aria-label": `Remove detail ${i + 1}`,
												onClick: () => form.setData("specifications", form.data.specifications.filter((_, j) => j !== i)),
												children: /* @__PURE__ */ jsx(Trash2, { "aria-hidden": "true" })
											})
										]
									}, i)), form.data.specifications.length < 20 && /* @__PURE__ */ jsxs(Button, {
										type: "button",
										variant: "ghost",
										size: "sm",
										onClick: () => form.setData("specifications", [...form.data.specifications, {
											label: "",
											value: ""
										}]),
										children: [/* @__PURE__ */ jsx(Plus, { "aria-hidden": "true" }), " Add a detail"]
									})]
								})
							] })
						]
					})
				}),
				/* @__PURE__ */ jsxs(Panel, {
					title: "Price and stock",
					description: `Prices in ${currency}. Changing stock here is recorded in the stock history.`,
					actions: /* @__PURE__ */ jsxs(Button, {
						type: "button",
						size: "sm",
						variant: "secondary",
						onClick: () => form.setData("variants", [...form.data.variants, emptyVariant()]),
						children: [/* @__PURE__ */ jsx(Plus, { "aria-hidden": "true" }), " Add option"]
					}),
					children: [multi && /* @__PURE__ */ jsx(Field, {
						label: "What do the options differ by?",
						name: "option_label",
						error: err("option_label"),
						hint: "For example Flavour, Size or Volume.",
						className: "mb-5 max-w-xs",
						children: (p) => /* @__PURE__ */ jsx(Input, {
							...p,
							value: form.data.option_label,
							onChange: (e) => form.setData("option_label", e.target.value),
							maxLength: 40
						})
					}), /* @__PURE__ */ jsx("div", {
						className: "space-y-4",
						children: form.data.variants.map((v, i) => /* @__PURE__ */ jsxs("fieldset", {
							className: "rounded-md border border-line p-4",
							children: [
								/* @__PURE__ */ jsx("legend", {
									className: "px-1 text-sm font-medium",
									children: multi ? v.name || `Option ${i + 1}` : "Price and stock"
								}),
								/* @__PURE__ */ jsxs("div", {
									className: "grid gap-4 sm:grid-cols-2 lg:grid-cols-4",
									children: [
										multi && /* @__PURE__ */ jsx(Field, {
											label: "Option name",
											name: `variants.${i}.name`,
											error: err(`variants.${i}.name`),
											required: true,
											className: "sm:col-span-2",
											children: (p) => /* @__PURE__ */ jsx(Input, {
												...p,
												value: v.name,
												onChange: (e) => setVariant(i, { name: e.target.value }),
												placeholder: "e.g. Vanilla",
												maxLength: 80
											})
										}),
										/* @__PURE__ */ jsx(Field, {
											label: "SKU",
											name: `variants.${i}.sku`,
											error: err(`variants.${i}.sku`),
											optional: true,
											className: multi ? "sm:col-span-2" : void 0,
											children: (p) => /* @__PURE__ */ jsx(Input, {
												...p,
												value: v.sku,
												onChange: (e) => setVariant(i, { sku: e.target.value }),
												maxLength: 64
											})
										}),
										/* @__PURE__ */ jsx(Field, {
											label: "Price",
											name: `variants.${i}.price`,
											error: err(`variants.${i}.price`),
											children: (p) => /* @__PURE__ */ jsx(Input, {
												...p,
												inputMode: "decimal",
												value: v.price,
												onChange: (e) => setVariant(i, { price: e.target.value }),
												placeholder: "249.00"
											})
										}),
										/* @__PURE__ */ jsx(Field, {
											label: "Sale price",
											name: `variants.${i}.sale_price`,
											error: err(`variants.${i}.sale_price`),
											optional: true,
											children: (p) => /* @__PURE__ */ jsx(Input, {
												...p,
												inputMode: "decimal",
												value: v.sale_price,
												onChange: (e) => setVariant(i, { sale_price: e.target.value })
											})
										}),
										/* @__PURE__ */ jsx(Field, {
											label: "In stock",
											name: `variants.${i}.stock`,
											error: err(`variants.${i}.stock`),
											children: (p) => /* @__PURE__ */ jsx(Input, {
												...p,
												type: "number",
												min: 0,
												value: v.stock,
												disabled: !v.track_stock,
												onChange: (e) => setVariant(i, { stock: Math.max(0, Number.parseInt(e.target.value || "0", 10)) })
											})
										}),
										/* @__PURE__ */ jsx(Field, {
											label: "Low stock alert at",
											name: `variants.${i}.low_stock_threshold`,
											error: err(`variants.${i}.low_stock_threshold`),
											optional: true,
											children: (p) => /* @__PURE__ */ jsx(Input, {
												...p,
												type: "number",
												min: 0,
												value: v.low_stock_threshold ?? "",
												onChange: (e) => setVariant(i, { low_stock_threshold: e.target.value }),
												placeholder: "Default"
											})
										})
									]
								}),
								/* @__PURE__ */ jsxs("div", {
									className: "mt-4 flex flex-wrap items-center gap-x-6 gap-y-3",
									children: [
										/* @__PURE__ */ jsxs("div", {
											className: "flex items-center gap-2",
											children: [/* @__PURE__ */ jsx(Checkbox, {
												id: `track-${i}`,
												checked: v.track_stock,
												onCheckedChange: (c) => setVariant(i, { track_stock: c === true })
											}), /* @__PURE__ */ jsx(Label, {
												htmlFor: `track-${i}`,
												className: "font-normal",
												children: "Track stock"
											})]
										}),
										/* @__PURE__ */ jsxs("div", {
											className: "flex items-center gap-2",
											children: [/* @__PURE__ */ jsx(Checkbox, {
												id: `active-${i}`,
												checked: v.is_active,
												onCheckedChange: (c) => setVariant(i, { is_active: c === true })
											}), /* @__PURE__ */ jsx(Label, {
												htmlFor: `active-${i}`,
												className: "font-normal",
												children: "Available for sale"
											})]
										}),
										multi && /* @__PURE__ */ jsxs(Button, {
											type: "button",
											variant: "ghost",
											size: "sm",
											className: "ml-auto text-clay",
											onClick: () => form.setData("variants", form.data.variants.filter((_, j) => j !== i)),
											children: [/* @__PURE__ */ jsx(Trash2, { "aria-hidden": "true" }), " Remove option"]
										})
									]
								})
							]
						}, v.id ?? `new-${i}`))
					})]
				}),
				/* @__PURE__ */ jsx(Panel, {
					title: "Search engines",
					description: "Optional. By default the product name and summary are used.",
					children: /* @__PURE__ */ jsxs("div", {
						className: "space-y-5",
						children: [/* @__PURE__ */ jsx(Field, {
							label: "Page title",
							name: "seo_title",
							error: err("seo_title"),
							hint: `${form.data.seo_title.length}/70 characters`,
							optional: true,
							children: (p) => /* @__PURE__ */ jsx(Input, {
								...p,
								value: form.data.seo_title,
								onChange: (e) => form.setData("seo_title", e.target.value),
								maxLength: 70
							})
						}), /* @__PURE__ */ jsx(Field, {
							label: "Description",
							name: "seo_description",
							error: err("seo_description"),
							hint: `${form.data.seo_description.length}/170 characters`,
							optional: true,
							children: (p) => /* @__PURE__ */ jsx(Textarea, {
								...p,
								rows: 2,
								value: form.data.seo_description,
								onChange: (e) => form.setData("seo_description", e.target.value),
								maxLength: 170
							})
						})]
					})
				}),
				/* @__PURE__ */ jsx("div", {
					className: "sticky bottom-0 z-10 -mx-4 flex justify-end gap-2 border-t border-line bg-panel/95 px-4 py-3 backdrop-blur sm:mx-0 sm:rounded-lg sm:border",
					children: /* @__PURE__ */ jsx(Button, {
						type: "submit",
						loading: form.processing,
						children: product ? "Save product" : "Create draft"
					})
				})
			]
		}), /* @__PURE__ */ jsxs("div", {
			className: "space-y-6",
			children: [
				product && /* @__PURE__ */ jsx(Visibility, { product }),
				/* @__PURE__ */ jsx(Panel, {
					title: "Merchandising",
					children: /* @__PURE__ */ jsxs("div", {
						className: "space-y-4",
						children: [
							/* @__PURE__ */ jsxs("div", {
								className: "flex items-center justify-between gap-3",
								children: [/* @__PURE__ */ jsx(Label, {
									htmlFor: "featured",
									className: "font-normal",
									children: "Featured on the home page"
								}), /* @__PURE__ */ jsx(Switch, {
									id: "featured",
									checked: form.data.is_featured,
									onCheckedChange: (v) => form.setData("is_featured", v)
								})]
							}),
							/* @__PURE__ */ jsxs("div", {
								className: "flex items-center justify-between gap-3",
								children: [/* @__PURE__ */ jsx(Label, {
									htmlFor: "bestseller",
									className: "font-normal",
									children: "Show “Bestseller” label"
								}), /* @__PURE__ */ jsx(Switch, {
									id: "bestseller",
									checked: form.data.is_bestseller,
									onCheckedChange: (v) => form.setData("is_bestseller", v)
								})]
							}),
							/* @__PURE__ */ jsx(Field, {
								label: "Position",
								name: "sort_order",
								error: err("sort_order"),
								hint: "Lower numbers appear first.",
								children: (p) => /* @__PURE__ */ jsx(Input, {
									...p,
									type: "number",
									value: form.data.sort_order,
									onChange: (e) => form.setData("sort_order", Number(e.target.value)),
									className: "max-w-28"
								})
							}),
							/* @__PURE__ */ jsx("p", {
								className: "text-xs text-stone",
								children: "Saved with the product."
							})
						]
					})
				}),
				product ? /* @__PURE__ */ jsx(ImageManager, { product }) : /* @__PURE__ */ jsx(Panel, {
					title: "Images",
					children: /* @__PURE__ */ jsx("p", {
						className: "text-sm text-stone",
						children: "Create the draft first, then add images."
					})
				}),
				product && !product.has_orders && /* @__PURE__ */ jsxs(Panel, {
					title: "Delete",
					children: [/* @__PURE__ */ jsx("p", {
						className: "text-sm text-stone",
						children: "Deleting cannot be undone. Products that have been ordered can only be archived."
					}), /* @__PURE__ */ jsx(ConfirmDialog, {
						trigger: /* @__PURE__ */ jsx(Button, {
							variant: "destructive-outline",
							size: "sm",
							className: "mt-3",
							children: "Delete product"
						}),
						title: "Delete this product?",
						description: `“${product.name}” and its images will be removed permanently.`,
						confirmLabel: "Delete product",
						onConfirm: () => router.delete(`/admin/products/${product.id}`)
					})]
				})
			]
		})]
	})] });
}
function Visibility({ product }) {
	const status = (action) => router.post(`/admin/products/${product.id}/status`, { action }, { preserveScroll: true });
	return /* @__PURE__ */ jsxs(Panel, {
		title: "Visibility",
		children: [
			product.status === "draft" && /* @__PURE__ */ jsxs(Fragment, { children: [product.blockers.length > 0 ? /* @__PURE__ */ jsxs(Fragment, { children: [
				/* @__PURE__ */ jsx("p", {
					className: "text-sm",
					children: "Before publishing:"
				}),
				/* @__PURE__ */ jsx("ul", {
					className: "mt-2 list-disc space-y-1 pl-5 text-sm text-stone",
					children: product.blockers.map((b) => /* @__PURE__ */ jsx("li", { children: b }, b))
				}),
				/* @__PURE__ */ jsx("p", {
					className: "mt-3 text-xs text-stone",
					children: "Save your changes first; this list updates after saving."
				})
			] }) : /* @__PURE__ */ jsx("p", {
				className: "text-sm text-stone",
				children: "Ready to publish."
			}), /* @__PURE__ */ jsx(Button, {
				className: "mt-4 w-full",
				disabled: product.blockers.length > 0,
				onClick: () => status("publish"),
				children: "Publish"
			})] }),
			product.status === "published" && /* @__PURE__ */ jsxs("div", {
				className: "space-y-2",
				children: [
					/* @__PURE__ */ jsx("p", {
						className: "text-sm text-stone",
						children: "Visible in the shop."
					}),
					/* @__PURE__ */ jsx(Button, {
						variant: "secondary",
						className: "w-full",
						onClick: () => status("unpublish"),
						children: "Move back to drafts"
					}),
					/* @__PURE__ */ jsx(ConfirmDialog, {
						trigger: /* @__PURE__ */ jsx(Button, {
							variant: "ghost",
							className: "w-full",
							children: "Archive (discontinued)"
						}),
						title: "Archive this product?",
						description: "It leaves the shop, and its page tells visitors it is no longer available. Past orders are not affected.",
						confirmLabel: "Archive",
						onConfirm: () => status("archive")
					})
				]
			}),
			product.status === "archived" && /* @__PURE__ */ jsx(Button, {
				variant: "secondary",
				className: "w-full",
				onClick: () => status("restore"),
				children: "Restore as draft"
			})
		]
	});
}
function ImageManager({ product }) {
	const upload = useForm({ images: [] });
	const [images, setImages] = useState(product.images.map((i) => ({
		id: i.id,
		src: i.src,
		alt: i.alt
	})));
	const [dirty, setDirty] = useState(false);
	const serverIds = product.images.map((i) => i.id).join(",");
	const [syncedIds, setSyncedIds] = useState(serverIds);
	if (serverIds !== syncedIds) {
		setSyncedIds(serverIds);
		setImages(product.images.map((i) => ({
			id: i.id,
			src: i.src,
			alt: i.alt
		})));
		setDirty(false);
	}
	const move = (i, d) => {
		const next = [...images];
		const [item] = next.splice(i, 1);
		if (!item) return;
		next.splice(i + d, 0, item);
		setImages(next);
		setDirty(true);
	};
	const uploadErrors = Object.entries(upload.errors).map(([, m]) => m);
	return /* @__PURE__ */ jsxs(Panel, {
		title: "Images",
		description: "JPG, PNG or WebP, at least 400 px wide. The first image is the main one.",
		children: [
			/* @__PURE__ */ jsxs("form", {
				onSubmit: (e) => {
					e.preventDefault();
					upload.post(`/admin/products/${product.id}/images`, {
						forceFormData: true,
						preserveScroll: true,
						onSuccess: () => upload.reset()
					});
				},
				children: [
					/* @__PURE__ */ jsxs("label", {
						className: "flex cursor-pointer flex-col items-center justify-center gap-2 rounded-md border border-dashed border-stone/40 px-4 py-6 text-center text-sm hover:border-ink",
						children: [
							/* @__PURE__ */ jsx(Upload, {
								className: "size-5 text-stone",
								"aria-hidden": "true"
							}),
							/* @__PURE__ */ jsx("span", { children: upload.data.images.length ? `${upload.data.images.length} file(s) selected` : "Choose images" }),
							/* @__PURE__ */ jsx("input", {
								type: "file",
								accept: "image/jpeg,image/png,image/webp",
								multiple: true,
								className: "sr-only",
								onChange: (e) => upload.setData("images", Array.from(e.target.files ?? []))
							})
						]
					}),
					uploadErrors.length > 0 && /* @__PURE__ */ jsx("ul", {
						className: "mt-2 text-sm text-clay",
						role: "alert",
						children: uploadErrors.map((m) => /* @__PURE__ */ jsx("li", { children: m }, m))
					}),
					/* @__PURE__ */ jsx(Button, {
						type: "submit",
						size: "sm",
						className: "mt-3 w-full",
						loading: upload.processing,
						disabled: upload.data.images.length === 0,
						children: "Upload"
					})
				]
			}),
			images.length > 0 && /* @__PURE__ */ jsx("ul", {
				className: "mt-5 space-y-3",
				children: images.map((img, i) => /* @__PURE__ */ jsxs("li", {
					className: "flex gap-3",
					children: [/* @__PURE__ */ jsx("img", {
						src: img.src,
						alt: "",
						className: "size-16 shrink-0 rounded object-cover"
					}), /* @__PURE__ */ jsxs("div", {
						className: "min-w-0 flex-1",
						children: [
							/* @__PURE__ */ jsxs("label", {
								htmlFor: `alt-${img.id}`,
								className: "text-xs text-stone",
								children: ["Description for screen readers", i === 0 ? " (main image)" : ""]
							}),
							/* @__PURE__ */ jsx(Input, {
								id: `alt-${img.id}`,
								value: img.alt,
								maxLength: 160,
								onChange: (e) => {
									setImages(images.map((x) => x.id === img.id ? {
										...x,
										alt: e.target.value
									} : x));
									setDirty(true);
								},
								className: "mt-1 h-9 text-sm"
							}),
							/* @__PURE__ */ jsxs("div", {
								className: "mt-1 flex gap-1",
								children: [
									/* @__PURE__ */ jsx(Button, {
										type: "button",
										variant: "ghost",
										size: "icon-sm",
										disabled: i === 0,
										onClick: () => move(i, -1),
										"aria-label": "Move up",
										children: /* @__PURE__ */ jsx(ArrowUp, { "aria-hidden": "true" })
									}),
									/* @__PURE__ */ jsx(Button, {
										type: "button",
										variant: "ghost",
										size: "icon-sm",
										disabled: i === images.length - 1,
										onClick: () => move(i, 1),
										"aria-label": "Move down",
										children: /* @__PURE__ */ jsx(ArrowDown, { "aria-hidden": "true" })
									}),
									/* @__PURE__ */ jsx(ConfirmDialog, {
										trigger: /* @__PURE__ */ jsx(Button, {
											type: "button",
											variant: "ghost",
											size: "icon-sm",
											"aria-label": "Delete image",
											className: "ml-auto text-clay",
											children: /* @__PURE__ */ jsx(Trash2, { "aria-hidden": "true" })
										}),
										title: "Delete this image?",
										description: "The image file is removed permanently.",
										confirmLabel: "Delete image",
										onConfirm: () => router.delete(`/admin/products/${product.id}/images/${img.id}`, { preserveScroll: true })
									})
								]
							})
						]
					})]
				}, img.id))
			}),
			dirty && /* @__PURE__ */ jsx(Button, {
				size: "sm",
				variant: "secondary",
				className: "mt-4 w-full",
				onClick: () => router.put(`/admin/products/${product.id}/images`, { images: images.map(({ id, alt }) => ({
					id,
					alt
				})) }, { preserveScroll: true }),
				children: "Save image order and descriptions"
			})
		]
	});
}
//#endregion
export { ProductForm as default };
