import { t as useShared } from "./use-shared-BMnpkZPP.js";
import { t as formatMoney } from "./money-CcsjAkm_.js";
import { c as Checkbox, i as Textarea, r as Select, t as Input, v as Button } from "../ssr.js";
import { n as FormErrorSummary, t as Field } from "./field-BVcOZvwI.js";
import { t as OrderTotals } from "./order-totals-CfndwuiF.js";
import { t as CouponForm } from "./coupon-form-kZ8KB7z7.js";
import { Link, router, useForm } from "@inertiajs/react";
import { jsx, jsxs } from "react/jsx-runtime";
import { Banknote, Lock } from "lucide-react";
//#region resources/js/pages/checkout/index.tsx
function Checkout({ idempotencyKey, quote, zones, checkout, country }) {
	const { cart, store, errors: pageErrors } = useShared();
	const lines = (cart?.lines ?? []).filter((l) => !l.issue);
	const currency = store.currency;
	const form = useForm({
		name: "",
		phone: "",
		email: "",
		shipping_zone_id: quote.zone_id ? String(quote.zone_id) : "",
		city: "",
		address: "",
		notes: "",
		privacy: false
	});
	const chooseZone = (id) => {
		form.setData("shipping_zone_id", id);
		router.get("/checkout", id ? { zone: id } : {}, {
			only: ["quote"],
			preserveState: true,
			preserveScroll: true,
			replace: true
		});
	};
	const submit = (e) => {
		e.preventDefault();
		form.transform((data) => ({
			...data,
			idempotency_key: idempotencyKey,
			expected_total: quote.total_minor ?? 0
		}));
		form.post("/checkout", { preserveScroll: true });
	};
	const generalErrors = {
		cart: pageErrors.cart,
		total: pageErrors.total,
		coupon: pageErrors.coupon,
		general: pageErrors.general,
		idempotency_key: pageErrors.idempotency_key
	};
	const isMorocco = country === "MA";
	return /* @__PURE__ */ jsxs("div", {
		className: "container-page py-10 lg:py-14",
		children: [/* @__PURE__ */ jsxs("div", {
			className: "flex flex-wrap items-baseline justify-between gap-4",
			children: [/* @__PURE__ */ jsx("h1", {
				className: "font-display text-display-sm",
				children: "Checkout"
			}), /* @__PURE__ */ jsx(Link, {
				href: "/cart",
				className: "text-sm underline underline-offset-4 hover:text-aloe",
				children: "Back to cart"
			})]
		}), !checkout.open ? /* @__PURE__ */ jsxs("div", {
			className: "mt-8 max-w-xl rounded-lg border border-line bg-white p-6",
			children: [/* @__PURE__ */ jsx("p", {
				className: "font-display text-2xl",
				children: "Ordering is paused"
			}), /* @__PURE__ */ jsx("p", {
				className: "mt-2 text-stone",
				children: checkout.closed_message
			})]
		}) : /* @__PURE__ */ jsxs("form", {
			onSubmit: submit,
			noValidate: true,
			className: "mt-8 grid gap-10 lg:grid-cols-12 lg:gap-14",
			children: [/* @__PURE__ */ jsxs("div", {
				className: "space-y-10 lg:col-span-7",
				children: [
					/* @__PURE__ */ jsx(FormErrorSummary, { errors: generalErrors }),
					/* @__PURE__ */ jsxs("fieldset", {
						className: "space-y-5",
						children: [
							/* @__PURE__ */ jsx("legend", {
								className: "mb-5 font-display text-2xl",
								children: "Your details"
							}),
							/* @__PURE__ */ jsx(Field, {
								label: "Full name",
								name: "name",
								error: form.errors.name,
								required: true,
								children: (p) => /* @__PURE__ */ jsx(Input, {
									...p,
									autoComplete: "name",
									value: form.data.name,
									onChange: (e) => form.setData("name", e.target.value),
									maxLength: 120
								})
							}),
							/* @__PURE__ */ jsx(Field, {
								label: "Phone number",
								name: "phone",
								error: form.errors.phone,
								required: true,
								hint: isMorocco ? "For example 06 12 34 56 78. The courier will call this number." : "The courier will call this number.",
								children: (p) => /* @__PURE__ */ jsx(Input, {
									...p,
									type: "tel",
									inputMode: "tel",
									autoComplete: "tel",
									value: form.data.phone,
									onChange: (e) => form.setData("phone", e.target.value),
									maxLength: 30
								})
							}),
							/* @__PURE__ */ jsx(Field, {
								label: "Email",
								name: "email",
								optional: true,
								error: form.errors.email,
								hint: "Only used for messages about this order.",
								children: (p) => /* @__PURE__ */ jsx(Input, {
									...p,
									type: "email",
									autoComplete: "email",
									value: form.data.email,
									onChange: (e) => form.setData("email", e.target.value),
									maxLength: 255
								})
							})
						]
					}),
					/* @__PURE__ */ jsxs("fieldset", {
						className: "space-y-5",
						children: [
							/* @__PURE__ */ jsx("legend", {
								className: "mb-5 font-display text-2xl",
								children: "Delivery"
							}),
							/* @__PURE__ */ jsx(Field, {
								label: "Delivery area",
								name: "shipping_zone_id",
								error: form.errors.shipping_zone_id,
								required: true,
								children: (p) => /* @__PURE__ */ jsxs(Select, {
									...p,
									value: form.data.shipping_zone_id,
									onChange: (e) => chooseZone(e.target.value),
									children: [/* @__PURE__ */ jsx("option", {
										value: "",
										children: "Choose your area"
									}), zones.map((z) => /* @__PURE__ */ jsxs("option", {
										value: z.id,
										children: [
											z.name,
											": ",
											formatMoney(z.fee_minor, currency),
											z.estimate ? ` (${z.estimate})` : ""
										]
									}, z.id))]
								})
							}),
							/* @__PURE__ */ jsxs("div", {
								className: "grid gap-5 sm:grid-cols-3",
								children: [/* @__PURE__ */ jsx(Field, {
									label: "City",
									name: "city",
									error: form.errors.city,
									required: true,
									className: "sm:col-span-1",
									children: (p) => /* @__PURE__ */ jsx(Input, {
										...p,
										autoComplete: "address-level2",
										value: form.data.city,
										onChange: (e) => form.setData("city", e.target.value),
										maxLength: 80
									})
								}), /* @__PURE__ */ jsx(Field, {
									label: "Address",
									name: "address",
									error: form.errors.address,
									required: true,
									hint: "Street, number, building, floor.",
									className: "sm:col-span-2",
									children: (p) => /* @__PURE__ */ jsx(Input, {
										...p,
										autoComplete: "street-address",
										value: form.data.address,
										onChange: (e) => form.setData("address", e.target.value),
										maxLength: 255
									})
								})]
							}),
							/* @__PURE__ */ jsx(Field, {
								label: "Delivery notes",
								name: "notes",
								optional: true,
								error: form.errors.notes,
								hint: "Landmark, best time to call, anything that helps the courier.",
								children: (p) => /* @__PURE__ */ jsx(Textarea, {
									...p,
									rows: 3,
									value: form.data.notes,
									onChange: (e) => form.setData("notes", e.target.value),
									maxLength: 500
								})
							})
						]
					}),
					/* @__PURE__ */ jsx("div", {
						className: "rounded-lg bg-sand p-5",
						children: /* @__PURE__ */ jsxs("div", {
							className: "flex gap-4",
							children: [/* @__PURE__ */ jsx(Banknote, {
								className: "mt-0.5 size-6 shrink-0 text-dune-deep",
								strokeWidth: 1.5,
								"aria-hidden": "true"
							}), /* @__PURE__ */ jsxs("div", { children: [
								/* @__PURE__ */ jsx("p", {
									className: "font-medium",
									children: "Payment: cash on delivery"
								}),
								/* @__PURE__ */ jsx("p", {
									className: "mt-1 text-[0.95rem] text-ink/80",
									children: checkout.cod_instructions
								}),
								checkout.confirmation_note && /* @__PURE__ */ jsx("p", {
									className: "mt-1 text-[0.95rem] text-ink/80",
									children: checkout.confirmation_note
								})
							] })]
						})
					}),
					/* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsxs("div", {
						className: "flex items-start gap-3",
						children: [/* @__PURE__ */ jsx(Checkbox, {
							id: "privacy",
							checked: form.data.privacy,
							onCheckedChange: (v) => form.setData("privacy", v === true),
							"aria-invalid": form.errors.privacy ? true : void 0,
							"aria-describedby": form.errors.privacy ? "privacy-error" : void 0,
							className: "mt-0.5"
						}), /* @__PURE__ */ jsxs("label", {
							htmlFor: "privacy",
							className: "text-[0.95rem]",
							children: [
								"I agree that my details are used to deliver this order, as described in the",
								" ",
								/* @__PURE__ */ jsx("a", {
									href: "/privacy-policy",
									target: "_blank",
									rel: "noopener",
									className: "underline underline-offset-4",
									children: "privacy policy"
								}),
								"."
							]
						})]
					}), form.errors.privacy && /* @__PURE__ */ jsx("p", {
						id: "privacy-error",
						className: "mt-2 text-sm text-clay",
						role: "alert",
						children: form.errors.privacy
					})] }),
					/* @__PURE__ */ jsx("div", {
						className: "lg:hidden",
						children: /* @__PURE__ */ jsx(SubmitBlock, {
							processing: form.processing,
							total: quote.total_minor,
							currency
						})
					})
				]
			}), /* @__PURE__ */ jsx("aside", {
				"aria-label": "Order summary",
				className: "lg:col-span-5",
				children: /* @__PURE__ */ jsxs("div", {
					className: "rounded-lg border border-line bg-white p-6 lg:sticky lg:top-28",
					children: [
						/* @__PURE__ */ jsx("h2", {
							className: "font-display text-2xl",
							children: "Your order"
						}),
						/* @__PURE__ */ jsx("ul", {
							className: "mt-4 divide-y divide-line border-y border-line",
							children: lines.map((l) => /* @__PURE__ */ jsxs("li", {
								className: "flex justify-between gap-4 py-3 text-[0.95rem]",
								children: [/* @__PURE__ */ jsxs("span", { children: [
									l.product_name,
									l.variant_name && /* @__PURE__ */ jsxs("span", {
										className: "text-stone",
										children: [" — ", l.variant_name]
									}),
									/* @__PURE__ */ jsxs("span", {
										className: "text-stone",
										children: [" × ", l.quantity]
									})
								] }), /* @__PURE__ */ jsx("span", {
									className: "shrink-0 tabular-nums",
									children: formatMoney(l.line_total_minor, currency)
								})]
							}, l.id))
						}),
						/* @__PURE__ */ jsx("div", {
							className: "mt-5",
							children: /* @__PURE__ */ jsx(CouponForm, {
								code: quote.coupon_code ?? cart?.coupon_code ?? null,
								error: quote.coupon_error
							})
						}),
						/* @__PURE__ */ jsx(OrderTotals, {
							className: "mt-6",
							currency,
							subtotal: quote.subtotal_minor,
							discount: quote.discount_minor,
							shipping: quote.shipping_minor,
							total: quote.total_minor,
							couponCode: quote.coupon_code
						}),
						quote.free_shipping_remaining_minor !== null && quote.free_shipping_remaining_minor > 0 && /* @__PURE__ */ jsxs("p", {
							className: "mt-3 text-sm text-stone",
							children: [
								"Add ",
								formatMoney(quote.free_shipping_remaining_minor, currency),
								" more for free delivery to this area."
							]
						}),
						/* @__PURE__ */ jsx("div", {
							className: "mt-6 hidden lg:block",
							children: /* @__PURE__ */ jsx(SubmitBlock, {
								processing: form.processing,
								total: quote.total_minor,
								currency
							})
						})
					]
				})
			})]
		})]
	});
}
function SubmitBlock({ processing, total, currency }) {
	return /* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx(Button, {
		type: "submit",
		size: "lg",
		className: "w-full",
		loading: processing,
		children: "Place order"
	}), /* @__PURE__ */ jsxs("p", {
		className: "mt-3 flex items-center justify-center gap-2 text-center text-sm text-stone",
		children: [/* @__PURE__ */ jsx(Lock, {
			className: "size-3.5",
			"aria-hidden": "true"
		}), total !== null ? `You will pay ${formatMoney(total, currency)} in cash on delivery.` : "Choose a delivery area to see your total."]
	})] });
}
//#endregion
export { Checkout as default };
