import { t as Input, v as Button } from "../ssr.js";
import { t as Field } from "./field-BVcOZvwI.js";
import { Head, useForm } from "@inertiajs/react";
import { jsx, jsxs } from "react/jsx-runtime";
//#region resources/js/pages/admin/auth/reset-password.tsx
function ResetPassword({ email, token }) {
	const form = useForm({
		token,
		email,
		password: "",
		password_confirmation: ""
	});
	const submit = (e) => {
		e.preventDefault();
		form.post("/admin/reset-password", { onFinish: () => form.reset("password", "password_confirmation") });
	};
	return /* @__PURE__ */ jsxs("div", {
		className: "rounded-lg border border-line bg-white p-8",
		children: [
			/* @__PURE__ */ jsx(Head, { title: "Choose a new password — Admin" }),
			/* @__PURE__ */ jsx("h1", {
				className: "font-display text-3xl",
				children: "Choose a new password"
			}),
			/* @__PURE__ */ jsxs("form", {
				onSubmit: submit,
				className: "mt-6 space-y-5",
				noValidate: true,
				children: [
					/* @__PURE__ */ jsx(Field, {
						label: "Email",
						name: "email",
						error: form.errors.email,
						required: true,
						children: (p) => /* @__PURE__ */ jsx(Input, {
							...p,
							type: "email",
							autoComplete: "username",
							value: form.data.email,
							onChange: (e) => form.setData("email", e.target.value)
						})
					}),
					/* @__PURE__ */ jsx(Field, {
						label: "New password",
						name: "password",
						error: form.errors.password,
						hint: "At least 12 characters, with upper and lower case letters and a number.",
						required: true,
						children: (p) => /* @__PURE__ */ jsx(Input, {
							...p,
							type: "password",
							autoComplete: "new-password",
							value: form.data.password,
							onChange: (e) => form.setData("password", e.target.value)
						})
					}),
					/* @__PURE__ */ jsx(Field, {
						label: "Confirm new password",
						name: "password_confirmation",
						error: form.errors.password_confirmation,
						required: true,
						children: (p) => /* @__PURE__ */ jsx(Input, {
							...p,
							type: "password",
							autoComplete: "new-password",
							value: form.data.password_confirmation,
							onChange: (e) => form.setData("password_confirmation", e.target.value)
						})
					}),
					/* @__PURE__ */ jsx(Button, {
						type: "submit",
						className: "w-full",
						loading: form.processing,
						children: "Save new password"
					})
				]
			})
		]
	});
}
//#endregion
export { ResetPassword as default };
