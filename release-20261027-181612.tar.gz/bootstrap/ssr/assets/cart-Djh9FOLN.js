import { t as useShared } from "./use-shared-BMnpkZPP.js";
import { t as formatMoney } from "./money-CcsjAkm_.js";
import { u as CartLines, v as Button } from "../ssr.js";
import { t as CouponForm } from "./coupon-form-kZ8KB7z7.js";
import { Link } from "@inertiajs/react";
import { jsx, jsxs } from "react/jsx-runtime";
//#region resources/js/pages/cart.tsx
function Cart() {
	const { cart, store, navigation = [] } = useShared();
	const lines = cart?.lines ?? [];
	return /* @__PURE__ */ jsxs("div", {
		className: "container-page py-10 lg:py-16",
		children: [/* @__PURE__ */ jsx("h1", {
			className: "font-display text-display-sm",
			children: "Your cart"
		}), lines.length === 0 ? /* @__PURE__ */ jsxs("div", {
			className: "mt-10 max-w-xl",
			children: [/* @__PURE__ */ jsx("p", {
				className: "text-lg text-stone",
				children: "Your cart is empty. Start with one of our collections."
			}), /* @__PURE__ */ jsx("ul", {
				className: "mt-6 flex flex-wrap gap-2",
				children: navigation.map((c) => /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsx(Link, {
					href: `/shop/${c.slug}`,
					className: "inline-flex h-10 items-center rounded-full border border-line bg-white px-4 hover:border-ink",
					children: c.name
				}) }, c.slug))
			})]
		}) : /* @__PURE__ */ jsxs("div", {
			className: "mt-8 grid gap-10 lg:grid-cols-12 lg:gap-14",
			children: [/* @__PURE__ */ jsx("section", {
				"aria-label": "Items",
				className: "lg:col-span-7",
				children: /* @__PURE__ */ jsx(CartLines, { lines })
			}), /* @__PURE__ */ jsx("aside", {
				"aria-label": "Summary",
				className: "lg:col-span-5",
				children: /* @__PURE__ */ jsxs("div", {
					className: "rounded-lg border border-line bg-white p-6 lg:sticky lg:top-28",
					children: [
						/* @__PURE__ */ jsxs("div", {
							className: "flex items-baseline justify-between",
							children: [/* @__PURE__ */ jsx("span", {
								className: "text-stone",
								children: "Subtotal"
							}), /* @__PURE__ */ jsx("span", {
								className: "font-display text-3xl tabular-nums",
								children: formatMoney(cart?.subtotal_minor ?? 0, store.currency)
							})]
						}),
						/* @__PURE__ */ jsx("p", {
							className: "mt-2 text-sm text-stone",
							children: "The delivery fee for your area is shown at checkout. You pay in cash when your order arrives."
						}),
						/* @__PURE__ */ jsx("div", {
							className: "mt-6",
							children: /* @__PURE__ */ jsx(CouponForm, { code: cart?.coupon_code ?? null })
						}),
						cart?.has_issues && /* @__PURE__ */ jsx("p", {
							className: "mt-6 rounded-(--radius-control) bg-clay-soft px-4 py-3 text-sm text-clay",
							role: "alert",
							children: "Some items need your attention before you can check out."
						}),
						/* @__PURE__ */ jsx(Button, {
							asChild: true,
							size: "lg",
							className: `mt-6 w-full ${cart?.has_issues ? "pointer-events-none opacity-50" : ""}`,
							children: /* @__PURE__ */ jsx(Link, {
								href: "/checkout",
								"aria-disabled": cart?.has_issues || void 0,
								children: "Go to checkout"
							})
						}),
						/* @__PURE__ */ jsx(Link, {
							href: "/shop",
							className: "mt-4 block text-center text-sm underline underline-offset-4 hover:text-aloe",
							children: "Continue shopping"
						})
					]
				})
			})]
		})]
	});
}
//#endregion
export { Cart as default };
