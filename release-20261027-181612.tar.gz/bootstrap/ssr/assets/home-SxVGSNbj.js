import { i as Textarea, l as Switch, n as Label, r as Select, t as Input, v as Button } from "../ssr.js";
import { a as Panel, r as PageHeader } from "./ui-DQeK8Yrd.js";
import { t as Field } from "./field-BVcOZvwI.js";
import { t as ContentImage } from "./content-image-DdCE0VuA.js";
import { useForm } from "@inertiajs/react";
import { Fragment, jsx, jsxs } from "react/jsx-runtime";
import { Plus, Trash2 } from "lucide-react";
//#region resources/js/pages/admin/content/home.tsx
function ContentHome({ home, announcement, products }) {
	const form = useForm({
		announcement: { ...announcement },
		home: {
			hero_heading: home.hero_heading,
			hero_text: home.hero_text,
			hero_attribution: home.hero_attribution,
			hero_image_alt: home.hero_image_alt,
			intro_heading: home.intro_heading,
			intro_text: home.intro_text,
			featured_heading: home.featured_heading,
			ritual_enabled: home.ritual_enabled,
			ritual_heading: home.ritual_heading,
			ritual_intro: home.ritual_intro,
			ritual_steps: home.ritual_steps,
			newsletter_enabled: home.newsletter_enabled
		}
	});
	const err = (k) => form.errors[k];
	const setHome = (key, value) => form.setData("home", {
		...form.data.home,
		[key]: value
	});
	const setAnn = (key, value) => form.setData("announcement", {
		...form.data.announcement,
		[key]: value
	});
	const submit = (e) => {
		e.preventDefault();
		form.put("/admin/content/home", { preserveScroll: true });
	};
	return /* @__PURE__ */ jsxs(Fragment, { children: [/* @__PURE__ */ jsx(PageHeader, {
		title: "Home page",
		description: "Text and images on the home page, and the announcement bar shown on every page."
	}), /* @__PURE__ */ jsxs("div", {
		className: "space-y-6",
		children: [/* @__PURE__ */ jsx(Panel, {
			title: "Hero photograph",
			children: /* @__PURE__ */ jsx(ContentImage, {
				slot: "hero",
				image: home.hero_image,
				isCustom: home.has_custom_image
			})
		}), /* @__PURE__ */ jsxs("form", {
			onSubmit: submit,
			noValidate: true,
			className: "space-y-6",
			children: [
				/* @__PURE__ */ jsx(Panel, {
					title: "Announcement bar",
					actions: /* @__PURE__ */ jsx(Switch, {
						"aria-label": "Show announcement bar",
						checked: form.data.announcement.enabled,
						onCheckedChange: (v) => setAnn("enabled", v)
					}),
					children: /* @__PURE__ */ jsxs("div", {
						className: "grid gap-4 sm:grid-cols-3",
						children: [
							/* @__PURE__ */ jsx(Field, {
								label: "Message",
								name: "announcement.text",
								error: err("announcement.text"),
								className: "sm:col-span-3",
								children: (p) => /* @__PURE__ */ jsx(Input, {
									...p,
									value: form.data.announcement.text,
									onChange: (e) => setAnn("text", e.target.value),
									maxLength: 140
								})
							}),
							/* @__PURE__ */ jsx(Field, {
								label: "Link text",
								name: "announcement.link_label",
								error: err("announcement.link_label"),
								optional: true,
								children: (p) => /* @__PURE__ */ jsx(Input, {
									...p,
									value: form.data.announcement.link_label,
									onChange: (e) => setAnn("link_label", e.target.value),
									maxLength: 40
								})
							}),
							/* @__PURE__ */ jsx(Field, {
								label: "Link",
								name: "announcement.link_url",
								error: err("announcement.link_url"),
								hint: "e.g. /shop/beauty",
								optional: true,
								className: "sm:col-span-2",
								children: (p) => /* @__PURE__ */ jsx(Input, {
									...p,
									value: form.data.announcement.link_url,
									onChange: (e) => setAnn("link_url", e.target.value),
									maxLength: 255
								})
							})
						]
					})
				}),
				/* @__PURE__ */ jsx(Panel, {
					title: "Hero",
					children: /* @__PURE__ */ jsxs("div", {
						className: "space-y-4",
						children: [
							/* @__PURE__ */ jsx(Field, {
								label: "Headline",
								name: "home.hero_heading",
								error: err("home.hero_heading"),
								required: true,
								children: (p) => /* @__PURE__ */ jsx(Input, {
									...p,
									value: form.data.home.hero_heading,
									onChange: (e) => setHome("hero_heading", e.target.value),
									maxLength: 120
								})
							}),
							/* @__PURE__ */ jsx(Field, {
								label: "Quote",
								name: "home.hero_text",
								error: err("home.hero_text"),
								hint: "In the founder’s own words.",
								optional: true,
								children: (p) => /* @__PURE__ */ jsx(Textarea, {
									...p,
									rows: 3,
									value: form.data.home.hero_text,
									onChange: (e) => setHome("hero_text", e.target.value),
									maxLength: 400
								})
							}),
							/* @__PURE__ */ jsxs("div", {
								className: "grid gap-4 sm:grid-cols-2",
								children: [/* @__PURE__ */ jsx(Field, {
									label: "Quote attribution",
									name: "home.hero_attribution",
									error: err("home.hero_attribution"),
									optional: true,
									children: (p) => /* @__PURE__ */ jsx(Input, {
										...p,
										value: form.data.home.hero_attribution,
										onChange: (e) => setHome("hero_attribution", e.target.value),
										maxLength: 80
									})
								}), /* @__PURE__ */ jsx(Field, {
									label: "Photograph description",
									name: "home.hero_image_alt",
									error: err("home.hero_image_alt"),
									hint: "For screen readers and search engines.",
									required: true,
									children: (p) => /* @__PURE__ */ jsx(Input, {
										...p,
										value: form.data.home.hero_image_alt,
										onChange: (e) => setHome("hero_image_alt", e.target.value),
										maxLength: 160
									})
								})]
							})
						]
					})
				}),
				/* @__PURE__ */ jsx(Panel, {
					title: "Introduction and featured products",
					children: /* @__PURE__ */ jsxs("div", {
						className: "space-y-4",
						children: [
							/* @__PURE__ */ jsx(Field, {
								label: "Introduction heading",
								name: "home.intro_heading",
								error: err("home.intro_heading"),
								optional: true,
								children: (p) => /* @__PURE__ */ jsx(Input, {
									...p,
									value: form.data.home.intro_heading,
									onChange: (e) => setHome("intro_heading", e.target.value),
									maxLength: 120
								})
							}),
							/* @__PURE__ */ jsx(Field, {
								label: "Introduction text",
								name: "home.intro_text",
								error: err("home.intro_text"),
								optional: true,
								children: (p) => /* @__PURE__ */ jsx(Textarea, {
									...p,
									rows: 3,
									value: form.data.home.intro_text,
									onChange: (e) => setHome("intro_text", e.target.value),
									maxLength: 600
								})
							}),
							/* @__PURE__ */ jsx(Field, {
								label: "Featured products heading",
								name: "home.featured_heading",
								error: err("home.featured_heading"),
								hint: "Choose which products appear with the “Featured” switch on each product.",
								required: true,
								children: (p) => /* @__PURE__ */ jsx(Input, {
									...p,
									value: form.data.home.featured_heading,
									onChange: (e) => setHome("featured_heading", e.target.value),
									maxLength: 80
								})
							})
						]
					})
				}),
				/* @__PURE__ */ jsx(Panel, {
					title: "Routine section",
					description: "An optional step-by-step routine made of published products.",
					actions: /* @__PURE__ */ jsx(Switch, {
						"aria-label": "Show routine section",
						checked: form.data.home.ritual_enabled,
						onCheckedChange: (v) => setHome("ritual_enabled", v)
					}),
					children: /* @__PURE__ */ jsxs("div", {
						className: "space-y-4",
						children: [
							/* @__PURE__ */ jsxs("div", {
								className: "grid gap-4 sm:grid-cols-2",
								children: [/* @__PURE__ */ jsx(Field, {
									label: "Heading",
									name: "home.ritual_heading",
									error: err("home.ritual_heading"),
									optional: true,
									children: (p) => /* @__PURE__ */ jsx(Input, {
										...p,
										value: form.data.home.ritual_heading,
										onChange: (e) => setHome("ritual_heading", e.target.value),
										maxLength: 80
									})
								}), /* @__PURE__ */ jsx(Field, {
									label: "Introduction",
									name: "home.ritual_intro",
									error: err("home.ritual_intro"),
									optional: true,
									children: (p) => /* @__PURE__ */ jsx(Input, {
										...p,
										value: form.data.home.ritual_intro,
										onChange: (e) => setHome("ritual_intro", e.target.value),
										maxLength: 400
									})
								})]
							}),
							/* @__PURE__ */ jsx("ol", {
								className: "space-y-2",
								children: form.data.home.ritual_steps.map((step, i) => /* @__PURE__ */ jsxs("li", {
									className: "flex flex-wrap items-center gap-2",
									children: [
										/* @__PURE__ */ jsxs("span", {
											className: "w-6 text-sm text-stone",
											children: [i + 1, "."]
										}),
										/* @__PURE__ */ jsx(Select, {
											"aria-label": `Step ${i + 1} product`,
											value: step.product_id,
											onChange: (e) => setHome("ritual_steps", form.data.home.ritual_steps.map((s, j) => j === i ? {
												...s,
												product_id: Number(e.target.value)
											} : s)),
											className: "min-w-56",
											children: products.map((p) => /* @__PURE__ */ jsx("option", {
												value: p.id,
												children: p.name
											}, p.id))
										}),
										/* @__PURE__ */ jsx(Input, {
											"aria-label": `Step ${i + 1} note`,
											placeholder: "Short note, e.g. Morning",
											value: step.note,
											onChange: (e) => setHome("ritual_steps", form.data.home.ritual_steps.map((s, j) => j === i ? {
												...s,
												note: e.target.value
											} : s)),
											maxLength: 160,
											className: "flex-1"
										}),
										/* @__PURE__ */ jsx(Button, {
											type: "button",
											variant: "ghost",
											size: "icon",
											"aria-label": `Remove step ${i + 1}`,
											onClick: () => setHome("ritual_steps", form.data.home.ritual_steps.filter((_, j) => j !== i)),
											children: /* @__PURE__ */ jsx(Trash2, { "aria-hidden": "true" })
										})
									]
								}, i))
							}),
							products.length === 0 ? /* @__PURE__ */ jsx("p", {
								className: "text-sm text-stone",
								children: "Publish products first to build a routine."
							}) : form.data.home.ritual_steps.length < 5 && /* @__PURE__ */ jsxs(Button, {
								type: "button",
								variant: "ghost",
								size: "sm",
								onClick: () => setHome("ritual_steps", [...form.data.home.ritual_steps, {
									product_id: products[0].id,
									note: ""
								}]),
								children: [/* @__PURE__ */ jsx(Plus, { "aria-hidden": "true" }), " Add step"]
							})
						]
					})
				}),
				/* @__PURE__ */ jsx(Panel, {
					title: "Newsletter",
					children: /* @__PURE__ */ jsxs("div", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ jsx(Switch, {
							id: "newsletter",
							checked: form.data.home.newsletter_enabled,
							onCheckedChange: (v) => setHome("newsletter_enabled", v)
						}), /* @__PURE__ */ jsx(Label, {
							htmlFor: "newsletter",
							className: "font-normal",
							children: "Show the newsletter sign-up in the footer"
						})]
					})
				}),
				/* @__PURE__ */ jsx("div", {
					className: "sticky bottom-0 z-10 flex justify-end border-t border-line bg-panel/95 py-3 backdrop-blur",
					children: /* @__PURE__ */ jsx(Button, {
						type: "submit",
						loading: form.processing,
						children: "Save home page"
					})
				})
			]
		})]
	})] });
}
//#endregion
export { ContentHome as default };
