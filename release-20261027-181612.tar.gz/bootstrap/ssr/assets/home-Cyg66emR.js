import { t as cn } from "./utils-BqvNF826.js";
import { f as Motif, p as ResponsiveImage, v as Button } from "../ssr.js";
import { i as AccordionTrigger, n as AccordionContent, r as AccordionItem, t as Accordion } from "./accordion-CjQ_fweI.js";
import { n as ProductCard } from "./product-card-Czb8w07c.js";
import { t as SectionHeading } from "./section-heading-DbvWb44b.js";
import { Link } from "@inertiajs/react";
import { Fragment, jsx, jsxs } from "react/jsx-runtime";
import { Banknote, PackageSearch, UserRoundCheck } from "lucide-react";
//#region resources/js/pages/home.tsx
function Home({ hero, intro, featuredHeading, featured, bestsellers, categories, ritual, journeys, faqs }) {
	return /* @__PURE__ */ jsxs(Fragment, { children: [
		/* @__PURE__ */ jsxs("section", {
			className: "container-page grid items-center gap-10 pt-10 pb-16 lg:grid-cols-12 lg:gap-8 lg:pt-16 lg:pb-24",
			children: [/* @__PURE__ */ jsxs("div", {
				className: "lg:col-span-7",
				children: [
					/* @__PURE__ */ jsx("h1", {
						className: "font-display text-display-xl text-balance",
						children: hero.heading
					}),
					hero.text && /* @__PURE__ */ jsxs("figure", {
						className: "mt-8 max-w-xl border-l border-dune pl-6",
						children: [/* @__PURE__ */ jsx("blockquote", {
							className: "font-serif text-xl leading-relaxed text-ink italic sm:text-[1.35rem]",
							children: hero.text
						}), hero.attribution && /* @__PURE__ */ jsx("figcaption", {
							className: "mt-3 text-sm text-stone",
							children: hero.attribution
						})]
					}),
					/* @__PURE__ */ jsxs("div", {
						className: "mt-10 flex flex-wrap items-center gap-x-6 gap-y-4",
						children: [/* @__PURE__ */ jsx(Button, {
							asChild: true,
							size: "lg",
							children: /* @__PURE__ */ jsx(Link, {
								href: "/shop",
								children: "Shop the collection"
							})
						}), /* @__PURE__ */ jsx(Link, {
							href: "/our-story",
							className: "text-[0.95rem] font-medium underline underline-offset-4 hover:text-aloe",
							children: "Read our story"
						})]
					})
				]
			}), /* @__PURE__ */ jsx("div", {
				className: "mx-auto w-full max-w-sm sm:max-w-md lg:col-span-5 lg:max-w-none",
				children: /* @__PURE__ */ jsx("div", {
					className: "arch aspect-[3/4] bg-sand motion-safe:animate-arch-reveal",
					children: /* @__PURE__ */ jsx(ResponsiveImage, {
						image: hero.image,
						sizes: "(min-width: 1024px) 40vw, (min-width: 640px) 28rem, 90vw",
						priority: true
					})
				})
			})]
		}),
		/* @__PURE__ */ jsx("section", {
			"aria-label": "How ordering works",
			className: "border-y border-line bg-white/60",
			children: /* @__PURE__ */ jsx("ul", {
				className: "container-page grid gap-6 py-8 sm:grid-cols-3",
				children: [
					{
						icon: Banknote,
						title: "Pay in cash on delivery",
						text: "No card or online payment needed."
					},
					{
						icon: UserRoundCheck,
						title: "No account needed",
						text: "Order with your name, phone and address."
					},
					{
						icon: PackageSearch,
						title: "Follow your order",
						text: "Use your order reference to check its status."
					}
				].map(({ icon: Icon, title, text }) => /* @__PURE__ */ jsxs("li", {
					className: "flex items-start gap-4",
					children: [/* @__PURE__ */ jsx(Icon, {
						className: "mt-0.5 size-6 shrink-0 text-dune",
						strokeWidth: 1.5,
						"aria-hidden": "true"
					}), /* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx("p", {
						className: "font-medium",
						children: title
					}), /* @__PURE__ */ jsx("p", {
						className: "text-sm text-stone",
						children: text
					})] })]
				}, title))
			})
		}),
		(intro.heading || intro.text) && /* @__PURE__ */ jsx("section", {
			className: "container-page py-20 lg:py-28",
			children: /* @__PURE__ */ jsxs("div", {
				className: "grid gap-6 lg:grid-cols-12",
				children: [/* @__PURE__ */ jsx("h2", {
					className: "font-display text-display text-balance lg:col-span-7",
					children: intro.heading
				}), intro.text && /* @__PURE__ */ jsx("p", {
					className: "font-serif text-editorial text-stone lg:col-span-4 lg:col-start-9 lg:self-end",
					children: intro.text
				})]
			})
		}),
		categories.length > 0 && /* @__PURE__ */ jsxs("section", {
			"aria-labelledby": "categories-heading",
			className: "container-page pb-20 lg:pb-28",
			children: [/* @__PURE__ */ jsx("h2", {
				id: "categories-heading",
				className: "sr-only",
				children: "Shop by category"
			}), /* @__PURE__ */ jsx("ul", {
				className: "grid grid-cols-2 gap-3 sm:gap-4 lg:grid-cols-4 lg:gap-5",
				children: categories.map((c, i) => /* @__PURE__ */ jsx("li", {
					className: cn(i % 2 === 1 && "lg:translate-y-12"),
					children: /* @__PURE__ */ jsxs(Link, {
						href: `/shop/${c.slug}`,
						className: "group flex aspect-[3/4] flex-col justify-between p-5 transition-colors sm:p-7",
						style: { backgroundColor: c.tint },
						children: [/* @__PURE__ */ jsx("span", {
							className: "block w-14 text-dune transition-transform duration-500 ease-(--ease-out-soft) motion-safe:group-hover:-translate-y-1 sm:w-20",
							children: /* @__PURE__ */ jsx(Motif, { name: c.motif })
						}), /* @__PURE__ */ jsxs("span", { children: [
							/* @__PURE__ */ jsx("span", {
								className: "block font-display text-2xl leading-tight sm:text-3xl",
								children: c.name
							}),
							c.tagline && /* @__PURE__ */ jsx("span", {
								className: "mt-2 hidden text-sm text-stone sm:block",
								children: c.tagline
							}),
							/* @__PURE__ */ jsx("span", {
								className: "mt-3 inline-block text-sm font-medium underline-offset-4 group-hover:underline",
								children: c.product_count > 0 ? `${c.product_count} products` : "Coming soon"
							})
						] })]
					})
				}, c.slug))
			})]
		}),
		featured.length > 0 && /* @__PURE__ */ jsxs("section", {
			className: "container-page pt-8 pb-20 lg:pt-16",
			children: [/* @__PURE__ */ jsx(SectionHeading, {
				title: featuredHeading,
				link: {
					href: "/shop",
					label: "See all products"
				}
			}), /* @__PURE__ */ jsx("div", {
				className: "mt-10 grid grid-cols-2 gap-x-4 gap-y-10 sm:gap-x-6 lg:grid-cols-4",
				children: featured.map((p) => /* @__PURE__ */ jsx(ProductCard, { product: p }, p.id))
			})]
		}),
		ritual && /* @__PURE__ */ jsx("section", {
			className: "bg-sand py-20 lg:py-28",
			children: /* @__PURE__ */ jsxs("div", {
				className: "container-page",
				children: [/* @__PURE__ */ jsx(SectionHeading, {
					title: ritual.heading,
					intro: ritual.intro || void 0
				}), /* @__PURE__ */ jsx("ol", {
					className: "mt-12 grid gap-10 sm:grid-cols-2 lg:grid-cols-4",
					children: ritual.steps.map((step, i) => /* @__PURE__ */ jsxs("li", { children: [/* @__PURE__ */ jsxs("p", {
						className: "mb-4 flex items-baseline gap-3",
						children: [/* @__PURE__ */ jsx("span", {
							className: "font-display text-4xl text-dune",
							children: i + 1
						}), step.note && /* @__PURE__ */ jsx("span", {
							className: "text-sm text-stone",
							children: step.note
						})]
					}), /* @__PURE__ */ jsx(ProductCard, { product: step.product })] }, step.product.id))
				})]
			})
		}),
		bestsellers.length > 0 && /* @__PURE__ */ jsxs("section", {
			className: "container-page py-20",
			children: [/* @__PURE__ */ jsx(SectionHeading, {
				title: "Bestsellers",
				link: {
					href: "/shop",
					label: "Browse the shop"
				}
			}), /* @__PURE__ */ jsx("div", {
				className: "mt-10 grid grid-cols-2 gap-x-4 gap-y-10 sm:gap-x-6 lg:grid-cols-4",
				children: bestsellers.map((p) => /* @__PURE__ */ jsx(ProductCard, { product: p }, p.id))
			})]
		}),
		/* @__PURE__ */ jsx("section", {
			className: "bg-sand py-20 lg:py-28",
			children: /* @__PURE__ */ jsxs("div", {
				className: "container-page grid gap-12 lg:grid-cols-12",
				children: [/* @__PURE__ */ jsxs("div", {
					className: "lg:col-span-5",
					children: [
						/* @__PURE__ */ jsx("h2", {
							className: "font-display text-display text-balance",
							children: "From London to Marrakech"
						}),
						/* @__PURE__ */ jsx("p", {
							className: "mt-6 font-serif text-editorial italic",
							children: "“I wasn’t looking for a business. I was simply looking for answers.”"
						}),
						/* @__PURE__ */ jsx(Button, {
							asChild: true,
							variant: "secondary",
							className: "mt-8",
							children: /* @__PURE__ */ jsx(Link, {
								href: "/our-story",
								children: "Read the founder’s story"
							})
						})
					]
				}), /* @__PURE__ */ jsx("ul", {
					className: "grid gap-8 sm:grid-cols-3 lg:col-span-6 lg:col-start-7 lg:grid-cols-1 lg:gap-0 lg:divide-y lg:divide-dune/40",
					children: journeys.map((j) => /* @__PURE__ */ jsx("li", {
						className: "lg:py-7 lg:first:pt-0",
						children: /* @__PURE__ */ jsxs(Link, {
							href: `/our-story#${j.key}`,
							className: "group block",
							children: [/* @__PURE__ */ jsx("h3", {
								className: "font-display text-2xl group-hover:text-aloe",
								children: j.title
							}), /* @__PURE__ */ jsx("p", {
								className: "mt-2 font-serif text-stone",
								children: j.excerpt
							})]
						})
					}, j.key))
				})]
			})
		}),
		faqs.length > 0 && /* @__PURE__ */ jsxs("section", {
			className: "container-page grid gap-10 pt-20 lg:grid-cols-12 lg:pt-28",
			children: [/* @__PURE__ */ jsxs("div", {
				className: "lg:col-span-4",
				children: [/* @__PURE__ */ jsx("h2", {
					className: "font-display text-display-sm",
					children: "Questions before you order"
				}), /* @__PURE__ */ jsx(Link, {
					href: "/faq",
					className: "mt-4 inline-block font-medium underline underline-offset-4 hover:text-aloe",
					children: "All questions"
				})]
			}), /* @__PURE__ */ jsx(Accordion, {
				type: "single",
				collapsible: true,
				className: "border-t border-line lg:col-span-7 lg:col-start-6",
				children: faqs.map((f) => /* @__PURE__ */ jsxs(AccordionItem, {
					value: String(f.id),
					children: [/* @__PURE__ */ jsx(AccordionTrigger, { children: f.question }), /* @__PURE__ */ jsx(AccordionContent, {
						className: "max-w-prose whitespace-pre-line",
						children: f.answer
					})]
				}, f.id))
			})]
		})
	] });
}
//#endregion
export { Home as default };
