import { t as cn } from "./utils-BqvNF826.js";
import { t as formatMoney } from "./money-CcsjAkm_.js";
import { jsx, jsxs } from "react/jsx-runtime";
//#region resources/js/components/store/order-totals.tsx
/** Subtotal, discount, delivery and the amount payable in cash on delivery. */
function OrderTotals({ currency, subtotal, discount, shipping, total, couponCode, className }) {
	return /* @__PURE__ */ jsxs("dl", {
		className: cn("space-y-2.5 text-[0.95rem]", className),
		children: [
			/* @__PURE__ */ jsxs("div", {
				className: "flex justify-between gap-4",
				children: [/* @__PURE__ */ jsx("dt", {
					className: "text-stone",
					children: "Subtotal"
				}), /* @__PURE__ */ jsx("dd", {
					className: "tabular-nums",
					children: formatMoney(subtotal, currency)
				})]
			}),
			discount > 0 && /* @__PURE__ */ jsxs("div", {
				className: "flex justify-between gap-4",
				children: [/* @__PURE__ */ jsxs("dt", {
					className: "text-stone",
					children: ["Discount", couponCode ? ` (${couponCode})` : ""]
				}), /* @__PURE__ */ jsxs("dd", {
					className: "text-dune-deep tabular-nums",
					children: ["−", formatMoney(discount, currency)]
				})]
			}),
			/* @__PURE__ */ jsxs("div", {
				className: "flex justify-between gap-4",
				children: [/* @__PURE__ */ jsx("dt", {
					className: "text-stone",
					children: "Delivery"
				}), /* @__PURE__ */ jsx("dd", {
					className: "tabular-nums",
					children: shipping === null ? "Choose a delivery area" : shipping === 0 ? "Free" : formatMoney(shipping, currency)
				})]
			}),
			/* @__PURE__ */ jsxs("div", {
				className: "flex items-baseline justify-between gap-4 border-t border-line pt-4",
				children: [/* @__PURE__ */ jsxs("dt", { children: [/* @__PURE__ */ jsx("span", {
					className: "block font-medium",
					children: "To pay on delivery"
				}), /* @__PURE__ */ jsx("span", {
					className: "text-sm text-stone",
					children: "In cash, to the courier"
				})] }), /* @__PURE__ */ jsx("dd", {
					className: "font-display text-3xl tabular-nums",
					children: total === null ? "—" : formatMoney(total, currency)
				})]
			})
		]
	});
}
//#endregion
export { OrderTotals as t };
