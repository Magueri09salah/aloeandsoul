import { t as cn } from "./utils-BqvNF826.js";
import { t as useShared } from "./use-shared-BMnpkZPP.js";
import { t as formatMoney } from "./money-CcsjAkm_.js";
import { c as Checkbox, n as Label, r as Select, t as Input, v as Button } from "../ssr.js";
import { a as Panel, d as th, i as Pagination, l as Table, n as OrderStatusBadge, o as PaymentBadge, r as PageHeader, t as EmptyState, u as td } from "./ui-DQeK8Yrd.js";
import { n as formatDateTime } from "./date-x_Fsbx42.js";
import { Link, router } from "@inertiajs/react";
import { useState } from "react";
import { Fragment, jsx, jsxs } from "react/jsx-runtime";
import { AlertTriangle, Search } from "lucide-react";
//#region resources/js/pages/admin/orders/index.tsx
function OrdersIndex({ orders, filters, statuses, paymentStatuses, counts }) {
	const { store } = useShared();
	const [draft, setDraft] = useState(filters);
	const apply = (next) => {
		const merged = {
			...draft,
			...next
		};
		setDraft(merged);
		const query = Object.fromEntries(Object.entries({
			...merged,
			flagged: merged.flagged ? "1" : ""
		}).filter(([, v]) => v !== null && v !== ""));
		router.get("/admin/orders", query, {
			preserveState: true,
			preserveScroll: true,
			replace: true
		});
	};
	const submit = (e) => {
		e.preventDefault();
		apply({});
	};
	return /* @__PURE__ */ jsxs(Fragment, { children: [
		/* @__PURE__ */ jsx(PageHeader, {
			title: "Orders",
			description: "Every order is paid in cash on delivery. Confirm new orders, then move them through preparation and delivery."
		}),
		/* @__PURE__ */ jsxs("div", {
			className: "mb-4 flex gap-2 overflow-x-auto pb-1",
			role: "group",
			"aria-label": "Filter by status",
			children: [/* @__PURE__ */ jsx(StatusChip, {
				active: !filters.status,
				onClick: () => apply({ status: null }),
				label: "All"
			}), statuses.map((s) => /* @__PURE__ */ jsx(StatusChip, {
				active: filters.status === s.value,
				onClick: () => apply({ status: s.value }),
				label: s.label,
				count: counts[s.value]
			}, s.value))]
		}),
		/* @__PURE__ */ jsxs(Panel, {
			padded: false,
			children: [
				/* @__PURE__ */ jsxs("form", {
					onSubmit: submit,
					className: "grid gap-3 border-b border-line p-4 sm:grid-cols-2 lg:grid-cols-[1fr_auto_auto_auto_auto_auto]",
					children: [
						/* @__PURE__ */ jsxs("div", {
							className: "relative",
							children: [
								/* @__PURE__ */ jsx("label", {
									htmlFor: "q",
									className: "sr-only",
									children: "Search orders"
								}),
								/* @__PURE__ */ jsx(Search, {
									className: "pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-stone",
									"aria-hidden": "true"
								}),
								/* @__PURE__ */ jsx(Input, {
									id: "q",
									type: "search",
									value: draft.q,
									onChange: (e) => setDraft({
										...draft,
										q: e.target.value
									}),
									placeholder: "Reference, name or phone",
									className: "h-10 pl-9"
								})
							]
						}),
						/* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx("label", {
							htmlFor: "payment",
							className: "sr-only",
							children: "Payment"
						}), /* @__PURE__ */ jsxs(Select, {
							id: "payment",
							value: draft.payment ?? "",
							onChange: (e) => apply({ payment: e.target.value || null }),
							className: "h-10",
							children: [/* @__PURE__ */ jsx("option", {
								value: "",
								children: "Any payment status"
							}), paymentStatuses.map((p) => /* @__PURE__ */ jsx("option", {
								value: p.value,
								children: p.label
							}, p.value))]
						})] }),
						/* @__PURE__ */ jsxs("div", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ jsx(Label, {
								htmlFor: "from",
								className: "text-stone",
								children: "From"
							}), /* @__PURE__ */ jsx(Input, {
								id: "from",
								type: "date",
								value: draft.from ?? "",
								onChange: (e) => apply({ from: e.target.value || null }),
								className: "h-10"
							})]
						}),
						/* @__PURE__ */ jsxs("div", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ jsx(Label, {
								htmlFor: "to",
								className: "text-stone",
								children: "To"
							}), /* @__PURE__ */ jsx(Input, {
								id: "to",
								type: "date",
								value: draft.to ?? "",
								onChange: (e) => apply({ to: e.target.value || null }),
								className: "h-10"
							})]
						}),
						/* @__PURE__ */ jsxs("div", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ jsx(Checkbox, {
								id: "flagged",
								checked: draft.flagged,
								onCheckedChange: (v) => apply({ flagged: v === true })
							}), /* @__PURE__ */ jsx(Label, {
								htmlFor: "flagged",
								className: "font-normal whitespace-nowrap",
								children: "Flagged only"
							})]
						}),
						/* @__PURE__ */ jsx(Button, {
							type: "submit",
							size: "sm",
							variant: "secondary",
							className: "h-10",
							children: "Search"
						})
					]
				}),
				orders.data.length === 0 ? /* @__PURE__ */ jsx(EmptyState, {
					title: "No orders found.",
					children: filters.q || filters.status ? "Try a different search or filter." : "Orders placed on the shop will appear here."
				}) : /* @__PURE__ */ jsxs(Table, { children: [/* @__PURE__ */ jsx("thead", { children: /* @__PURE__ */ jsxs("tr", { children: [
					/* @__PURE__ */ jsx("th", {
						className: th,
						children: "Order"
					}),
					/* @__PURE__ */ jsx("th", {
						className: th,
						children: "Customer"
					}),
					/* @__PURE__ */ jsx("th", {
						className: th,
						children: "Status"
					}),
					/* @__PURE__ */ jsx("th", {
						className: th,
						children: "Payment"
					}),
					/* @__PURE__ */ jsx("th", {
						className: cn(th, "text-right"),
						children: "To collect"
					}),
					/* @__PURE__ */ jsx("th", {
						className: th,
						children: "Placed"
					})
				] }) }), /* @__PURE__ */ jsx("tbody", { children: orders.data.map((o) => /* @__PURE__ */ jsxs("tr", {
					className: "hover:bg-panel/50",
					children: [
						/* @__PURE__ */ jsxs("td", {
							className: td,
							children: [/* @__PURE__ */ jsx(Link, {
								href: `/admin/orders/${o.reference}`,
								className: "font-medium whitespace-nowrap underline-offset-4 hover:underline",
								children: o.reference
							}), o.risk && /* @__PURE__ */ jsx(AlertTriangle, {
								className: "ml-1.5 inline size-3.5 text-dune-deep",
								"aria-label": "Flagged for review"
							})]
						}),
						/* @__PURE__ */ jsxs("td", {
							className: td,
							children: [o.customer_name, /* @__PURE__ */ jsxs("span", {
								className: "block text-xs text-stone",
								children: [
									o.customer_phone,
									", ",
									o.city
								]
							})]
						}),
						/* @__PURE__ */ jsx("td", {
							className: td,
							children: /* @__PURE__ */ jsx(OrderStatusBadge, {
								status: o.status,
								label: o.status_label
							})
						}),
						/* @__PURE__ */ jsx("td", {
							className: td,
							children: /* @__PURE__ */ jsx(PaymentBadge, {
								status: o.payment_status,
								label: o.payment_status_label
							})
						}),
						/* @__PURE__ */ jsx("td", {
							className: cn(td, "text-right whitespace-nowrap tabular-nums"),
							children: formatMoney(o.total_minor, o.currency)
						}),
						/* @__PURE__ */ jsx("td", {
							className: cn(td, "whitespace-nowrap text-stone"),
							children: formatDateTime(o.created_at, store.timezone)
						})
					]
				}, o.reference)) })] }),
				/* @__PURE__ */ jsx(Pagination, { page: orders })
			]
		})
	] });
}
function StatusChip({ active, onClick, label, count }) {
	return /* @__PURE__ */ jsxs("button", {
		type: "button",
		onClick,
		"aria-pressed": active,
		className: cn("inline-flex h-9 shrink-0 items-center gap-1.5 rounded-full border px-3.5 text-sm whitespace-nowrap", active ? "border-ink bg-ink text-ivory" : "border-line bg-white hover:border-stone"),
		children: [label, count !== void 0 && count > 0 && /* @__PURE__ */ jsx("span", {
			className: cn("tabular-nums", active ? "text-ivory/70" : "text-stone"),
			children: count
		})]
	});
}
//#endregion
export { OrdersIndex as default };
