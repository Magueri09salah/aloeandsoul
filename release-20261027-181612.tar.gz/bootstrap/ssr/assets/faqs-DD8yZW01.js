import { a as ConfirmDialog, c as Checkbox, i as Textarea, n as Label, o as Dialog, s as DialogContent, t as Input, v as Button } from "../ssr.js";
import { t as Badge } from "./badge-ChM6xC7L.js";
import { a as Panel, r as PageHeader, t as EmptyState } from "./ui-DQeK8Yrd.js";
import { t as Field } from "./field-BVcOZvwI.js";
import { router, useForm } from "@inertiajs/react";
import { useState } from "react";
import { Fragment, jsx, jsxs } from "react/jsx-runtime";
import { Plus } from "lucide-react";
//#region resources/js/pages/admin/faqs/index.tsx
function Faqs({ faqs }) {
	const [editing, setEditing] = useState(null);
	return /* @__PURE__ */ jsxs(Fragment, { children: [
		/* @__PURE__ */ jsx(PageHeader, {
			title: "FAQ",
			description: "Answers shown on the FAQ page. Up to four can also appear on the home page.",
			actions: /* @__PURE__ */ jsxs(Button, {
				onClick: () => setEditing("new"),
				children: [/* @__PURE__ */ jsx(Plus, { "aria-hidden": "true" }), " Add question"]
			})
		}),
		/* @__PURE__ */ jsx(Panel, {
			padded: false,
			children: faqs.length === 0 ? /* @__PURE__ */ jsx(EmptyState, { title: "No questions yet." }) : /* @__PURE__ */ jsx("ul", {
				className: "divide-y divide-line",
				children: faqs.map((f) => /* @__PURE__ */ jsxs("li", {
					className: "flex items-start justify-between gap-4 px-5 py-4",
					children: [/* @__PURE__ */ jsxs("div", {
						className: "min-w-0",
						children: [
							/* @__PURE__ */ jsx("p", {
								className: "font-medium",
								children: f.question
							}),
							/* @__PURE__ */ jsx("p", {
								className: "mt-1 line-clamp-2 text-sm text-stone",
								children: f.answer
							}),
							/* @__PURE__ */ jsxs("div", {
								className: "mt-2 flex gap-2",
								children: [!f.is_published && /* @__PURE__ */ jsx(Badge, {
									tone: "warning",
									children: "Hidden"
								}), f.show_on_home && /* @__PURE__ */ jsx(Badge, {
									tone: "info",
									children: "On home page"
								})]
							})
						]
					}), /* @__PURE__ */ jsx(Button, {
						size: "sm",
						variant: "ghost",
						onClick: () => setEditing(f),
						children: "Edit"
					})]
				}, f.id))
			})
		}),
		/* @__PURE__ */ jsx(Dialog, {
			open: editing !== null,
			onOpenChange: (o) => !o && setEditing(null),
			children: editing !== null && /* @__PURE__ */ jsx(DialogContent, {
				title: editing === "new" ? "New question" : "Edit question",
				className: "max-w-xl",
				children: /* @__PURE__ */ jsx(FaqForm, {
					faq: editing === "new" ? null : editing,
					onDone: () => setEditing(null)
				})
			})
		})
	] });
}
function FaqForm({ faq, onDone }) {
	const form = useForm({
		question: faq?.question ?? "",
		answer: faq?.answer ?? "",
		sort_order: faq?.sort_order ?? 0,
		is_published: faq?.is_published ?? true,
		show_on_home: faq?.show_on_home ?? false
	});
	const submit = (e) => {
		e.preventDefault();
		const opts = {
			preserveScroll: true,
			onSuccess: onDone
		};
		if (faq) form.put(`/admin/faqs/${faq.id}`, opts);
		else form.post("/admin/faqs", opts);
	};
	return /* @__PURE__ */ jsxs("form", {
		onSubmit: submit,
		noValidate: true,
		className: "space-y-4",
		children: [
			/* @__PURE__ */ jsx(Field, {
				label: "Question",
				name: "question",
				error: form.errors.question,
				required: true,
				children: (p) => /* @__PURE__ */ jsx(Input, {
					...p,
					value: form.data.question,
					onChange: (e) => form.setData("question", e.target.value),
					maxLength: 255
				})
			}),
			/* @__PURE__ */ jsx(Field, {
				label: "Answer",
				name: "answer",
				error: form.errors.answer,
				required: true,
				children: (p) => /* @__PURE__ */ jsx(Textarea, {
					...p,
					rows: 5,
					value: form.data.answer,
					onChange: (e) => form.setData("answer", e.target.value),
					maxLength: 3e3
				})
			}),
			/* @__PURE__ */ jsx(Field, {
				label: "Position",
				name: "sort_order",
				error: form.errors.sort_order,
				children: (p) => /* @__PURE__ */ jsx(Input, {
					...p,
					type: "number",
					className: "max-w-28",
					value: form.data.sort_order,
					onChange: (e) => form.setData("sort_order", Number(e.target.value))
				})
			}),
			/* @__PURE__ */ jsxs("div", {
				className: "flex flex-wrap gap-6",
				children: [/* @__PURE__ */ jsxs("div", {
					className: "flex items-center gap-2.5",
					children: [/* @__PURE__ */ jsx(Checkbox, {
						id: "faq-published",
						checked: form.data.is_published,
						onCheckedChange: (v) => form.setData("is_published", v === true)
					}), /* @__PURE__ */ jsx(Label, {
						htmlFor: "faq-published",
						className: "font-normal",
						children: "Published"
					})]
				}), /* @__PURE__ */ jsxs("div", {
					className: "flex items-center gap-2.5",
					children: [/* @__PURE__ */ jsx(Checkbox, {
						id: "faq-home",
						checked: form.data.show_on_home,
						onCheckedChange: (v) => form.setData("show_on_home", v === true)
					}), /* @__PURE__ */ jsx(Label, {
						htmlFor: "faq-home",
						className: "font-normal",
						children: "Show on home page"
					})]
				})]
			}),
			/* @__PURE__ */ jsxs("div", {
				className: "flex justify-between gap-2 pt-2",
				children: [faq ? /* @__PURE__ */ jsx(ConfirmDialog, {
					trigger: /* @__PURE__ */ jsx(Button, {
						type: "button",
						variant: "destructive-outline",
						children: "Delete"
					}),
					title: "Delete this question?",
					description: faq.question,
					confirmLabel: "Delete",
					onConfirm: () => router.delete(`/admin/faqs/${faq.id}`, { onSuccess: onDone })
				}) : /* @__PURE__ */ jsx("span", {}), /* @__PURE__ */ jsx(Button, {
					type: "submit",
					loading: form.processing,
					children: "Save"
				})]
			})
		]
	});
}
//#endregion
export { Faqs as default };
