import { t as cn } from "./utils-BqvNF826.js";
import { Link } from "@inertiajs/react";
import { Fragment, jsx, jsxs } from "react/jsx-runtime";
//#region resources/js/components/store/breadcrumbs.tsx
function Breadcrumbs({ items, className }) {
	return /* @__PURE__ */ jsx("nav", {
		"aria-label": "Breadcrumb",
		className: cn("text-sm text-stone", className),
		children: /* @__PURE__ */ jsx("ol", {
			className: "flex flex-wrap items-center gap-x-2 gap-y-1",
			children: items.map((item, i) => {
				const last = i === items.length - 1;
				const path = new URL(item.url).pathname;
				return /* @__PURE__ */ jsx("li", {
					className: "flex items-center gap-2",
					children: last ? /* @__PURE__ */ jsx("span", {
						"aria-current": "page",
						className: "text-ink",
						children: item.name
					}) : /* @__PURE__ */ jsxs(Fragment, { children: [/* @__PURE__ */ jsx(Link, {
						href: path,
						className: "hover:text-ink hover:underline hover:underline-offset-4",
						children: item.name
					}), /* @__PURE__ */ jsx("span", {
						"aria-hidden": "true",
						className: "text-line",
						children: "/"
					})] })
				}, item.url);
			})
		})
	});
}
//#endregion
export { Breadcrumbs as t };
