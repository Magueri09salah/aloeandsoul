import { t as cn } from "./utils-BqvNF826.js";
import { t as useShared } from "./use-shared-BMnpkZPP.js";
import { n as toDecimalInput, t as formatMoney } from "./money-CcsjAkm_.js";
import { c as Checkbox, i as Textarea, n as Label, o as Dialog, r as Select, s as DialogContent, t as Input, v as Button } from "../ssr.js";
import { a as Panel, d as th, l as Table, n as OrderStatusBadge, o as PaymentBadge, r as PageHeader, u as td } from "./ui-DQeK8Yrd.js";
import { n as formatDateTime } from "./date-x_Fsbx42.js";
import { t as Field } from "./field-BVcOZvwI.js";
import { t as OrderTotals } from "./order-totals-CfndwuiF.js";
import { Link, useForm } from "@inertiajs/react";
import { useState } from "react";
import { Fragment, jsx, jsxs } from "react/jsx-runtime";
import { AlertTriangle, MessageCircle, Phone, Printer } from "lucide-react";
//#region resources/js/pages/admin/orders/show.tsx
var DANGER = [
	"CANCELLED",
	"FAILED_DELIVERY",
	"RETURNED"
];
/** What each move is called on its button. */
var ACTIONS = {
	CONFIRMED: "Confirm order",
	PROCESSING: "Start preparing",
	READY_TO_SHIP: "Mark as packed",
	SHIPPED: "Hand to courier",
	DELIVERED: "Mark as delivered",
	CANCELLED: "Cancel order",
	FAILED_DELIVERY: "Delivery failed",
	RETURNED: "Mark as returned"
};
function OrderShow({ order, canManage }) {
	const { store } = useShared();
	const money = (v) => formatMoney(v, order.currency);
	return /* @__PURE__ */ jsxs(Fragment, { children: [
		/* @__PURE__ */ jsx(PageHeader, {
			back: {
				href: "/admin/orders",
				label: "Orders"
			},
			title: `Order ${order.reference}`,
			description: /* @__PURE__ */ jsxs("span", {
				className: "flex flex-wrap items-center gap-2",
				children: [
					/* @__PURE__ */ jsx(OrderStatusBadge, {
						status: order.status,
						label: order.status_label
					}),
					/* @__PURE__ */ jsx(PaymentBadge, {
						status: order.payment_status,
						label: order.payment_status_label
					}),
					/* @__PURE__ */ jsxs("span", {
						className: "text-sm",
						children: ["Placed ", formatDateTime(order.created_at, store.timezone)]
					})
				]
			}),
			actions: /* @__PURE__ */ jsx(Button, {
				asChild: true,
				variant: "secondary",
				size: "sm",
				children: /* @__PURE__ */ jsxs("a", {
					href: `/admin/orders/${order.reference}/packing-slip`,
					target: "_blank",
					rel: "noopener",
					children: [/* @__PURE__ */ jsx(Printer, { "aria-hidden": "true" }), "Packing slip"]
				})
			})
		}),
		order.risk_flags.length > 0 && /* @__PURE__ */ jsxs("div", {
			className: "mb-6 flex gap-3 rounded-lg border border-dune/60 bg-[#F6EFE1] p-4 text-sm",
			role: "note",
			children: [/* @__PURE__ */ jsx(AlertTriangle, {
				className: "mt-0.5 size-4 shrink-0 text-dune-deep",
				"aria-hidden": "true"
			}), /* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx("p", {
				className: "font-medium",
				children: "Worth a phone call before sending"
			}), /* @__PURE__ */ jsx("ul", {
				className: "mt-1 list-disc pl-5 text-ink/80",
				children: order.risk_flags.map((f) => /* @__PURE__ */ jsx("li", { children: f }, f))
			})] })]
		}),
		/* @__PURE__ */ jsxs("div", {
			className: "grid gap-6 lg:grid-cols-3",
			children: [/* @__PURE__ */ jsxs("div", {
				className: "space-y-6 lg:col-span-2",
				children: [
					canManage && order.transitions.length > 0 && /* @__PURE__ */ jsx(NextSteps, { order }),
					/* @__PURE__ */ jsxs(Panel, {
						title: "Items",
						padded: false,
						children: [/* @__PURE__ */ jsxs(Table, { children: [/* @__PURE__ */ jsx("thead", { children: /* @__PURE__ */ jsxs("tr", { children: [
							/* @__PURE__ */ jsx("th", {
								className: th,
								children: "Product"
							}),
							/* @__PURE__ */ jsx("th", {
								className: cn(th, "text-right"),
								children: "Qty"
							}),
							/* @__PURE__ */ jsx("th", {
								className: cn(th, "text-right"),
								children: "Price"
							}),
							/* @__PURE__ */ jsx("th", {
								className: cn(th, "text-right"),
								children: "Total"
							})
						] }) }), /* @__PURE__ */ jsx("tbody", { children: order.items.map((i) => /* @__PURE__ */ jsxs("tr", { children: [
							/* @__PURE__ */ jsxs("td", {
								className: td,
								children: [
									/* @__PURE__ */ jsx(Link, {
										href: `/admin/products/${i.product_id}/edit`,
										className: "hover:underline",
										children: i.name
									}),
									i.variant && /* @__PURE__ */ jsxs("span", {
										className: "text-stone",
										children: [" — ", i.variant]
									}),
									i.sku && /* @__PURE__ */ jsx("span", {
										className: "block text-xs text-stone",
										children: i.sku
									})
								]
							}),
							/* @__PURE__ */ jsx("td", {
								className: cn(td, "text-right tabular-nums"),
								children: i.quantity
							}),
							/* @__PURE__ */ jsxs("td", {
								className: cn(td, "text-right tabular-nums"),
								children: [money(i.unit_price_minor), i.regular_unit_price_minor > i.unit_price_minor && /* @__PURE__ */ jsx("s", {
									className: "block text-xs text-stone",
									children: money(i.regular_unit_price_minor)
								})]
							}),
							/* @__PURE__ */ jsx("td", {
								className: cn(td, "text-right tabular-nums"),
								children: money(i.line_total_minor)
							})
						] }, i.id)) })] }), /* @__PURE__ */ jsx("div", {
							className: "p-5",
							children: /* @__PURE__ */ jsx(OrderTotals, {
								currency: order.currency,
								subtotal: order.subtotal_minor,
								discount: order.discount_minor,
								shipping: order.shipping_minor,
								total: order.total_minor,
								couponCode: order.coupon_code,
								className: "ml-auto max-w-sm"
							})
						})]
					}),
					/* @__PURE__ */ jsxs(Panel, {
						title: "History",
						children: [/* @__PURE__ */ jsx("ol", {
							className: "space-y-4",
							children: [...order.events].reverse().map((e) => /* @__PURE__ */ jsxs("li", {
								className: "flex gap-3 text-sm",
								children: [/* @__PURE__ */ jsx("span", {
									className: cn("mt-1.5 size-2 shrink-0 rounded-full", e.type === "note" ? "bg-dune" : e.type === "payment" ? "bg-aloe" : "bg-ink"),
									"aria-hidden": "true"
								}), /* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsxs("p", { children: [
									e.type === "note" ? /* @__PURE__ */ jsx("span", {
										className: "font-medium",
										children: "Note"
									}) : e.to_label && /* @__PURE__ */ jsx("span", {
										className: "font-medium",
										children: e.to_label
									}),
									e.type === "delivery" && /* @__PURE__ */ jsx("span", {
										className: "font-medium",
										children: "Delivery details"
									}),
									/* @__PURE__ */ jsxs("span", {
										className: "text-stone",
										children: [
											" ",
											"· ",
											formatDateTime(e.created_at, store.timezone),
											e.user ? ` · ${e.user}` : ""
										]
									})
								] }), e.note && /* @__PURE__ */ jsx("p", {
									className: "mt-0.5 whitespace-pre-line text-ink/80",
									children: e.note
								})] })]
							}, e.id))
						}), canManage && /* @__PURE__ */ jsx(NoteForm, { reference: order.reference })]
					})
				]
			}), /* @__PURE__ */ jsxs("div", {
				className: "space-y-6",
				children: [
					/* @__PURE__ */ jsxs(Panel, {
						title: "Customer",
						children: [
							/* @__PURE__ */ jsx("p", {
								className: "font-medium",
								children: order.customer.name
							}),
							/* @__PURE__ */ jsx("p", {
								className: "mt-1 text-sm",
								children: order.customer.phone
							}),
							order.customer.email && /* @__PURE__ */ jsx("p", {
								className: "text-sm text-stone",
								children: order.customer.email
							}),
							/* @__PURE__ */ jsxs("div", {
								className: "mt-3 flex flex-wrap gap-2",
								children: [/* @__PURE__ */ jsx(Button, {
									asChild: true,
									size: "sm",
									variant: "secondary",
									children: /* @__PURE__ */ jsxs("a", {
										href: `tel:${order.customer.phone_e164}`,
										children: [/* @__PURE__ */ jsx(Phone, { "aria-hidden": "true" }), "Call"]
									})
								}), /* @__PURE__ */ jsx(Button, {
									asChild: true,
									size: "sm",
									variant: "secondary",
									children: /* @__PURE__ */ jsxs("a", {
										href: `https://wa.me/${order.customer.whatsapp}?text=${encodeURIComponent(`Hello ${order.customer.name.split(" ")[0]}, this is Aloe & Soul about your order ${order.reference}.`)}`,
										target: "_blank",
										rel: "noopener noreferrer",
										children: [/* @__PURE__ */ jsx(MessageCircle, { "aria-hidden": "true" }), "WhatsApp"]
									})
								})]
							}),
							order.customer.id && /* @__PURE__ */ jsx(Link, {
								href: `/admin/customers/${order.customer.id}`,
								className: "mt-4 inline-block text-sm underline underline-offset-4",
								children: order.customer.orders_count === 1 ? "First order" : `${order.customer.orders_count} orders in total`
							})
						]
					}),
					/* @__PURE__ */ jsxs(Panel, {
						title: "Delivery",
						children: [/* @__PURE__ */ jsxs("dl", {
							className: "space-y-2 text-sm",
							children: [/* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx("dt", {
								className: "text-stone",
								children: "Address"
							}), /* @__PURE__ */ jsxs("dd", { children: [
								order.delivery.address,
								/* @__PURE__ */ jsx("br", {}),
								order.delivery.city,
								" (",
								order.delivery.zone,
								")"
							] })] }), order.delivery.notes && /* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx("dt", {
								className: "text-stone",
								children: "Notes from the customer"
							}), /* @__PURE__ */ jsx("dd", {
								className: "whitespace-pre-line",
								children: order.delivery.notes
							})] })]
						}), canManage ? /* @__PURE__ */ jsx(DeliveryForm, { order }) : null]
					}),
					/* @__PURE__ */ jsxs(Panel, {
						title: "Payment",
						description: "Cash on delivery",
						children: [
							/* @__PURE__ */ jsx("p", {
								className: "text-sm",
								children: /* @__PURE__ */ jsx(PaymentBadge, {
									status: order.payment.status,
									label: order.payment.status_label
								})
							}),
							order.payment.collected_minor !== null && /* @__PURE__ */ jsxs("p", {
								className: "mt-2 text-sm text-stone",
								children: [
									money(order.payment.collected_minor),
									" recorded ",
									formatDateTime(order.payment.collected_at, store.timezone),
									order.payment.recorded_by ? ` by ${order.payment.recorded_by}` : "",
									"."
								]
							}),
							canManage && order.payment.allowed.length > 0 && /* @__PURE__ */ jsx(PaymentForm, { order })
						]
					})
				]
			})]
		})
	] });
}
function NextSteps({ order }) {
	const [target, setTarget] = useState(null);
	const form = useForm({
		to: "",
		note: "",
		restock: true,
		collect_payment: true
	});
	const errors = form.errors;
	const open = (o) => {
		form.setData({
			to: o.value,
			note: "",
			restock: true,
			collect_payment: true
		});
		form.clearErrors();
		setTarget(o);
	};
	const submit = (e) => {
		e.preventDefault();
		form.post(`/admin/orders/${order.reference}/transitions`, {
			preserveScroll: true,
			onSuccess: () => setTarget(null)
		});
	};
	return /* @__PURE__ */ jsxs(Panel, {
		title: "Next step",
		description: "Only the moves that make sense from the current status are offered.",
		children: [/* @__PURE__ */ jsx("div", {
			className: "flex flex-wrap gap-2",
			children: order.transitions.map((t) => /* @__PURE__ */ jsx(Button, {
				variant: DANGER.includes(t.value) ? "destructive-outline" : "primary",
				onClick: () => open(t),
				children: ACTIONS[t.value] ?? t.label
			}, t.value))
		}), /* @__PURE__ */ jsx(Dialog, {
			open: target !== null,
			onOpenChange: (o) => !o && setTarget(null),
			children: target && /* @__PURE__ */ jsx(DialogContent, {
				title: `${ACTIONS[target.value] ?? target.label}?`,
				description: `Order ${order.reference} will move to “${target.label}”.`,
				children: /* @__PURE__ */ jsxs("form", {
					onSubmit: submit,
					className: "space-y-4",
					children: [
						target.value === "CANCELLED" && /* @__PURE__ */ jsx("p", {
							className: "text-sm text-stone",
							children: "Reserved stock is returned to inventory and any discount code use is released."
						}),
						target.value === "RETURNED" && /* @__PURE__ */ jsxs("div", {
							className: "flex items-start gap-3",
							children: [/* @__PURE__ */ jsx(Checkbox, {
								id: "restock",
								checked: form.data.restock,
								onCheckedChange: (v) => form.setData("restock", v === true)
							}), /* @__PURE__ */ jsx(Label, {
								htmlFor: "restock",
								className: "font-normal",
								children: "Put the returned items back into stock (they are in a sellable condition)"
							})]
						}),
						target.value === "DELIVERED" && /* @__PURE__ */ jsxs("div", {
							className: "flex items-start gap-3",
							children: [/* @__PURE__ */ jsx(Checkbox, {
								id: "collect",
								checked: form.data.collect_payment,
								onCheckedChange: (v) => form.setData("collect_payment", v === true)
							}), /* @__PURE__ */ jsxs(Label, {
								htmlFor: "collect",
								className: "font-normal",
								children: [
									"The courier collected ",
									formatMoney(order.total_minor, order.currency),
									" in cash"
								]
							})]
						}),
						/* @__PURE__ */ jsx(Field, {
							label: "Note",
							name: "note",
							optional: true,
							error: form.errors.note,
							children: (p) => /* @__PURE__ */ jsx(Textarea, {
								...p,
								rows: 3,
								value: form.data.note,
								onChange: (e) => form.setData("note", e.target.value),
								placeholder: "e.g. confirmed by phone"
							})
						}),
						(errors.status || errors.to) && /* @__PURE__ */ jsx("p", {
							className: "text-sm text-clay",
							role: "alert",
							children: errors.status ?? errors.to
						}),
						/* @__PURE__ */ jsxs("div", {
							className: "flex justify-end gap-2",
							children: [/* @__PURE__ */ jsx(Button, {
								type: "button",
								variant: "ghost",
								onClick: () => setTarget(null),
								children: "Back"
							}), /* @__PURE__ */ jsx(Button, {
								type: "submit",
								variant: DANGER.includes(target.value) ? "destructive" : "primary",
								loading: form.processing,
								children: ACTIONS[target.value] ?? "Confirm"
							})]
						})
					]
				})
			})
		})]
	});
}
function PaymentForm({ order }) {
	const first = order.payment.allowed[0]?.value ?? "";
	const form = useForm({
		payment_status: first,
		amount: toDecimalInput(order.total_minor, order.currency),
		note: ""
	});
	const submit = (e) => {
		e.preventDefault();
		form.post(`/admin/orders/${order.reference}/payment`, { preserveScroll: true });
	};
	return /* @__PURE__ */ jsxs("form", {
		onSubmit: submit,
		className: "mt-4 space-y-3 border-t border-line pt-4",
		children: [
			/* @__PURE__ */ jsx(Field, {
				label: "Record payment",
				name: "payment_status",
				error: form.errors.payment_status,
				children: (p) => /* @__PURE__ */ jsx(Select, {
					...p,
					value: form.data.payment_status,
					onChange: (e) => form.setData("payment_status", e.target.value),
					children: order.payment.allowed.map((s) => /* @__PURE__ */ jsx("option", {
						value: s.value,
						children: s.label
					}, s.value))
				})
			}),
			form.data.payment_status === "collected" && /* @__PURE__ */ jsx(Field, {
				label: `Amount collected (${order.currency})`,
				name: "amount",
				error: form.errors.amount,
				children: (p) => /* @__PURE__ */ jsx(Input, {
					...p,
					inputMode: "decimal",
					value: form.data.amount,
					onChange: (e) => form.setData("amount", e.target.value)
				})
			}),
			/* @__PURE__ */ jsx(Button, {
				type: "submit",
				size: "sm",
				loading: form.processing,
				children: "Save payment"
			})
		]
	});
}
function DeliveryForm({ order }) {
	const form = useForm({
		courier_name: order.delivery.courier_name ?? "",
		tracking_number: order.delivery.tracking_number ?? ""
	});
	const submit = (e) => {
		e.preventDefault();
		form.put(`/admin/orders/${order.reference}/delivery`, { preserveScroll: true });
	};
	return /* @__PURE__ */ jsxs("form", {
		onSubmit: submit,
		className: "mt-4 space-y-3 border-t border-line pt-4",
		children: [
			/* @__PURE__ */ jsx(Field, {
				label: "Courier",
				name: "courier_name",
				optional: true,
				error: form.errors.courier_name,
				children: (p) => /* @__PURE__ */ jsx(Input, {
					...p,
					value: form.data.courier_name,
					onChange: (e) => form.setData("courier_name", e.target.value),
					maxLength: 80
				})
			}),
			/* @__PURE__ */ jsx(Field, {
				label: "Tracking number",
				name: "tracking_number",
				optional: true,
				error: form.errors.tracking_number,
				children: (p) => /* @__PURE__ */ jsx(Input, {
					...p,
					value: form.data.tracking_number,
					onChange: (e) => form.setData("tracking_number", e.target.value),
					maxLength: 80
				})
			}),
			/* @__PURE__ */ jsx(Button, {
				type: "submit",
				size: "sm",
				variant: "secondary",
				loading: form.processing,
				disabled: !form.isDirty,
				children: "Save delivery details"
			})
		]
	});
}
function NoteForm({ reference }) {
	const form = useForm({ note: "" });
	const submit = (e) => {
		e.preventDefault();
		form.post(`/admin/orders/${reference}/notes`, {
			preserveScroll: true,
			onSuccess: () => form.reset()
		});
	};
	return /* @__PURE__ */ jsxs("form", {
		onSubmit: submit,
		className: "mt-6 space-y-2 border-t border-line pt-5",
		children: [/* @__PURE__ */ jsx(Field, {
			label: "Internal note",
			name: "note",
			error: form.errors.note,
			hint: "Only visible to the team.",
			children: (p) => /* @__PURE__ */ jsx(Textarea, {
				...p,
				rows: 2,
				value: form.data.note,
				onChange: (e) => form.setData("note", e.target.value),
				maxLength: 2e3
			})
		}), /* @__PURE__ */ jsx(Button, {
			type: "submit",
			size: "sm",
			variant: "secondary",
			loading: form.processing,
			disabled: !form.data.note.trim(),
			children: "Add note"
		})]
	});
}
//#endregion
export { OrderShow as default };
