import { t as useShared } from "./use-shared-BMnpkZPP.js";
import { i as Textarea, t as Input, v as Button } from "../ssr.js";
import { t as Field } from "./field-BVcOZvwI.js";
import { useForm } from "@inertiajs/react";
import { jsx, jsxs } from "react/jsx-runtime";
import { Mail, MapPin, MessageCircle, Phone } from "lucide-react";
//#region resources/js/pages/contact.tsx
function Contact() {
	const { contact } = useShared();
	const form = useForm({
		name: "",
		email: "",
		phone: "",
		message: "",
		website: ""
	});
	const submit = (e) => {
		e.preventDefault();
		form.post("/contact", {
			preserveScroll: true,
			onSuccess: () => form.reset()
		});
	};
	return /* @__PURE__ */ jsxs("div", {
		className: "container-page grid gap-14 py-12 lg:grid-cols-12 lg:py-20",
		children: [/* @__PURE__ */ jsxs("div", {
			className: "lg:col-span-5",
			children: [
				/* @__PURE__ */ jsx("h1", {
					className: "font-display text-display-sm",
					children: "Contact"
				}),
				/* @__PURE__ */ jsx("p", {
					className: "mt-4 text-lg text-stone",
					children: "A question about a product or an order? Send a message, or reach us directly on WhatsApp for a quick reply."
				}),
				/* @__PURE__ */ jsxs("ul", {
					className: "mt-10 space-y-5",
					children: [
						contact?.whatsapp && /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsxs("a", {
							href: `https://wa.me/${contact.whatsapp}`,
							target: "_blank",
							rel: "noopener noreferrer",
							className: "group flex items-start gap-4",
							children: [/* @__PURE__ */ jsx(MessageCircle, {
								className: "mt-0.5 size-5 text-dune",
								strokeWidth: 1.5,
								"aria-hidden": "true"
							}), /* @__PURE__ */ jsxs("span", { children: [/* @__PURE__ */ jsx("span", {
								className: "block font-medium group-hover:text-aloe",
								children: "WhatsApp"
							}), /* @__PURE__ */ jsx("span", {
								className: "text-stone",
								children: contact.phone_display
							})] })]
						}) }),
						contact?.email && /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsxs("a", {
							href: `mailto:${contact.email}`,
							className: "group flex items-start gap-4",
							children: [/* @__PURE__ */ jsx(Mail, {
								className: "mt-0.5 size-5 text-dune",
								strokeWidth: 1.5,
								"aria-hidden": "true"
							}), /* @__PURE__ */ jsxs("span", { children: [/* @__PURE__ */ jsx("span", {
								className: "block font-medium group-hover:text-aloe",
								children: "Email"
							}), /* @__PURE__ */ jsx("span", {
								className: "text-stone",
								children: contact.email
							})] })]
						}) }),
						contact?.phone && /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsxs("a", {
							href: `tel:${contact.phone}`,
							className: "group flex items-start gap-4",
							children: [/* @__PURE__ */ jsx(Phone, {
								className: "mt-0.5 size-5 text-dune",
								strokeWidth: 1.5,
								"aria-hidden": "true"
							}), /* @__PURE__ */ jsxs("span", { children: [
								/* @__PURE__ */ jsx("span", {
									className: "block font-medium group-hover:text-aloe",
									children: "Phone"
								}),
								/* @__PURE__ */ jsx("span", {
									className: "text-stone",
									children: contact.phone_display
								}),
								contact.hours && /* @__PURE__ */ jsx("span", {
									className: "block text-sm text-stone",
									children: contact.hours
								})
							] })]
						}) }),
						contact?.locations && contact.locations.length > 0 && /* @__PURE__ */ jsxs("li", {
							className: "flex items-start gap-4",
							children: [/* @__PURE__ */ jsx(MapPin, {
								className: "mt-0.5 size-5 text-dune",
								strokeWidth: 1.5,
								"aria-hidden": "true"
							}), /* @__PURE__ */ jsxs("span", { children: [/* @__PURE__ */ jsx("span", {
								className: "block font-medium",
								children: "Where we are"
							}), /* @__PURE__ */ jsx("span", {
								className: "text-stone",
								children: contact.locations.join(", ")
							})] })]
						})
					]
				})
			]
		}), /* @__PURE__ */ jsxs("section", {
			"aria-labelledby": "form-heading",
			className: "rounded-lg border border-line bg-white p-6 sm:p-8 lg:col-span-6 lg:col-start-7",
			children: [/* @__PURE__ */ jsx("h2", {
				id: "form-heading",
				className: "font-display text-2xl",
				children: "Send a message"
			}), /* @__PURE__ */ jsxs("form", {
				onSubmit: submit,
				noValidate: true,
				className: "mt-6 space-y-5",
				children: [
					/* @__PURE__ */ jsx(Field, {
						label: "Name",
						name: "name",
						error: form.errors.name,
						required: true,
						children: (p) => /* @__PURE__ */ jsx(Input, {
							...p,
							autoComplete: "name",
							value: form.data.name,
							onChange: (e) => form.setData("name", e.target.value),
							maxLength: 120
						})
					}),
					/* @__PURE__ */ jsxs("div", {
						className: "grid gap-5 sm:grid-cols-2",
						children: [/* @__PURE__ */ jsx(Field, {
							label: "Email",
							name: "email",
							error: form.errors.email,
							required: true,
							children: (p) => /* @__PURE__ */ jsx(Input, {
								...p,
								type: "email",
								autoComplete: "email",
								value: form.data.email,
								onChange: (e) => form.setData("email", e.target.value),
								maxLength: 255
							})
						}), /* @__PURE__ */ jsx(Field, {
							label: "Phone",
							name: "phone",
							optional: true,
							error: form.errors.phone,
							children: (p) => /* @__PURE__ */ jsx(Input, {
								...p,
								type: "tel",
								autoComplete: "tel",
								value: form.data.phone,
								onChange: (e) => form.setData("phone", e.target.value),
								maxLength: 30
							})
						})]
					}),
					/* @__PURE__ */ jsx(Field, {
						label: "Message",
						name: "message",
						error: form.errors.message,
						required: true,
						children: (p) => /* @__PURE__ */ jsx(Textarea, {
							...p,
							rows: 6,
							value: form.data.message,
							onChange: (e) => form.setData("message", e.target.value),
							maxLength: 2e3
						})
					}),
					/* @__PURE__ */ jsx("input", {
						type: "text",
						name: "website",
						tabIndex: -1,
						autoComplete: "off",
						className: "hidden",
						"aria-hidden": "true",
						value: form.data.website,
						onChange: (e) => form.setData("website", e.target.value)
					}),
					/* @__PURE__ */ jsxs("p", {
						className: "text-sm text-stone",
						children: [
							"We use your details only to reply to you. See our",
							" ",
							/* @__PURE__ */ jsx("a", {
								href: "/privacy-policy",
								className: "underline underline-offset-4",
								children: "privacy policy"
							}),
							"."
						]
					}),
					/* @__PURE__ */ jsx(Button, {
						type: "submit",
						loading: form.processing,
						children: "Send message"
					})
				]
			})]
		})]
	});
}
//#endregion
export { Contact as default };
