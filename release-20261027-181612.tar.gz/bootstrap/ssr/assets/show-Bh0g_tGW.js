import { t as cn } from "./utils-BqvNF826.js";
import { t as useShared } from "./use-shared-BMnpkZPP.js";
import { t as formatMoney } from "./money-CcsjAkm_.js";
import { a as ConfirmDialog, v as Button } from "../ssr.js";
import { a as Panel, c as Stat, d as th, l as Table, n as OrderStatusBadge, o as PaymentBadge, r as PageHeader, u as td } from "./ui-DQeK8Yrd.js";
import { n as formatDateTime, t as formatDate } from "./date-x_Fsbx42.js";
import { Link, router } from "@inertiajs/react";
import { Fragment, jsx, jsxs } from "react/jsx-runtime";
//#region resources/js/pages/admin/customers/show.tsx
function CustomerShow({ customer, stats, orders, currency, canAnonymize }) {
	const { store } = useShared();
	return /* @__PURE__ */ jsxs(Fragment, { children: [
		/* @__PURE__ */ jsx(PageHeader, {
			back: {
				href: "/admin/customers",
				label: "Customers"
			},
			title: customer.name,
			description: customer.anonymized_at ? `Personal data removed on ${formatDate(customer.anonymized_at, store.timezone)}.` : `Customer since ${formatDate(customer.first_order_at, store.timezone)}`,
			actions: customer.whatsapp && /* @__PURE__ */ jsx(Button, {
				asChild: true,
				variant: "secondary",
				size: "sm",
				children: /* @__PURE__ */ jsx("a", {
					href: `https://wa.me/${customer.whatsapp}`,
					target: "_blank",
					rel: "noopener noreferrer",
					children: "WhatsApp"
				})
			})
		}),
		/* @__PURE__ */ jsxs("div", {
			className: "grid grid-cols-2 gap-4 lg:grid-cols-4",
			children: [
				/* @__PURE__ */ jsx(Stat, {
					label: "Orders",
					value: stats.orders
				}),
				/* @__PURE__ */ jsx(Stat, {
					label: "Delivered",
					value: stats.delivered
				}),
				/* @__PURE__ */ jsx(Stat, {
					label: "Failed or returned",
					value: stats.failed_or_returned
				}),
				/* @__PURE__ */ jsx(Stat, {
					label: "Cash collected",
					value: formatMoney(stats.collected_minor, currency)
				})
			]
		}),
		/* @__PURE__ */ jsxs("div", {
			className: "mt-6 grid gap-6 lg:grid-cols-3",
			children: [/* @__PURE__ */ jsx(Panel, {
				title: "Orders",
				padded: false,
				className: "lg:col-span-2",
				children: /* @__PURE__ */ jsxs(Table, { children: [/* @__PURE__ */ jsx("thead", { children: /* @__PURE__ */ jsxs("tr", { children: [
					/* @__PURE__ */ jsx("th", {
						className: th,
						children: "Order"
					}),
					/* @__PURE__ */ jsx("th", {
						className: th,
						children: "Status"
					}),
					/* @__PURE__ */ jsx("th", {
						className: th,
						children: "Payment"
					}),
					/* @__PURE__ */ jsx("th", {
						className: cn(th, "text-right"),
						children: "Total"
					}),
					/* @__PURE__ */ jsx("th", {
						className: th,
						children: "Placed"
					})
				] }) }), /* @__PURE__ */ jsx("tbody", { children: orders.map((o) => /* @__PURE__ */ jsxs("tr", { children: [
					/* @__PURE__ */ jsx("td", {
						className: td,
						children: /* @__PURE__ */ jsx(Link, {
							href: `/admin/orders/${o.reference}`,
							className: "font-medium hover:underline",
							children: o.reference
						})
					}),
					/* @__PURE__ */ jsx("td", {
						className: td,
						children: /* @__PURE__ */ jsx(OrderStatusBadge, {
							status: o.status,
							label: o.status_label
						})
					}),
					/* @__PURE__ */ jsx("td", {
						className: td,
						children: /* @__PURE__ */ jsx(PaymentBadge, {
							status: o.payment_status,
							label: o.payment_status_label
						})
					}),
					/* @__PURE__ */ jsx("td", {
						className: cn(td, "text-right tabular-nums"),
						children: formatMoney(o.total_minor, o.currency)
					}),
					/* @__PURE__ */ jsx("td", {
						className: cn(td, "whitespace-nowrap text-stone"),
						children: formatDateTime(o.created_at, store.timezone)
					})
				] }, o.reference)) })] })
			}), /* @__PURE__ */ jsxs("div", {
				className: "space-y-6",
				children: [/* @__PURE__ */ jsx(Panel, {
					title: "Contact",
					children: /* @__PURE__ */ jsxs("dl", {
						className: "space-y-2 text-sm",
						children: [
							/* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx("dt", {
								className: "text-stone",
								children: "Phone"
							}), /* @__PURE__ */ jsx("dd", { children: customer.phone ?? "—" })] }),
							/* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx("dt", {
								className: "text-stone",
								children: "Email"
							}), /* @__PURE__ */ jsx("dd", { children: customer.email ?? "—" })] }),
							/* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx("dt", {
								className: "text-stone",
								children: "City"
							}), /* @__PURE__ */ jsx("dd", { children: customer.city ?? "—" })] })
						]
					})
				}), canAnonymize && !customer.anonymized_at && /* @__PURE__ */ jsxs(Panel, {
					title: "Remove personal data",
					description: "For a customer who asks to be forgotten.",
					children: [/* @__PURE__ */ jsx("p", {
						className: "text-sm text-stone",
						children: "Name, phone, email and addresses are removed from this customer and all their orders. Order amounts are kept for your accounts."
					}), /* @__PURE__ */ jsx(ConfirmDialog, {
						trigger: /* @__PURE__ */ jsx(Button, {
							variant: "destructive-outline",
							size: "sm",
							className: "mt-3",
							children: "Remove personal data"
						}),
						title: "Remove this customer’s personal data?",
						description: "This cannot be undone. Orders still in progress must be completed or cancelled first.",
						confirmLabel: "Remove personal data",
						onConfirm: () => router.post(`/admin/customers/${customer.id}/anonymize`, {}, { preserveScroll: true })
					})]
				})]
			})]
		})
	] });
}
//#endregion
export { CustomerShow as default };
