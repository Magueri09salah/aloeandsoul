import { i as AccordionTrigger, n as AccordionContent, r as AccordionItem, t as Accordion } from "./accordion-CjQ_fweI.js";
import { Link } from "@inertiajs/react";
import { jsx, jsxs } from "react/jsx-runtime";
//#region resources/js/pages/faq.tsx
function Faq({ faqs }) {
	return /* @__PURE__ */ jsxs("div", {
		className: "container-page grid gap-10 py-12 lg:grid-cols-12 lg:py-20",
		children: [/* @__PURE__ */ jsxs("div", {
			className: "lg:col-span-4",
			children: [/* @__PURE__ */ jsx("h1", {
				className: "font-display text-display-sm",
				children: "Frequently asked questions"
			}), /* @__PURE__ */ jsxs("p", {
				className: "mt-4 text-stone",
				children: [
					"Can’t find your answer?",
					" ",
					/* @__PURE__ */ jsx(Link, {
						href: "/contact",
						className: "underline underline-offset-4 hover:text-aloe",
						children: "Contact us"
					}),
					"."
				]
			})]
		}), faqs.length === 0 ? /* @__PURE__ */ jsx("p", {
			className: "text-stone lg:col-span-7 lg:col-start-6",
			children: "Questions and answers will appear here soon."
		}) : /* @__PURE__ */ jsx(Accordion, {
			type: "multiple",
			className: "border-t border-line lg:col-span-7 lg:col-start-6",
			children: faqs.map((f) => /* @__PURE__ */ jsxs(AccordionItem, {
				value: String(f.id),
				children: [/* @__PURE__ */ jsx(AccordionTrigger, { children: f.question }), /* @__PURE__ */ jsx(AccordionContent, {
					className: "max-w-prose whitespace-pre-line",
					children: f.answer
				})]
			}, f.id))
		})]
	});
}
//#endregion
export { Faq as default };
