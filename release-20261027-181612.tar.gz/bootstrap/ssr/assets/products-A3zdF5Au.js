import { t as cn } from "./utils-BqvNF826.js";
import { t as formatMoney } from "./money-CcsjAkm_.js";
import { r as Select, t as Input, v as Button } from "../ssr.js";
import { a as Panel, d as th, i as Pagination, l as Table, r as PageHeader, s as ProductStatusBadge, t as EmptyState, u as td } from "./ui-DQeK8Yrd.js";
import { Link, router } from "@inertiajs/react";
import { useState } from "react";
import { Fragment, jsx, jsxs } from "react/jsx-runtime";
import { Plus, Search } from "lucide-react";
//#region resources/js/pages/admin/products/index.tsx
function ProductsIndex({ products, filters, categories, statuses, currency, canManage }) {
	const [q, setQ] = useState(filters.q);
	const apply = (next) => {
		const merged = {
			...filters,
			q,
			...next
		};
		const query = Object.fromEntries(Object.entries(merged).filter(([, v]) => v !== null && v !== "" && v !== void 0));
		router.get("/admin/products", query, {
			preserveState: true,
			preserveScroll: true,
			replace: true
		});
	};
	const price = (r) => {
		if (r.min_price_minor === null) return /* @__PURE__ */ jsx("span", {
			className: "text-stone",
			children: "No price"
		});
		if (r.min_price_minor === r.max_price_minor) return formatMoney(r.min_price_minor, currency);
		return `${formatMoney(r.min_price_minor, currency)} – ${formatMoney(r.max_price_minor ?? r.min_price_minor, currency)}`;
	};
	return /* @__PURE__ */ jsxs(Fragment, { children: [/* @__PURE__ */ jsx(PageHeader, {
		title: "Products",
		description: "Drafts are hidden from the shop. A product can be published once it has a price, an image and a description.",
		actions: canManage && /* @__PURE__ */ jsx(Button, {
			asChild: true,
			children: /* @__PURE__ */ jsxs(Link, {
				href: "/admin/products/create",
				children: [/* @__PURE__ */ jsx(Plus, { "aria-hidden": "true" }), "Add product"]
			})
		})
	}), /* @__PURE__ */ jsxs(Panel, {
		padded: false,
		children: [
			/* @__PURE__ */ jsxs("form", {
				onSubmit: (e) => {
					e.preventDefault();
					apply({});
				},
				className: "grid gap-3 border-b border-line p-4 sm:grid-cols-[1fr_auto_auto_auto]",
				children: [
					/* @__PURE__ */ jsxs("div", {
						className: "relative",
						children: [
							/* @__PURE__ */ jsx("label", {
								htmlFor: "q",
								className: "sr-only",
								children: "Search products"
							}),
							/* @__PURE__ */ jsx(Search, {
								className: "pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-stone",
								"aria-hidden": "true"
							}),
							/* @__PURE__ */ jsx(Input, {
								id: "q",
								type: "search",
								value: q,
								onChange: (e) => setQ(e.target.value),
								placeholder: "Name or SKU",
								className: "h-10 pl-9"
							})
						]
					}),
					/* @__PURE__ */ jsxs(Select, {
						"aria-label": "Category",
						value: filters.category ?? "",
						onChange: (e) => apply({ category: e.target.value ? Number(e.target.value) : null }),
						className: "h-10",
						children: [/* @__PURE__ */ jsx("option", {
							value: "",
							children: "All categories"
						}), categories.map((c) => /* @__PURE__ */ jsx("option", {
							value: c.id,
							children: c.name
						}, c.id))]
					}),
					/* @__PURE__ */ jsxs(Select, {
						"aria-label": "Status",
						value: filters.status ?? "",
						onChange: (e) => apply({ status: e.target.value || null }),
						className: "h-10",
						children: [/* @__PURE__ */ jsx("option", {
							value: "",
							children: "All statuses"
						}), statuses.map((s) => /* @__PURE__ */ jsx("option", {
							value: s.value,
							children: s.label
						}, s.value))]
					}),
					/* @__PURE__ */ jsxs(Select, {
						"aria-label": "Sort",
						value: filters.sort,
						onChange: (e) => apply({ sort: e.target.value }),
						className: "h-10",
						children: [
							/* @__PURE__ */ jsx("option", {
								value: "updated",
								children: "Recently edited"
							}),
							/* @__PURE__ */ jsx("option", {
								value: "name",
								children: "Name"
							}),
							/* @__PURE__ */ jsx("option", {
								value: "stock",
								children: "Lowest stock"
							})
						]
					})
				]
			}),
			products.data.length === 0 ? /* @__PURE__ */ jsx(EmptyState, { title: "No products found." }) : /* @__PURE__ */ jsxs(Table, { children: [/* @__PURE__ */ jsx("thead", { children: /* @__PURE__ */ jsxs("tr", { children: [
				/* @__PURE__ */ jsx("th", {
					className: th,
					children: "Product"
				}),
				/* @__PURE__ */ jsx("th", {
					className: th,
					children: "Status"
				}),
				/* @__PURE__ */ jsx("th", {
					className: th,
					children: "Price"
				}),
				/* @__PURE__ */ jsx("th", {
					className: cn(th, "text-right"),
					children: "Stock"
				})
			] }) }), /* @__PURE__ */ jsx("tbody", { children: products.data.map((p) => /* @__PURE__ */ jsxs("tr", {
				className: "hover:bg-panel/50",
				children: [
					/* @__PURE__ */ jsx("td", {
						className: td,
						children: /* @__PURE__ */ jsxs("div", {
							className: "flex items-center gap-3",
							children: [/* @__PURE__ */ jsx("div", {
								className: "size-11 shrink-0 overflow-hidden rounded bg-sand",
								children: p.image && /* @__PURE__ */ jsx("img", {
									src: p.image.src,
									alt: "",
									className: "h-full w-full object-cover",
									loading: "lazy"
								})
							}), /* @__PURE__ */ jsxs("div", {
								className: "min-w-0",
								children: [canManage ? /* @__PURE__ */ jsx(Link, {
									href: `/admin/products/${p.id}/edit`,
									className: "font-medium hover:underline",
									children: p.name
								}) : /* @__PURE__ */ jsx("span", {
									className: "font-medium",
									children: p.name
								}), /* @__PURE__ */ jsxs("span", {
									className: "block text-xs text-stone",
									children: [
										p.category,
										p.variant_count > 1 && `, ${p.variant_count} options`,
										p.is_featured && ", featured",
										p.is_bestseller && ", bestseller"
									]
								})]
							})]
						})
					}),
					/* @__PURE__ */ jsxs("td", {
						className: td,
						children: [/* @__PURE__ */ jsx(ProductStatusBadge, {
							status: p.status,
							label: p.status_label
						}), p.blockers > 0 && /* @__PURE__ */ jsxs("span", {
							className: "mt-1 block text-xs text-stone",
							children: [p.blockers, " thing(s) to complete"]
						})]
					}),
					/* @__PURE__ */ jsx("td", {
						className: cn(td, "whitespace-nowrap tabular-nums"),
						children: price(p)
					}),
					/* @__PURE__ */ jsx("td", {
						className: cn(td, "text-right tabular-nums", p.total_stock === 0 && "text-clay"),
						children: p.total_stock
					})
				]
			}, p.id)) })] }),
			/* @__PURE__ */ jsx(Pagination, { page: products })
		]
	})] });
}
//#endregion
export { ProductsIndex as default };
