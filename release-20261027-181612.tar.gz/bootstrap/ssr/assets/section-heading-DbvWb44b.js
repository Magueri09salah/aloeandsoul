import { t as cn } from "./utils-BqvNF826.js";
import { Link } from "@inertiajs/react";
import { jsx, jsxs } from "react/jsx-runtime";
//#region resources/js/components/store/section-heading.tsx
function SectionHeading({ title, intro, link, className, as: Tag = "h2" }) {
	return /* @__PURE__ */ jsxs("div", {
		className: cn("flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between", className),
		children: [/* @__PURE__ */ jsxs("div", {
			className: "max-w-2xl",
			children: [/* @__PURE__ */ jsx(Tag, {
				className: "font-display text-display-sm",
				children: title
			}), intro && /* @__PURE__ */ jsx("p", {
				className: "mt-3 text-lg text-stone",
				children: intro
			})]
		}), link && /* @__PURE__ */ jsx(Link, {
			href: link.href,
			className: "shrink-0 text-[0.95rem] font-medium underline underline-offset-4 hover:text-aloe",
			children: link.label
		})]
	});
}
//#endregion
export { SectionHeading as t };
