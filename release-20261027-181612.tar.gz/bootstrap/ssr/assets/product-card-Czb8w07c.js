import { t as cn } from "./utils-BqvNF826.js";
import { b as useCartUi, d as ProductPlaceholder, h as Price, p as ResponsiveImage, y as Spinner } from "../ssr.js";
import { Link, router } from "@inertiajs/react";
import { useState } from "react";
import { jsx, jsxs } from "react/jsx-runtime";
import { Plus } from "lucide-react";
//#region resources/js/components/store/product-card.tsx
var MOTIF_BY_CATEGORY = {
	"sport-fitness": "horizon",
	beauty: "circle",
	hygiene: "wave",
	"nutrition-supplements": "leaf"
};
function ProductCard({ product, sizes = "(min-width: 1024px) 25vw, (min-width: 640px) 33vw, 50vw", priority = false, className }) {
	const cart = useCartUi();
	const [adding, setAdding] = useState(false);
	const href = `/products/${product.slug}`;
	const quickAdd = () => {
		if (!product.quick_add_variant_id) return;
		router.post("/cart/items", {
			variant_id: product.quick_add_variant_id,
			quantity: 1
		}, {
			preserveScroll: true,
			onStart: () => setAdding(true),
			onFinish: () => setAdding(false),
			onSuccess: (page) => {
				if (!page.props.errors.quantity) cart.open();
			}
		});
	};
	return /* @__PURE__ */ jsxs("article", {
		className: cn("group relative flex flex-col", className),
		children: [/* @__PURE__ */ jsxs(Link, {
			href,
			className: "block focus-visible:outline-offset-4",
			prefetch: "hover",
			children: [/* @__PURE__ */ jsxs("div", {
				className: "relative aspect-[4/5] overflow-hidden",
				style: { backgroundColor: product.category.tint },
				children: [product.image ? /* @__PURE__ */ jsx(ResponsiveImage, {
					image: product.image,
					sizes,
					priority,
					alt: "",
					className: "transition-transform duration-700 ease-(--ease-out-soft) motion-safe:group-hover:scale-[1.03]"
				}) : /* @__PURE__ */ jsx(ProductPlaceholder, {
					tint: product.category.tint,
					motif: MOTIF_BY_CATEGORY[product.category.slug]
				}), /* @__PURE__ */ jsxs("div", {
					className: "absolute top-3 left-3 flex flex-col items-start gap-1.5",
					children: [
						!product.in_stock && /* @__PURE__ */ jsx("span", {
							className: "rounded-full bg-white/90 px-2.5 py-1 text-xs font-medium text-stone",
							children: "Out of stock"
						}),
						product.in_stock && product.on_sale && /* @__PURE__ */ jsx("span", {
							className: "rounded-full bg-ink px-2.5 py-1 text-xs font-medium text-ivory",
							children: "Sale"
						}),
						product.is_bestseller && /* @__PURE__ */ jsx("span", {
							className: "rounded-full bg-white/90 px-2.5 py-1 text-xs font-medium text-ink",
							children: "Bestseller"
						})
					]
				})]
			}), /* @__PURE__ */ jsx("h3", {
				className: "mt-3.5 text-[0.98rem] leading-snug font-medium text-ink group-hover:text-aloe",
				children: product.name
			})]
		}), /* @__PURE__ */ jsxs("div", {
			className: "mt-1 flex min-h-9 items-center justify-between gap-3",
			children: [/* @__PURE__ */ jsx(Price, {
				amount: product.price_minor,
				regular: product.regular_price_minor,
				from: product.price_varies,
				className: "text-[0.95rem]"
			}), product.quick_add_variant_id ? /* @__PURE__ */ jsx("button", {
				type: "button",
				onClick: quickAdd,
				disabled: adding,
				className: "inline-flex size-9 shrink-0 items-center justify-center rounded-full border border-line bg-white text-ink transition-colors hover:border-ink hover:bg-ink hover:text-ivory disabled:opacity-60",
				"aria-label": `Add ${product.name} to cart`,
				children: adding ? /* @__PURE__ */ jsx(Spinner, {}) : /* @__PURE__ */ jsx(Plus, {
					className: "size-4",
					"aria-hidden": "true"
				})
			}) : product.variant_count > 1 && product.in_stock && /* @__PURE__ */ jsxs("span", {
				className: "text-sm text-stone",
				children: [
					product.variant_count,
					" ",
					product.option_label ? `${product.option_label.toLowerCase()}s` : "options"
				]
			})]
		})]
	});
}
//#endregion
export { ProductCard as n, MOTIF_BY_CATEGORY as t };
