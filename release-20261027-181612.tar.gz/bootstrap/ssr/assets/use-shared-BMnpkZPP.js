import { usePage } from "@inertiajs/react";
//#region resources/js/hooks/use-shared.ts
/** Typed access to props shared by HandleInertiaRequests on every page. */
function useShared() {
	return usePage().props;
}
//#endregion
export { useShared as t };
