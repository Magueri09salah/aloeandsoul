import { t as cn } from "./utils-BqvNF826.js";
import { o as Dialog, s as DialogContent, t as Input, v as Button } from "../ssr.js";
import { t as Badge } from "./badge-ChM6xC7L.js";
import { a as Panel, d as th, i as Pagination, l as Table, r as PageHeader, t as EmptyState, u as td } from "./ui-DQeK8Yrd.js";
import { t as Field } from "./field-BVcOZvwI.js";
import { Link, router, useForm } from "@inertiajs/react";
import { useState } from "react";
import { Fragment, jsx, jsxs } from "react/jsx-runtime";
import { Search } from "lucide-react";
//#region resources/js/pages/admin/inventory/index.tsx
function Inventory({ variants, filters, canManage }) {
	const [q, setQ] = useState(filters.q);
	const [adjusting, setAdjusting] = useState(null);
	const apply = (next) => {
		const merged = {
			...filters,
			q,
			...next
		};
		const query = Object.fromEntries(Object.entries(merged).filter(([, v]) => v !== null && v !== ""));
		router.get("/admin/inventory", query, {
			preserveState: true,
			preserveScroll: true,
			replace: true
		});
	};
	return /* @__PURE__ */ jsxs(Fragment, { children: [
		/* @__PURE__ */ jsx(PageHeader, {
			title: "Stock",
			description: "Stock is reserved when an order is placed and returned automatically if the order is cancelled. Every change is recorded."
		}),
		/* @__PURE__ */ jsx("div", {
			className: "mb-4 flex flex-wrap gap-2",
			role: "group",
			"aria-label": "Stock level",
			children: [
				{
					value: null,
					label: "All"
				},
				{
					value: "low",
					label: "Low stock"
				},
				{
					value: "out",
					label: "Out of stock"
				}
			].map((l) => /* @__PURE__ */ jsx("button", {
				type: "button",
				"aria-pressed": filters.level === l.value,
				onClick: () => apply({ level: l.value }),
				className: cn("h-9 rounded-full border px-3.5 text-sm", filters.level === l.value ? "border-ink bg-ink text-ivory" : "border-line bg-white hover:border-stone"),
				children: l.label
			}, l.label))
		}),
		/* @__PURE__ */ jsxs(Panel, {
			padded: false,
			children: [
				/* @__PURE__ */ jsx("form", {
					onSubmit: (e) => {
						e.preventDefault();
						apply({});
					},
					className: "border-b border-line p-4",
					children: /* @__PURE__ */ jsxs("div", {
						className: "relative max-w-md",
						children: [
							/* @__PURE__ */ jsx("label", {
								htmlFor: "q",
								className: "sr-only",
								children: "Search stock"
							}),
							/* @__PURE__ */ jsx(Search, {
								className: "pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-stone",
								"aria-hidden": "true"
							}),
							/* @__PURE__ */ jsx(Input, {
								id: "q",
								type: "search",
								value: q,
								onChange: (e) => setQ(e.target.value),
								placeholder: "Product, option or SKU",
								className: "h-10 pl-9"
							})
						]
					})
				}),
				variants.data.length === 0 ? /* @__PURE__ */ jsx(EmptyState, { title: "Nothing to show." }) : /* @__PURE__ */ jsxs(Table, { children: [/* @__PURE__ */ jsx("thead", { children: /* @__PURE__ */ jsxs("tr", { children: [
					/* @__PURE__ */ jsx("th", {
						className: th,
						children: "Product"
					}),
					/* @__PURE__ */ jsx("th", {
						className: th,
						children: "SKU"
					}),
					/* @__PURE__ */ jsx("th", {
						className: cn(th, "text-right"),
						children: "In stock"
					}),
					/* @__PURE__ */ jsx("th", {
						className: th,
						children: /* @__PURE__ */ jsx("span", {
							className: "sr-only",
							children: "Actions"
						})
					})
				] }) }), /* @__PURE__ */ jsx("tbody", { children: variants.data.map((v) => /* @__PURE__ */ jsxs("tr", { children: [
					/* @__PURE__ */ jsxs("td", {
						className: td,
						children: [
							/* @__PURE__ */ jsx(Link, {
								href: `/admin/products/${v.product_id}/edit`,
								className: "hover:underline",
								children: v.product_name
							}),
							v.name && /* @__PURE__ */ jsxs("span", {
								className: "text-stone",
								children: [" — ", v.name]
							}),
							/* @__PURE__ */ jsxs("span", {
								className: "ml-2 inline-flex gap-1",
								children: [v.product_status === "draft" && /* @__PURE__ */ jsx(Badge, {
									tone: "warning",
									children: "Draft"
								}), !v.is_active && /* @__PURE__ */ jsx(Badge, {
									tone: "neutral",
									children: "Not for sale"
								})]
							})
						]
					}),
					/* @__PURE__ */ jsx("td", {
						className: cn(td, "text-stone"),
						children: v.sku ?? "—"
					}),
					/* @__PURE__ */ jsx("td", {
						className: cn(td, "text-right tabular-nums"),
						children: v.track_stock ? /* @__PURE__ */ jsx("span", {
							className: cn(v.stock === 0 ? "text-clay" : v.is_low && "text-dune-deep"),
							children: v.stock
						}) : /* @__PURE__ */ jsx("span", {
							className: "text-stone",
							children: "Not tracked"
						})
					}),
					/* @__PURE__ */ jsxs("td", {
						className: cn(td, "text-right whitespace-nowrap"),
						children: [/* @__PURE__ */ jsx(Button, {
							asChild: true,
							size: "sm",
							variant: "ghost",
							children: /* @__PURE__ */ jsx(Link, {
								href: `/admin/inventory/${v.id}/history`,
								children: "History"
							})
						}), canManage && v.track_stock && /* @__PURE__ */ jsx(Button, {
							size: "sm",
							variant: "secondary",
							onClick: () => setAdjusting(v),
							children: "Adjust"
						})]
					})
				] }, v.id)) })] }),
				/* @__PURE__ */ jsx(Pagination, { page: variants })
			]
		}),
		/* @__PURE__ */ jsx(Dialog, {
			open: adjusting !== null,
			onOpenChange: (o) => !o && setAdjusting(null),
			children: adjusting && /* @__PURE__ */ jsx(DialogContent, {
				title: "Adjust stock",
				description: `${adjusting.product_name}${adjusting.name ? ` — ${adjusting.name}` : ""}`,
				children: /* @__PURE__ */ jsx(AdjustForm, {
					row: adjusting,
					onDone: () => setAdjusting(null)
				})
			})
		})
	] });
}
function AdjustForm({ row, onDone }) {
	const form = useForm({
		stock: row.stock,
		note: ""
	});
	const submit = (e) => {
		e.preventDefault();
		form.put(`/admin/inventory/${row.id}`, {
			preserveScroll: true,
			onSuccess: onDone
		});
	};
	return /* @__PURE__ */ jsxs("form", {
		onSubmit: submit,
		noValidate: true,
		className: "space-y-4",
		children: [
			/* @__PURE__ */ jsx(Field, {
				label: "Units in stock now",
				name: "stock",
				error: form.errors.stock,
				hint: `Currently ${row.stock}. Enter the counted quantity.`,
				required: true,
				children: (p) => /* @__PURE__ */ jsx(Input, {
					...p,
					type: "number",
					min: 0,
					value: form.data.stock,
					onChange: (e) => form.setData("stock", Math.max(0, Number.parseInt(e.target.value || "0", 10)))
				})
			}),
			/* @__PURE__ */ jsx(Field, {
				label: "Reason",
				name: "note",
				error: form.errors.note,
				hint: "For example: delivery received, stock count, damaged.",
				optional: true,
				children: (p) => /* @__PURE__ */ jsx(Input, {
					...p,
					value: form.data.note,
					onChange: (e) => form.setData("note", e.target.value),
					maxLength: 255
				})
			}),
			/* @__PURE__ */ jsx("div", {
				className: "flex justify-end",
				children: /* @__PURE__ */ jsx(Button, {
					type: "submit",
					loading: form.processing,
					children: "Save stock"
				})
			})
		]
	});
}
//#endregion
export { Inventory as default };
