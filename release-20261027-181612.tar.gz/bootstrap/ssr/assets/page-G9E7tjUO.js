import { t as formatDate } from "./date-x_Fsbx42.js";
import { t as SafeHtml } from "./safe-html-DgcSMhDG.js";
import { jsx, jsxs } from "react/jsx-runtime";
//#region resources/js/pages/page.tsx
function Page({ page }) {
	return /* @__PURE__ */ jsxs("article", {
		className: "container-page py-12 lg:py-20",
		children: [/* @__PURE__ */ jsxs("header", {
			className: "max-w-3xl",
			children: [/* @__PURE__ */ jsx("h1", {
				className: "font-display text-display-sm",
				children: page.title
			}), page.updated_at && /* @__PURE__ */ jsxs("p", {
				className: "mt-3 text-sm text-stone",
				children: ["Last updated ", formatDate(page.updated_at)]
			})]
		}), /* @__PURE__ */ jsx(SafeHtml, {
			html: page.body_html,
			className: "prose-editorial mt-10"
		})]
	});
}
//#endregion
export { Page as default };
