import { t as useShared } from "./use-shared-BMnpkZPP.js";
import { t as formatMoney } from "./money-CcsjAkm_.js";
import { v as Button } from "../ssr.js";
import { t as OrderTotals } from "./order-totals-CfndwuiF.js";
import { Link } from "@inertiajs/react";
import { jsx, jsxs } from "react/jsx-runtime";
//#region resources/js/pages/checkout/confirmation.tsx
function Confirmation({ order, checkout }) {
	const { contact } = useShared();
	const firstName = order.delivery.name.split(" ")[0];
	const steps = [
		checkout.confirmation_note || "We review your order and prepare it.",
		"We pack your order and hand it to the courier.",
		`You pay ${formatMoney(order.total_minor, order.currency)} in cash when it arrives.`
	];
	return /* @__PURE__ */ jsxs("div", {
		className: "container-page py-12 lg:py-20",
		children: [/* @__PURE__ */ jsxs("div", {
			className: "max-w-3xl",
			children: [
				/* @__PURE__ */ jsx("p", {
					className: "text-dune-deep",
					children: "Order received"
				}),
				/* @__PURE__ */ jsxs("h1", {
					className: "mt-2 font-display text-display",
					children: [
						"Thank you, ",
						firstName,
						"."
					]
				}),
				/* @__PURE__ */ jsxs("p", {
					className: "mt-6 text-lg",
					children: [
						"Your order reference is",
						" ",
						/* @__PURE__ */ jsx("strong", {
							className: "rounded bg-sand px-2 py-0.5 font-semibold tracking-wide select-all",
							children: order.reference
						}),
						". Keep it to follow your order."
					]
				})
			]
		}), /* @__PURE__ */ jsxs("div", {
			className: "mt-12 grid gap-12 lg:grid-cols-12",
			children: [/* @__PURE__ */ jsxs("section", {
				"aria-labelledby": "next-heading",
				className: "lg:col-span-5",
				children: [
					/* @__PURE__ */ jsx("h2", {
						id: "next-heading",
						className: "font-display text-2xl",
						children: "What happens next"
					}),
					/* @__PURE__ */ jsx("ol", {
						className: "mt-6 space-y-6",
						children: steps.map((step, i) => /* @__PURE__ */ jsxs("li", {
							className: "flex gap-4",
							children: [/* @__PURE__ */ jsx("span", {
								className: "flex size-9 shrink-0 items-center justify-center rounded-full border border-dune font-display text-lg text-dune-deep",
								children: i + 1
							}), /* @__PURE__ */ jsx("p", {
								className: "pt-1.5",
								children: step
							})]
						}, step))
					}),
					/* @__PURE__ */ jsxs("div", {
						className: "mt-10 flex flex-wrap gap-3",
						children: [/* @__PURE__ */ jsx(Button, {
							asChild: true,
							variant: "secondary",
							children: /* @__PURE__ */ jsx(Link, {
								href: "/track-order",
								children: "Track this order"
							})
						}), contact?.whatsapp && /* @__PURE__ */ jsx(Button, {
							asChild: true,
							variant: "ghost",
							children: /* @__PURE__ */ jsx("a", {
								href: `https://wa.me/${contact.whatsapp}?text=${encodeURIComponent(`Order ${order.reference}`)}`,
								target: "_blank",
								rel: "noopener noreferrer",
								children: "Questions? WhatsApp us"
							})
						})]
					})
				]
			}), /* @__PURE__ */ jsxs("section", {
				"aria-labelledby": "summary-heading",
				className: "rounded-lg border border-line bg-white p-6 lg:col-span-6 lg:col-start-7",
				children: [
					/* @__PURE__ */ jsx("h2", {
						id: "summary-heading",
						className: "font-display text-2xl",
						children: "Order summary"
					}),
					/* @__PURE__ */ jsx("ul", {
						className: "mt-4 divide-y divide-line border-y border-line",
						children: order.items.map((item, i) => /* @__PURE__ */ jsxs("li", {
							className: "flex justify-between gap-4 py-3 text-[0.95rem]",
							children: [/* @__PURE__ */ jsxs("span", { children: [
								item.name,
								item.variant && /* @__PURE__ */ jsxs("span", {
									className: "text-stone",
									children: [" — ", item.variant]
								}),
								/* @__PURE__ */ jsxs("span", {
									className: "text-stone",
									children: [" × ", item.quantity]
								})
							] }), /* @__PURE__ */ jsx("span", {
								className: "tabular-nums",
								children: formatMoney(item.line_total_minor, order.currency)
							})]
						}, i))
					}),
					/* @__PURE__ */ jsx(OrderTotals, {
						className: "mt-5",
						currency: order.currency,
						subtotal: order.subtotal_minor,
						discount: order.discount_minor,
						shipping: order.shipping_minor,
						total: order.total_minor,
						couponCode: order.coupon_code
					}),
					/* @__PURE__ */ jsxs("div", {
						className: "mt-6 border-t border-line pt-5 text-[0.95rem]",
						children: [
							/* @__PURE__ */ jsx("h3", {
								className: "font-medium",
								children: "Delivery to"
							}),
							/* @__PURE__ */ jsxs("p", {
								className: "mt-1 text-stone",
								children: [
									order.delivery.name,
									", ",
									order.delivery.phone,
									/* @__PURE__ */ jsx("br", {}),
									order.delivery.address,
									", ",
									order.delivery.city,
									" (",
									order.delivery.zone,
									")"
								]
							}),
							order.delivery.notes && /* @__PURE__ */ jsxs("p", {
								className: "mt-2 text-stone",
								children: ["Notes: ", order.delivery.notes]
							})
						]
					})
				]
			})]
		})]
	});
}
//#endregion
export { Confirmation as default };
