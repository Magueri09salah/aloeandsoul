import { t as cn } from "./utils-BqvNF826.js";
import { t as useShared } from "./use-shared-BMnpkZPP.js";
import { t as formatMoney } from "./money-CcsjAkm_.js";
import { t as Input } from "../ssr.js";
import { a as Panel, d as th, i as Pagination, l as Table, r as PageHeader, t as EmptyState, u as td } from "./ui-DQeK8Yrd.js";
import { t as formatDate } from "./date-x_Fsbx42.js";
import { Link, router } from "@inertiajs/react";
import { useState } from "react";
import { Fragment, jsx, jsxs } from "react/jsx-runtime";
import { Search } from "lucide-react";
//#region resources/js/pages/admin/customers/index.tsx
function Customers({ customers, filters, currency }) {
	const { store } = useShared();
	const [q, setQ] = useState(filters.q);
	const submit = (e) => {
		e.preventDefault();
		router.get("/admin/customers", q ? { q } : {}, {
			preserveState: true,
			replace: true
		});
	};
	return /* @__PURE__ */ jsxs(Fragment, { children: [/* @__PURE__ */ jsx(PageHeader, {
		title: "Customers",
		description: "Created automatically from orders, identified by phone number. No accounts or passwords."
	}), /* @__PURE__ */ jsxs(Panel, {
		padded: false,
		children: [
			/* @__PURE__ */ jsx("form", {
				onSubmit: submit,
				className: "border-b border-line p-4",
				children: /* @__PURE__ */ jsxs("div", {
					className: "relative max-w-md",
					children: [
						/* @__PURE__ */ jsx("label", {
							htmlFor: "q",
							className: "sr-only",
							children: "Search customers"
						}),
						/* @__PURE__ */ jsx(Search, {
							className: "pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-stone",
							"aria-hidden": "true"
						}),
						/* @__PURE__ */ jsx(Input, {
							id: "q",
							type: "search",
							value: q,
							onChange: (e) => setQ(e.target.value),
							placeholder: "Name or phone",
							className: "h-10 pl-9"
						})
					]
				})
			}),
			customers.data.length === 0 ? /* @__PURE__ */ jsx(EmptyState, { title: "No customers found." }) : /* @__PURE__ */ jsxs(Table, { children: [/* @__PURE__ */ jsx("thead", { children: /* @__PURE__ */ jsxs("tr", { children: [
				/* @__PURE__ */ jsx("th", {
					className: th,
					children: "Customer"
				}),
				/* @__PURE__ */ jsx("th", {
					className: th,
					children: "City"
				}),
				/* @__PURE__ */ jsx("th", {
					className: cn(th, "text-right"),
					children: "Orders"
				}),
				/* @__PURE__ */ jsx("th", {
					className: cn(th, "text-right"),
					children: "Delivered value"
				}),
				/* @__PURE__ */ jsx("th", {
					className: th,
					children: "Last order"
				})
			] }) }), /* @__PURE__ */ jsx("tbody", { children: customers.data.map((c) => /* @__PURE__ */ jsxs("tr", {
				className: "hover:bg-panel/50",
				children: [
					/* @__PURE__ */ jsxs("td", {
						className: td,
						children: [/* @__PURE__ */ jsx(Link, {
							href: `/admin/customers/${c.id}`,
							className: cn("font-medium hover:underline", c.anonymized && "text-stone"),
							children: c.name
						}), /* @__PURE__ */ jsx("span", {
							className: "block text-xs text-stone",
							children: c.phone
						})]
					}),
					/* @__PURE__ */ jsx("td", {
						className: td,
						children: c.city ?? "—"
					}),
					/* @__PURE__ */ jsx("td", {
						className: cn(td, "text-right tabular-nums"),
						children: c.orders_count
					}),
					/* @__PURE__ */ jsx("td", {
						className: cn(td, "text-right tabular-nums"),
						children: formatMoney(c.delivered_value_minor, currency)
					}),
					/* @__PURE__ */ jsx("td", {
						className: cn(td, "text-stone"),
						children: formatDate(c.last_order_at, store.timezone)
					})
				]
			}, c.id)) })] }),
			/* @__PURE__ */ jsx(Pagination, { page: customers })
		]
	})] });
}
//#endregion
export { Customers as default };
