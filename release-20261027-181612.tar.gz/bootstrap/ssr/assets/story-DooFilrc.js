import { i as Textarea, t as Input, v as Button } from "../ssr.js";
import { a as Panel, r as PageHeader } from "./ui-DQeK8Yrd.js";
import { t as Field } from "./field-BVcOZvwI.js";
import { t as ContentImage } from "./content-image-DdCE0VuA.js";
import { useForm } from "@inertiajs/react";
import { Fragment, jsx, jsxs } from "react/jsx-runtime";
import { Plus, Trash2 } from "lucide-react";
//#region resources/js/pages/admin/content/story.tsx
function ContentStory({ story }) {
	const form = useForm({
		heading: story.heading,
		intro: story.intro,
		image_alt: story.image_alt,
		milestones: story.milestones,
		chapters: story.chapters,
		closing: story.closing,
		disclaimer: story.disclaimer
	});
	const err = (k) => form.errors[k];
	const submit = (e) => {
		e.preventDefault();
		form.put("/admin/content/story", { preserveScroll: true });
	};
	return /* @__PURE__ */ jsxs(Fragment, { children: [/* @__PURE__ */ jsx(PageHeader, {
		title: "Our story",
		description: "The founder’s story, in her own words. Paragraphs are separated by an empty line.",
		actions: /* @__PURE__ */ jsx(Button, {
			asChild: true,
			variant: "secondary",
			size: "sm",
			children: /* @__PURE__ */ jsx("a", {
				href: "/our-story",
				target: "_blank",
				rel: "noopener",
				children: "View page"
			})
		})
	}), /* @__PURE__ */ jsxs("div", {
		className: "space-y-6",
		children: [/* @__PURE__ */ jsx(Panel, {
			title: "Photograph",
			children: /* @__PURE__ */ jsx(ContentImage, {
				slot: "story",
				image: story.image,
				isCustom: story.has_custom_image
			})
		}), /* @__PURE__ */ jsxs("form", {
			onSubmit: submit,
			noValidate: true,
			className: "space-y-6",
			children: [
				/* @__PURE__ */ jsx(Panel, {
					title: "Opening",
					children: /* @__PURE__ */ jsxs("div", {
						className: "space-y-4",
						children: [
							/* @__PURE__ */ jsx(Field, {
								label: "Heading",
								name: "heading",
								error: err("heading"),
								required: true,
								children: (p) => /* @__PURE__ */ jsx(Input, {
									...p,
									value: form.data.heading,
									onChange: (e) => form.setData("heading", e.target.value),
									maxLength: 120
								})
							}),
							/* @__PURE__ */ jsx(Field, {
								label: "Opening line",
								name: "intro",
								error: err("intro"),
								optional: true,
								children: (p) => /* @__PURE__ */ jsx(Textarea, {
									...p,
									rows: 2,
									value: form.data.intro,
									onChange: (e) => form.setData("intro", e.target.value),
									maxLength: 400
								})
							}),
							/* @__PURE__ */ jsx(Field, {
								label: "Photograph description",
								name: "image_alt",
								error: err("image_alt"),
								required: true,
								children: (p) => /* @__PURE__ */ jsx(Input, {
									...p,
									value: form.data.image_alt,
									onChange: (e) => form.setData("image_alt", e.target.value),
									maxLength: 160
								})
							})
						]
					})
				}),
				/* @__PURE__ */ jsx(Panel, {
					title: "Milestones",
					description: "Short facts shown as a timeline, in order.",
					children: /* @__PURE__ */ jsxs("div", {
						className: "space-y-3",
						children: [form.data.milestones.map((m, i) => /* @__PURE__ */ jsxs("div", {
							className: "flex flex-wrap gap-2",
							children: [
								/* @__PURE__ */ jsx(Input, {
									"aria-label": `Milestone ${i + 1} place`,
									"aria-invalid": err(`milestones.${i}.place`) ? true : void 0,
									value: m.place,
									onChange: (e) => form.setData("milestones", form.data.milestones.map((x, j) => j === i ? {
										...x,
										place: e.target.value
									} : x)),
									className: "max-w-40",
									maxLength: 40
								}),
								/* @__PURE__ */ jsx(Input, {
									"aria-label": `Milestone ${i + 1} text`,
									"aria-invalid": err(`milestones.${i}.text`) ? true : void 0,
									value: m.text,
									onChange: (e) => form.setData("milestones", form.data.milestones.map((x, j) => j === i ? {
										...x,
										text: e.target.value
									} : x)),
									className: "flex-1",
									maxLength: 200
								}),
								/* @__PURE__ */ jsx(Button, {
									type: "button",
									variant: "ghost",
									size: "icon",
									"aria-label": `Remove milestone ${i + 1}`,
									onClick: () => form.setData("milestones", form.data.milestones.filter((_, j) => j !== i)),
									children: /* @__PURE__ */ jsx(Trash2, { "aria-hidden": "true" })
								})
							]
						}, i)), form.data.milestones.length < 6 && /* @__PURE__ */ jsxs(Button, {
							type: "button",
							variant: "ghost",
							size: "sm",
							onClick: () => form.setData("milestones", [...form.data.milestones, {
								place: "",
								text: ""
							}]),
							children: [/* @__PURE__ */ jsx(Plus, { "aria-hidden": "true" }), " Add milestone"]
						})]
					})
				}),
				form.data.chapters.map((c, i) => /* @__PURE__ */ jsx(Panel, {
					title: c.title || `Chapter ${i + 1}`,
					actions: form.data.chapters.length > 1 && /* @__PURE__ */ jsxs(Button, {
						type: "button",
						variant: "ghost",
						size: "sm",
						className: "text-clay",
						onClick: () => form.setData("chapters", form.data.chapters.filter((_, j) => j !== i)),
						children: [/* @__PURE__ */ jsx(Trash2, { "aria-hidden": "true" }), " Remove"]
					}),
					children: /* @__PURE__ */ jsxs("div", {
						className: "space-y-4",
						children: [/* @__PURE__ */ jsxs("div", {
							className: "grid gap-4 sm:grid-cols-3",
							children: [/* @__PURE__ */ jsx(Field, {
								label: "Title",
								name: `chapters.${i}.title`,
								error: err(`chapters.${i}.title`),
								required: true,
								className: "sm:col-span-2",
								children: (p) => /* @__PURE__ */ jsx(Input, {
									...p,
									value: c.title,
									onChange: (e) => form.setData("chapters", form.data.chapters.map((x, j) => j === i ? {
										...x,
										title: e.target.value
									} : x)),
									maxLength: 80
								})
							}), /* @__PURE__ */ jsx(Field, {
								label: "Link name",
								name: `chapters.${i}.key`,
								error: err(`chapters.${i}.key`),
								hint: `/our-story#${c.key || "…"}`,
								required: true,
								children: (p) => /* @__PURE__ */ jsx(Input, {
									...p,
									value: c.key,
									onChange: (e) => form.setData("chapters", form.data.chapters.map((x, j) => j === i ? {
										...x,
										key: e.target.value
									} : x)),
									maxLength: 30
								})
							})]
						}), /* @__PURE__ */ jsx(Field, {
							label: "Text",
							name: `chapters.${i}.body`,
							error: err(`chapters.${i}.body`),
							required: true,
							children: (p) => /* @__PURE__ */ jsx(Textarea, {
								...p,
								rows: 12,
								className: "font-serif",
								value: c.body,
								onChange: (e) => form.setData("chapters", form.data.chapters.map((x, j) => j === i ? {
									...x,
									body: e.target.value
								} : x))
							})
						})]
					})
				}, i)),
				form.data.chapters.length < 6 && /* @__PURE__ */ jsxs(Button, {
					type: "button",
					variant: "secondary",
					onClick: () => form.setData("chapters", [...form.data.chapters, {
						key: "",
						title: "",
						body: ""
					}]),
					children: [/* @__PURE__ */ jsx(Plus, { "aria-hidden": "true" }), " Add chapter"]
				}),
				/* @__PURE__ */ jsx(Panel, {
					title: "Closing",
					children: /* @__PURE__ */ jsxs("div", {
						className: "space-y-4",
						children: [/* @__PURE__ */ jsx(Field, {
							label: "Closing text",
							name: "closing",
							error: err("closing"),
							optional: true,
							children: (p) => /* @__PURE__ */ jsx(Textarea, {
								...p,
								rows: 3,
								value: form.data.closing,
								onChange: (e) => form.setData("closing", e.target.value),
								maxLength: 600
							})
						}), /* @__PURE__ */ jsx(Field, {
							label: "Note at the end",
							name: "disclaimer",
							error: err("disclaimer"),
							hint: "Keep a sentence saying the story is personal and not medical advice.",
							optional: true,
							children: (p) => /* @__PURE__ */ jsx(Textarea, {
								...p,
								rows: 2,
								value: form.data.disclaimer,
								onChange: (e) => form.setData("disclaimer", e.target.value),
								maxLength: 600
							})
						})]
					})
				}),
				/* @__PURE__ */ jsx("div", {
					className: "sticky bottom-0 z-10 flex justify-end border-t border-line bg-panel/95 py-3 backdrop-blur",
					children: /* @__PURE__ */ jsx(Button, {
						type: "submit",
						loading: form.processing,
						children: "Save story"
					})
				})
			]
		})]
	})] });
}
//#endregion
export { ContentStory as default };
