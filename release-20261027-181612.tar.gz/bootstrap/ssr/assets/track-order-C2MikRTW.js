import { t as useShared } from "./use-shared-BMnpkZPP.js";
import { t as formatMoney } from "./money-CcsjAkm_.js";
import { t as Input, v as Button } from "../ssr.js";
import { t as Badge } from "./badge-ChM6xC7L.js";
import { t as formatDate } from "./date-x_Fsbx42.js";
import { t as Field } from "./field-BVcOZvwI.js";
import { useForm } from "@inertiajs/react";
import { jsx, jsxs } from "react/jsx-runtime";
//#region resources/js/pages/track-order.tsx
function TrackOrder({ order }) {
	const { store } = useShared();
	const form = useForm({
		reference: "",
		phone: ""
	});
	const submit = (e) => {
		e.preventDefault();
		form.post("/track-order", { preserveScroll: true });
	};
	return /* @__PURE__ */ jsxs("div", {
		className: "container-page grid gap-12 py-12 lg:grid-cols-12 lg:py-20",
		children: [/* @__PURE__ */ jsxs("div", {
			className: "lg:col-span-5",
			children: [
				/* @__PURE__ */ jsx("h1", {
					className: "font-display text-display-sm",
					children: "Track your order"
				}),
				/* @__PURE__ */ jsx("p", {
					className: "mt-4 text-lg text-stone",
					children: "Enter the reference shown after you ordered and the phone number you used."
				}),
				/* @__PURE__ */ jsxs("form", {
					onSubmit: submit,
					noValidate: true,
					className: "mt-8 space-y-5",
					children: [
						/* @__PURE__ */ jsx(Field, {
							label: "Order reference",
							name: "reference",
							error: form.errors.reference,
							hint: "For example AS-2610-K7Q3X",
							required: true,
							children: (p) => /* @__PURE__ */ jsx(Input, {
								...p,
								value: form.data.reference,
								onChange: (e) => form.setData("reference", e.target.value.toUpperCase()),
								autoCapitalize: "characters",
								autoComplete: "off",
								maxLength: 20
							})
						}),
						/* @__PURE__ */ jsx(Field, {
							label: "Phone number",
							name: "phone",
							error: form.errors.phone,
							required: true,
							children: (p) => /* @__PURE__ */ jsx(Input, {
								...p,
								type: "tel",
								inputMode: "tel",
								autoComplete: "tel",
								value: form.data.phone,
								onChange: (e) => form.setData("phone", e.target.value),
								maxLength: 30
							})
						}),
						/* @__PURE__ */ jsx(Button, {
							type: "submit",
							loading: form.processing,
							children: "Find my order"
						})
					]
				})
			]
		}), /* @__PURE__ */ jsx("div", {
			className: "lg:col-span-6 lg:col-start-7",
			"aria-live": "polite",
			children: order && /* @__PURE__ */ jsxs("section", {
				className: "rounded-lg border border-line bg-white p-6",
				children: [
					/* @__PURE__ */ jsxs("div", {
						className: "flex flex-wrap items-center justify-between gap-3",
						children: [/* @__PURE__ */ jsxs("h2", {
							className: "font-display text-2xl",
							children: ["Order ", order.reference]
						}), /* @__PURE__ */ jsx(Badge, {
							tone: order.status === "DELIVERED" ? "success" : order.status === "CANCELLED" ? "danger" : "info",
							children: order.status_label
						})]
					}),
					/* @__PURE__ */ jsxs("p", {
						className: "mt-2 text-sm text-stone",
						children: ["Placed on ", formatDate(order.placed_at, store.timezone)]
					}),
					/* @__PURE__ */ jsx("p", {
						className: "mt-5 text-lg",
						children: order.status_message
					}),
					/* @__PURE__ */ jsx("ul", {
						className: "mt-5 divide-y divide-line border-y border-line text-[0.95rem]",
						children: order.items.map((item, i) => /* @__PURE__ */ jsxs("li", {
							className: "py-2.5",
							children: [
								item.name,
								item.variant && /* @__PURE__ */ jsxs("span", {
									className: "text-stone",
									children: [" — ", item.variant]
								}),
								/* @__PURE__ */ jsxs("span", {
									className: "text-stone",
									children: [" × ", item.quantity]
								})
							]
						}, i))
					}),
					/* @__PURE__ */ jsxs("p", {
						className: "mt-4 flex justify-between",
						children: [/* @__PURE__ */ jsx("span", {
							className: "text-stone",
							children: "To pay on delivery"
						}), /* @__PURE__ */ jsx("span", {
							className: "font-medium tabular-nums",
							children: formatMoney(order.total_minor, order.currency)
						})]
					})
				]
			})
		})]
	});
}
//#endregion
export { TrackOrder as default };
