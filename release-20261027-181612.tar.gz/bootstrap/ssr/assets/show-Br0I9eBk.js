import { t as cn } from "./utils-BqvNF826.js";
import { t as useShared } from "./use-shared-BMnpkZPP.js";
import { t as formatMoney } from "./money-CcsjAkm_.js";
import { b as useCartUi, d as ProductPlaceholder, h as Price, m as QuantityStepper, p as ResponsiveImage, v as Button } from "../ssr.js";
import { n as ProductCard, t as MOTIF_BY_CATEGORY } from "./product-card-Czb8w07c.js";
import { t as SectionHeading } from "./section-heading-DbvWb44b.js";
import { t as SafeHtml } from "./safe-html-DgcSMhDG.js";
import { t as Breadcrumbs } from "./breadcrumbs-D6WOVEz0.js";
import { Link, router } from "@inertiajs/react";
import { useState } from "react";
import { Fragment, jsx, jsxs } from "react/jsx-runtime";
import { Banknote, Truck } from "lucide-react";
//#region resources/js/pages/product/show.tsx
function ProductShow({ product, related, breadcrumbs, delivery }) {
	const { store, errors } = useShared();
	const orderingEnabled = store.ordering_enabled;
	const cart = useCartUi();
	const firstAvailable = product.variants.find((v) => v.in_stock) ?? product.variants[0];
	const [variantId, setVariantId] = useState(firstAvailable?.id ?? null);
	const [quantity, setQuantity] = useState(1);
	const [adding, setAdding] = useState(false);
	const [imageIndex, setImageIndex] = useState(0);
	const variant = product.variants.find((v) => v.id === variantId) ?? firstAvailable;
	const hasOptions = product.variants.length > 1;
	const mainImage = product.images[imageIndex] ?? product.images[0];
	const add = () => {
		if (!variant) return;
		router.post("/cart/items", {
			variant_id: variant.id,
			quantity
		}, {
			preserveScroll: true,
			onStart: () => setAdding(true),
			onFinish: () => setAdding(false),
			onSuccess: (page) => {
				if (!page.props.errors.quantity) {
					setQuantity(1);
					cart.open();
				}
			}
		});
	};
	return /* @__PURE__ */ jsxs(Fragment, { children: [
		/* @__PURE__ */ jsx("div", {
			className: "container-page pt-6 lg:pt-8",
			children: /* @__PURE__ */ jsx(Breadcrumbs, { items: breadcrumbs })
		}),
		/* @__PURE__ */ jsxs("div", {
			className: "container-page grid gap-10 pt-6 pb-16 lg:grid-cols-12 lg:gap-12",
			children: [/* @__PURE__ */ jsxs("section", {
				"aria-label": "Product images",
				className: "lg:col-span-7",
				children: [/* @__PURE__ */ jsx("div", {
					className: "aspect-[4/5] overflow-hidden",
					style: { backgroundColor: product.category.tint },
					children: mainImage ? /* @__PURE__ */ jsx(ResponsiveImage, {
						image: mainImage,
						sizes: "(min-width: 1024px) 55vw, 100vw",
						priority: true
					}) : /* @__PURE__ */ jsx(ProductPlaceholder, {
						tint: product.category.tint,
						motif: MOTIF_BY_CATEGORY[product.category.slug]
					})
				}), product.images.length > 1 && /* @__PURE__ */ jsx("ul", {
					className: "mt-3 grid grid-cols-5 gap-3",
					children: product.images.map((img, i) => /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsx("button", {
						type: "button",
						onClick: () => setImageIndex(i),
						className: cn("block aspect-square w-full overflow-hidden ring-offset-2 ring-offset-ivory transition", i === imageIndex ? "ring-2 ring-ink" : "opacity-80 hover:opacity-100"),
						"aria-label": `Show image ${i + 1} of ${product.images.length}`,
						"aria-pressed": i === imageIndex,
						children: /* @__PURE__ */ jsx(ResponsiveImage, {
							image: img,
							sizes: "120px",
							alt: ""
						})
					}) }, img.src))
				})]
			}), /* @__PURE__ */ jsx("section", {
				"aria-labelledby": "product-title",
				className: "lg:col-span-5",
				children: /* @__PURE__ */ jsxs("div", {
					className: "lg:sticky lg:top-28",
					children: [
						/* @__PURE__ */ jsx(Link, {
							href: `/shop/${product.category.slug}`,
							className: "text-sm text-dune-deep hover:underline hover:underline-offset-4",
							children: product.category.name
						}),
						/* @__PURE__ */ jsx("h1", {
							id: "product-title",
							className: "mt-2 font-display text-display-sm",
							children: product.name
						}),
						/* @__PURE__ */ jsx("p", {
							className: "mt-4 text-xl",
							children: variant ? /* @__PURE__ */ jsx(Price, {
								amount: variant.price_minor,
								regular: variant.regular_price_minor
							}) : null
						}),
						product.summary && /* @__PURE__ */ jsx("p", {
							className: "mt-4 text-lg text-stone",
							children: product.summary
						}),
						hasOptions && /* @__PURE__ */ jsxs("fieldset", {
							className: "mt-8",
							children: [/* @__PURE__ */ jsxs("legend", {
								className: "mb-3 text-sm font-medium",
								children: [
									product.option_label ?? "Option",
									": ",
									/* @__PURE__ */ jsx("span", {
										className: "font-normal text-stone",
										children: variant?.name
									})
								]
							}), /* @__PURE__ */ jsx("div", {
								className: "flex flex-wrap gap-2",
								children: product.variants.map((v) => /* @__PURE__ */ jsxs("label", {
									className: cn("relative inline-flex h-11 cursor-pointer items-center rounded-full border px-5 text-[0.95rem] transition-colors has-[:focus-visible]:outline-2 has-[:focus-visible]:outline-offset-2 has-[:focus-visible]:outline-aloe", v.id === variant?.id ? "border-ink bg-ink text-ivory" : "border-line bg-white hover:border-ink", !v.in_stock && "text-stone line-through decoration-1"),
									children: [
										/* @__PURE__ */ jsx("input", {
											type: "radio",
											name: "variant",
											value: v.id,
											checked: v.id === variant?.id,
											onChange: () => {
												setVariantId(v.id);
												setQuantity(1);
											},
											className: "sr-only"
										}),
										v.name,
										!v.in_stock && /* @__PURE__ */ jsx("span", {
											className: "sr-only",
											children: " (out of stock)"
										})
									]
								}, v.id))
							})]
						}),
						/* @__PURE__ */ jsx("div", {
							className: "mt-8",
							children: variant?.in_stock ? /* @__PURE__ */ jsxs(Fragment, { children: [
								/* @__PURE__ */ jsxs("div", {
									className: "flex flex-wrap items-center gap-3",
									children: [/* @__PURE__ */ jsx(QuantityStepper, {
										label: "Quantity",
										value: quantity,
										max: variant.max_quantity,
										onChange: setQuantity
									}), /* @__PURE__ */ jsx(Button, {
										size: "lg",
										className: "min-w-52 flex-1",
										loading: adding,
										onClick: add,
										disabled: !orderingEnabled,
										children: "Add to cart"
									})]
								}),
								variant.low_stock && /* @__PURE__ */ jsx("p", {
									className: "mt-3 text-sm text-dune-deep",
									children: "Only a few left."
								}),
								errors.quantity && /* @__PURE__ */ jsx("p", {
									className: "mt-3 text-sm text-clay",
									role: "alert",
									children: errors.quantity
								}),
								!orderingEnabled && /* @__PURE__ */ jsx("p", {
									className: "mt-3 text-sm text-stone",
									children: "Online ordering is paused at the moment."
								})
							] }) : /* @__PURE__ */ jsxs("p", {
								className: "rounded-(--radius-control) bg-sand px-4 py-3 text-stone",
								children: [
									hasOptions ? "This option is out of stock." : "This product is out of stock.",
									" Please check back soon or",
									" ",
									/* @__PURE__ */ jsx(Link, {
										href: "/contact",
										className: "underline underline-offset-4",
										children: "contact us"
									}),
									"."
								]
							})
						}),
						/* @__PURE__ */ jsxs("div", {
							className: "mt-8 divide-y divide-line border-y border-line text-[0.95rem]",
							children: [/* @__PURE__ */ jsxs("div", {
								className: "flex gap-4 py-4",
								children: [/* @__PURE__ */ jsx(Banknote, {
									className: "mt-0.5 size-5 shrink-0 text-dune",
									strokeWidth: 1.5,
									"aria-hidden": "true"
								}), /* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx("p", {
									className: "font-medium",
									children: "Cash on delivery"
								}), /* @__PURE__ */ jsx("p", {
									className: "text-stone",
									children: delivery.cod_instructions
								})] })]
							}), delivery.zones.length > 0 && /* @__PURE__ */ jsxs("details", {
								className: "group py-4",
								children: [
									/* @__PURE__ */ jsxs("summary", {
										className: "flex cursor-pointer list-none gap-4 [&::-webkit-details-marker]:hidden",
										children: [/* @__PURE__ */ jsx(Truck, {
											className: "mt-0.5 size-5 shrink-0 text-dune",
											strokeWidth: 1.5,
											"aria-hidden": "true"
										}), /* @__PURE__ */ jsxs("span", {
											className: "flex-1",
											children: [/* @__PURE__ */ jsx("span", {
												className: "block font-medium",
												children: "Delivery"
											}), /* @__PURE__ */ jsxs("span", {
												className: "text-stone",
												children: [delivery.min_fee_minor !== null && `From ${formatMoney(delivery.min_fee_minor, store.currency)}. `, /* @__PURE__ */ jsx("span", {
													className: "underline underline-offset-4 group-open:hidden",
													children: "See delivery areas"
												})]
											})]
										})]
									}),
									/* @__PURE__ */ jsx("ul", {
										className: "mt-3 ml-9 space-y-1.5 text-stone",
										children: delivery.zones.map((z) => /* @__PURE__ */ jsxs("li", {
											className: "flex justify-between gap-4",
											children: [/* @__PURE__ */ jsxs("span", { children: [z.name, z.estimate && /* @__PURE__ */ jsxs("span", {
												className: "text-stone/80",
												children: [" · ", z.estimate]
											})] }), /* @__PURE__ */ jsxs("span", {
												className: "text-right tabular-nums",
												children: [formatMoney(z.fee_minor, store.currency), z.free_over_minor !== null && /* @__PURE__ */ jsxs("span", {
													className: "block text-xs",
													children: ["free over ", formatMoney(z.free_over_minor, store.currency)]
												})]
											})]
										}, z.name))
									}),
									delivery.info && /* @__PURE__ */ jsx("p", {
										className: "mt-3 ml-9 text-stone",
										children: delivery.info
									})
								]
							})]
						}),
						product.description_html && /* @__PURE__ */ jsxs("div", {
							className: "mt-10",
							children: [/* @__PURE__ */ jsx("h2", {
								className: "mb-4 font-display text-2xl",
								children: "About this product"
							}), /* @__PURE__ */ jsx(SafeHtml, {
								html: product.description_html,
								className: "prose-compact text-ink/90"
							})]
						}),
						product.specifications.length > 0 && /* @__PURE__ */ jsxs("div", {
							className: "mt-10",
							children: [/* @__PURE__ */ jsx("h2", {
								className: "mb-4 font-display text-2xl",
								children: "Details"
							}), /* @__PURE__ */ jsxs("dl", {
								className: "divide-y divide-line border-y border-line",
								children: [product.specifications.map((s) => /* @__PURE__ */ jsxs("div", {
									className: "grid grid-cols-3 gap-4 py-3 text-[0.95rem]",
									children: [/* @__PURE__ */ jsx("dt", {
										className: "text-stone",
										children: s.label
									}), /* @__PURE__ */ jsx("dd", {
										className: "col-span-2",
										children: s.value
									})]
								}, s.label)), variant?.sku && /* @__PURE__ */ jsxs("div", {
									className: "grid grid-cols-3 gap-4 py-3 text-[0.95rem]",
									children: [/* @__PURE__ */ jsx("dt", {
										className: "text-stone",
										children: "Reference"
									}), /* @__PURE__ */ jsx("dd", {
										className: "col-span-2",
										children: variant.sku
									})]
								})]
							})]
						})
					]
				})
			})]
		}),
		related.length > 0 && /* @__PURE__ */ jsxs("section", {
			className: "container-page border-t border-line pt-16",
			children: [/* @__PURE__ */ jsx(SectionHeading, {
				title: `More from ${product.category.name}`,
				link: {
					href: `/shop/${product.category.slug}`,
					label: "See all"
				}
			}), /* @__PURE__ */ jsx("div", {
				className: "mt-10 grid grid-cols-2 gap-x-4 gap-y-10 sm:gap-x-6 lg:grid-cols-4",
				children: related.map((p) => /* @__PURE__ */ jsx(ProductCard, { product: p }, p.id))
			})]
		})
	] });
}
//#endregion
export { ProductShow as default };
