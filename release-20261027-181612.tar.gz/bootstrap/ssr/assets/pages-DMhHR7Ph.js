import { t as useShared } from "./use-shared-BMnpkZPP.js";
import { t as Badge } from "./badge-ChM6xC7L.js";
import { a as Panel, d as th, l as Table, r as PageHeader, u as td } from "./ui-DQeK8Yrd.js";
import { t as formatDate } from "./date-x_Fsbx42.js";
import { Link } from "@inertiajs/react";
import { Fragment, jsx, jsxs } from "react/jsx-runtime";
//#region resources/js/pages/admin/pages/index.tsx
function Pages({ pages }) {
	const { store } = useShared();
	return /* @__PURE__ */ jsxs(Fragment, { children: [/* @__PURE__ */ jsx(PageHeader, {
		title: "Policy pages",
		description: "Legal and support pages. Text in [square brackets] must be completed with your business details before launch."
	}), /* @__PURE__ */ jsx(Panel, {
		padded: false,
		children: /* @__PURE__ */ jsxs(Table, { children: [/* @__PURE__ */ jsx("thead", { children: /* @__PURE__ */ jsxs("tr", { children: [
			/* @__PURE__ */ jsx("th", {
				className: th,
				children: "Page"
			}),
			/* @__PURE__ */ jsx("th", {
				className: th,
				children: "Status"
			}),
			/* @__PURE__ */ jsx("th", {
				className: th,
				children: "Last edited"
			})
		] }) }), /* @__PURE__ */ jsx("tbody", { children: pages.map((p) => /* @__PURE__ */ jsxs("tr", { children: [
			/* @__PURE__ */ jsxs("td", {
				className: td,
				children: [/* @__PURE__ */ jsx(Link, {
					href: `/admin/pages/${p.id}/edit`,
					className: "font-medium hover:underline",
					children: p.title
				}), /* @__PURE__ */ jsxs("span", {
					className: "block text-xs text-stone",
					children: ["/", p.slug]
				})]
			}),
			/* @__PURE__ */ jsx("td", {
				className: td,
				children: /* @__PURE__ */ jsxs("span", {
					className: "flex flex-wrap gap-1.5",
					children: [
						p.needs_review && /* @__PURE__ */ jsx(Badge, {
							tone: "warning",
							children: "Needs review"
						}),
						!p.is_published && /* @__PURE__ */ jsx(Badge, {
							tone: "neutral",
							children: "Hidden"
						}),
						p.is_published && !p.needs_review && /* @__PURE__ */ jsx(Badge, {
							tone: "success",
							children: "Live"
						})
					]
				})
			}),
			/* @__PURE__ */ jsx("td", {
				className: `${td} text-stone`,
				children: formatDate(p.updated_at, store.timezone)
			})
		] }, p.id)) })] })
	})] });
}
//#endregion
export { Pages as default };
