import { v as Button } from "../ssr.js";
import { Link, usePage } from "@inertiajs/react";
import { jsx, jsxs } from "react/jsx-runtime";
//#region resources/js/pages/error.tsx
var MESSAGES = {
	403: {
		title: "You don’t have access to this page.",
		text: "If you think you should, ask the shop owner to check your account."
	},
	404: {
		title: "This page doesn’t exist.",
		text: "It may have moved, or the address may be mistyped."
	},
	410: {
		title: "This page has been removed.",
		text: "The item is no longer available."
	},
	429: {
		title: "Too many requests.",
		text: "Please wait a minute and try again."
	},
	500: {
		title: "Something went wrong on our side.",
		text: "Please try again in a moment. If it keeps happening, contact us and quote the reference below."
	},
	503: {
		title: "We’ll be right back.",
		text: "The shop is being updated. Please try again in a few minutes."
	}
};
function ErrorPage({ status, request_id }) {
	const { url } = usePage();
	const message = MESSAGES[status] ?? MESSAGES[500];
	const isAdmin = url.startsWith("/admin");
	return /* @__PURE__ */ jsxs("section", {
		className: "container-page max-w-2xl py-24 text-center",
		children: [
			/* @__PURE__ */ jsx("p", {
				className: "font-display text-6xl text-dune",
				children: status
			}),
			/* @__PURE__ */ jsx("h1", {
				className: "mt-4 font-display text-display-sm",
				children: message.title
			}),
			/* @__PURE__ */ jsx("p", {
				className: "mt-4 text-lg text-stone",
				children: message.text
			}),
			status >= 500 && request_id && /* @__PURE__ */ jsxs("p", {
				className: "mt-4 text-sm text-stone",
				children: ["Reference: ", request_id]
			}),
			/* @__PURE__ */ jsxs("div", {
				className: "mt-10 flex flex-wrap justify-center gap-3",
				children: [/* @__PURE__ */ jsx(Button, {
					asChild: true,
					children: /* @__PURE__ */ jsx(Link, {
						href: isAdmin ? "/admin" : "/",
						children: isAdmin ? "Back to the dashboard" : "Go to the home page"
					})
				}), !isAdmin && /* @__PURE__ */ jsx(Button, {
					asChild: true,
					variant: "secondary",
					children: /* @__PURE__ */ jsx(Link, {
						href: "/shop",
						children: "Browse the shop"
					})
				})]
			})
		]
	});
}
//#endregion
export { ErrorPage as default };
