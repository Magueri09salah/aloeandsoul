import { t as cn } from "./utils-BqvNF826.js";
import { n as Label } from "../ssr.js";
import * as React from "react";
import { Fragment, jsx, jsxs } from "react/jsx-runtime";
//#region resources/js/components/ui/field.tsx
/**
* Label + control + hint + error, wired together with ids so screen readers
* announce the hint and the error with the control.
*/
function Field({ label, name, error, hint, required, optional, className, children }) {
	const id = `${React.useId()}-${name}`;
	const hintId = hint ? `${id}-hint` : void 0;
	const errorId = error ? `${id}-error` : void 0;
	return /* @__PURE__ */ jsxs("div", {
		className: cn("flex flex-col gap-1.5", className),
		children: [
			/* @__PURE__ */ jsxs(Label, {
				htmlFor: id,
				children: [label, optional && /* @__PURE__ */ jsx("span", {
					className: "ml-1 font-normal text-stone",
					children: "(optional)"
				})]
			}),
			children({
				id,
				name,
				required,
				"aria-invalid": error ? true : void 0,
				"aria-describedby": [hintId, errorId].filter(Boolean).join(" ") || void 0
			}),
			hint && /* @__PURE__ */ jsx("p", {
				id: hintId,
				className: "text-sm text-stone",
				children: hint
			}),
			error && /* @__PURE__ */ jsx("p", {
				id: errorId,
				className: "text-sm text-clay",
				role: "alert",
				children: error
			})
		]
	});
}
/** Summary of errors at the top of a form; focus moves here on failed submit. */
function FormErrorSummary({ errors, className }) {
	const messages = Object.values(errors).filter((m) => Boolean(m));
	const ref = React.useRef(null);
	React.useEffect(() => {
		if (messages.length > 0) ref.current?.focus();
	}, [messages.length]);
	if (messages.length === 0) return null;
	return /* @__PURE__ */ jsx("div", {
		ref,
		tabIndex: -1,
		role: "alert",
		className: cn("rounded-(--radius-control) border border-clay/40 bg-clay-soft px-4 py-3 text-sm text-clay", className),
		children: messages.length === 1 ? /* @__PURE__ */ jsx("p", { children: messages[0] }) : /* @__PURE__ */ jsxs(Fragment, { children: [/* @__PURE__ */ jsx("p", {
			className: "font-medium",
			children: "Please check the following:"
		}), /* @__PURE__ */ jsx("ul", {
			className: "mt-1 list-disc pl-5",
			children: messages.map((m) => /* @__PURE__ */ jsx("li", { children: m }, m))
		})] })
	});
}
//#endregion
export { FormErrorSummary as n, Field as t };
