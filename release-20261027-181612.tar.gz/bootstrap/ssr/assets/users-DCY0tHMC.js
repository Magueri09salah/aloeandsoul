import { t as useShared } from "./use-shared-BMnpkZPP.js";
import { l as Switch, n as Label, o as Dialog, r as Select, s as DialogContent, t as Input, v as Button } from "../ssr.js";
import { t as Badge } from "./badge-ChM6xC7L.js";
import { a as Panel, d as th, l as Table, r as PageHeader, u as td } from "./ui-DQeK8Yrd.js";
import { n as formatDateTime } from "./date-x_Fsbx42.js";
import { t as Field } from "./field-BVcOZvwI.js";
import { useForm } from "@inertiajs/react";
import { useState } from "react";
import { Fragment, jsx, jsxs } from "react/jsx-runtime";
import { Plus } from "lucide-react";
//#region resources/js/pages/admin/users/index.tsx
function Users({ users, roles }) {
	const { store } = useShared();
	const [creating, setCreating] = useState(false);
	const [editing, setEditing] = useState(null);
	return /* @__PURE__ */ jsxs(Fragment, { children: [
		/* @__PURE__ */ jsx(PageHeader, {
			title: "Team",
			description: "People who can sign in to this admin. Accounts are switched off rather than deleted, so the activity log keeps its history.",
			actions: /* @__PURE__ */ jsxs(Button, {
				onClick: () => setCreating(true),
				children: [/* @__PURE__ */ jsx(Plus, { "aria-hidden": "true" }), " Add person"]
			})
		}),
		/* @__PURE__ */ jsx(Panel, {
			padded: false,
			children: /* @__PURE__ */ jsxs(Table, { children: [/* @__PURE__ */ jsx("thead", { children: /* @__PURE__ */ jsxs("tr", { children: [
				/* @__PURE__ */ jsx("th", {
					className: th,
					children: "Name"
				}),
				/* @__PURE__ */ jsx("th", {
					className: th,
					children: "Role"
				}),
				/* @__PURE__ */ jsx("th", {
					className: th,
					children: "Security"
				}),
				/* @__PURE__ */ jsx("th", {
					className: th,
					children: "Last sign-in"
				}),
				/* @__PURE__ */ jsx("th", {
					className: th,
					children: /* @__PURE__ */ jsx("span", {
						className: "sr-only",
						children: "Actions"
					})
				})
			] }) }), /* @__PURE__ */ jsx("tbody", { children: users.map((u) => /* @__PURE__ */ jsxs("tr", { children: [
				/* @__PURE__ */ jsxs("td", {
					className: td,
					children: [
						/* @__PURE__ */ jsx("span", {
							className: "font-medium",
							children: u.name
						}),
						u.is_me && /* @__PURE__ */ jsx("span", {
							className: "text-stone",
							children: " (you)"
						}),
						/* @__PURE__ */ jsx("span", {
							className: "block text-xs text-stone",
							children: u.email
						})
					]
				}),
				/* @__PURE__ */ jsxs("td", {
					className: td,
					children: [
						u.role_label,
						" ",
						!u.is_active && /* @__PURE__ */ jsx(Badge, {
							tone: "neutral",
							children: "Off"
						})
					]
				}),
				/* @__PURE__ */ jsx("td", {
					className: td,
					children: u.two_factor ? /* @__PURE__ */ jsx(Badge, {
						tone: "success",
						children: "Two-factor on"
					}) : /* @__PURE__ */ jsx(Badge, {
						tone: "warning",
						children: "Password only"
					})
				}),
				/* @__PURE__ */ jsx("td", {
					className: `${td} text-stone`,
					children: formatDateTime(u.last_login_at, store.timezone)
				}),
				/* @__PURE__ */ jsx("td", {
					className: `${td} text-right`,
					children: /* @__PURE__ */ jsx(Button, {
						size: "sm",
						variant: "ghost",
						onClick: () => setEditing(u),
						children: "Edit"
					})
				})
			] }, u.id)) })] })
		}),
		/* @__PURE__ */ jsx(Panel, {
			title: "What each role can do",
			className: "mt-6",
			children: /* @__PURE__ */ jsx("dl", {
				className: "grid gap-4 sm:grid-cols-3",
				children: roles.map((r) => /* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx("dt", {
					className: "font-medium",
					children: r.label
				}), /* @__PURE__ */ jsx("dd", {
					className: "mt-1 text-sm text-stone",
					children: r.description
				})] }, r.value))
			})
		}),
		/* @__PURE__ */ jsx(Dialog, {
			open: creating,
			onOpenChange: setCreating,
			children: creating && /* @__PURE__ */ jsx(DialogContent, {
				title: "Add a person",
				description: "They sign in with this email and password, then should change the password and turn on two-factor authentication.",
				children: /* @__PURE__ */ jsx(CreateForm, {
					roles,
					onDone: () => setCreating(false)
				})
			})
		}),
		/* @__PURE__ */ jsx(Dialog, {
			open: editing !== null,
			onOpenChange: (o) => !o && setEditing(null),
			children: editing && /* @__PURE__ */ jsx(DialogContent, {
				title: `Edit ${editing.name}`,
				children: /* @__PURE__ */ jsx(EditForm, {
					user: editing,
					roles,
					onDone: () => setEditing(null)
				})
			})
		})
	] });
}
function CreateForm({ roles, onDone }) {
	const form = useForm({
		name: "",
		email: "",
		role: "staff",
		password: "",
		password_confirmation: ""
	});
	const submit = (e) => {
		e.preventDefault();
		form.post("/admin/users", {
			preserveScroll: true,
			onSuccess: onDone,
			onFinish: () => form.reset("password", "password_confirmation")
		});
	};
	return /* @__PURE__ */ jsxs("form", {
		onSubmit: submit,
		noValidate: true,
		className: "space-y-4",
		children: [
			/* @__PURE__ */ jsx(Field, {
				label: "Name",
				name: "name",
				error: form.errors.name,
				required: true,
				children: (p) => /* @__PURE__ */ jsx(Input, {
					...p,
					value: form.data.name,
					onChange: (e) => form.setData("name", e.target.value)
				})
			}),
			/* @__PURE__ */ jsx(Field, {
				label: "Email",
				name: "email",
				error: form.errors.email,
				required: true,
				children: (p) => /* @__PURE__ */ jsx(Input, {
					...p,
					type: "email",
					value: form.data.email,
					onChange: (e) => form.setData("email", e.target.value),
					autoComplete: "off"
				})
			}),
			/* @__PURE__ */ jsx(Field, {
				label: "Role",
				name: "role",
				error: form.errors.role,
				children: (p) => /* @__PURE__ */ jsx(Select, {
					...p,
					value: form.data.role,
					onChange: (e) => form.setData("role", e.target.value),
					children: roles.map((r) => /* @__PURE__ */ jsx("option", {
						value: r.value,
						children: r.label
					}, r.value))
				})
			}),
			/* @__PURE__ */ jsx(Field, {
				label: "Temporary password",
				name: "password",
				error: form.errors.password,
				hint: "At least 12 characters, with upper and lower case letters and a number.",
				required: true,
				children: (p) => /* @__PURE__ */ jsx(Input, {
					...p,
					type: "password",
					autoComplete: "new-password",
					value: form.data.password,
					onChange: (e) => form.setData("password", e.target.value)
				})
			}),
			/* @__PURE__ */ jsx(Field, {
				label: "Confirm password",
				name: "password_confirmation",
				error: form.errors.password_confirmation,
				required: true,
				children: (p) => /* @__PURE__ */ jsx(Input, {
					...p,
					type: "password",
					autoComplete: "new-password",
					value: form.data.password_confirmation,
					onChange: (e) => form.setData("password_confirmation", e.target.value)
				})
			}),
			/* @__PURE__ */ jsx("div", {
				className: "flex justify-end",
				children: /* @__PURE__ */ jsx(Button, {
					type: "submit",
					loading: form.processing,
					children: "Create account"
				})
			})
		]
	});
}
function EditForm({ user, roles, onDone }) {
	const form = useForm({
		role: user.role,
		is_active: user.is_active
	});
	const submit = (e) => {
		e.preventDefault();
		form.put(`/admin/users/${user.id}`, {
			preserveScroll: true,
			onSuccess: onDone
		});
	};
	return /* @__PURE__ */ jsxs("form", {
		onSubmit: submit,
		noValidate: true,
		className: "space-y-4",
		children: [
			/* @__PURE__ */ jsx(Field, {
				label: "Role",
				name: "role",
				error: form.errors.role,
				children: (p) => /* @__PURE__ */ jsx(Select, {
					...p,
					value: form.data.role,
					onChange: (e) => form.setData("role", e.target.value),
					children: roles.map((r) => /* @__PURE__ */ jsx("option", {
						value: r.value,
						children: r.label
					}, r.value))
				})
			}),
			/* @__PURE__ */ jsxs("div", {
				className: "flex items-center gap-3",
				children: [/* @__PURE__ */ jsx(Switch, {
					id: "active",
					checked: form.data.is_active,
					onCheckedChange: (v) => form.setData("is_active", v)
				}), /* @__PURE__ */ jsx(Label, {
					htmlFor: "active",
					className: "font-normal",
					children: "Can sign in"
				})]
			}),
			!form.data.is_active && /* @__PURE__ */ jsx("p", {
				className: "text-sm text-stone",
				children: "Switching this off signs them out everywhere immediately."
			}),
			/* @__PURE__ */ jsx("div", {
				className: "flex justify-end",
				children: /* @__PURE__ */ jsx(Button, {
					type: "submit",
					loading: form.processing,
					children: "Save"
				})
			})
		]
	});
}
//#endregion
export { Users as default };
