import { i as Textarea, l as Switch, n as Label, r as Select, t as Input, v as Button } from "../ssr.js";
import { a as Panel, r as PageHeader } from "./ui-DQeK8Yrd.js";
import { t as Field } from "./field-BVcOZvwI.js";
import { useForm } from "@inertiajs/react";
import { Fragment, jsx, jsxs } from "react/jsx-runtime";
import { Plus, Trash2 } from "lucide-react";
//#region resources/js/pages/admin/settings.tsx
function SaveBar({ processing, label = "Save" }) {
	return /* @__PURE__ */ jsx("div", {
		className: "mt-5 flex justify-end border-t border-line pt-4",
		children: /* @__PURE__ */ jsx(Button, {
			type: "submit",
			loading: processing,
			children: label
		})
	});
}
function Section({ title, description, onSubmit, children }) {
	return /* @__PURE__ */ jsx(Panel, {
		title,
		description,
		children: /* @__PURE__ */ jsx("form", {
			onSubmit,
			noValidate: true,
			children
		})
	});
}
function Settings({ settings, currencies, hasOrders }) {
	const store = useForm(settings.store);
	const checkout = useForm(settings.checkout);
	const contact = useForm(settings.contact);
	const social = useForm(settings.social);
	const seo = useForm(settings.seo);
	const save = (form, group) => (e) => {
		e.preventDefault();
		form.put(`/admin/settings/${group}`, { preserveScroll: true });
	};
	return /* @__PURE__ */ jsxs(Fragment, { children: [/* @__PURE__ */ jsx(PageHeader, {
		title: "Settings",
		description: "Store-wide settings. Only owners can change these."
	}), /* @__PURE__ */ jsxs("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ jsxs(Section, {
				title: "Store",
				onSubmit: save(store, "store"),
				children: [
					/* @__PURE__ */ jsxs("div", {
						className: "grid gap-4 sm:grid-cols-2",
						children: [
							/* @__PURE__ */ jsx(Field, {
								label: "Store name",
								name: "name",
								error: store.errors.name,
								required: true,
								children: (p) => /* @__PURE__ */ jsx(Input, {
									...p,
									value: store.data.name,
									onChange: (e) => store.setData("name", e.target.value)
								})
							}),
							/* @__PURE__ */ jsx(Field, {
								label: "Tagline",
								name: "tagline",
								error: store.errors.tagline,
								optional: true,
								children: (p) => /* @__PURE__ */ jsx(Input, {
									...p,
									value: store.data.tagline,
									onChange: (e) => store.setData("tagline", e.target.value)
								})
							}),
							/* @__PURE__ */ jsx(Field, {
								label: "Currency",
								name: "currency",
								error: store.errors.currency,
								hint: hasOrders ? "Prices are not converted when you change currency." : void 0,
								children: (p) => /* @__PURE__ */ jsx(Select, {
									...p,
									value: store.data.currency,
									onChange: (e) => store.setData("currency", e.target.value),
									children: currencies.map((c) => /* @__PURE__ */ jsx("option", { children: c }, c))
								})
							}),
							/* @__PURE__ */ jsxs("div", {
								className: "grid grid-cols-3 gap-3",
								children: [/* @__PURE__ */ jsx(Field, {
									label: "Country code",
									name: "country",
									error: store.errors.country,
									hint: "e.g. MA",
									children: (p) => /* @__PURE__ */ jsx(Input, {
										...p,
										value: store.data.country,
										onChange: (e) => store.setData("country", e.target.value.toUpperCase()),
										maxLength: 2
									})
								}), /* @__PURE__ */ jsx(Field, {
									label: "Country name",
									name: "country_name",
									error: store.errors.country_name,
									className: "col-span-2",
									children: (p) => /* @__PURE__ */ jsx(Input, {
										...p,
										value: store.data.country_name,
										onChange: (e) => store.setData("country_name", e.target.value)
									})
								})]
							}),
							/* @__PURE__ */ jsx(Field, {
								label: "Order reference prefix",
								name: "order_prefix",
								error: store.errors.order_prefix,
								hint: "e.g. AS gives AS-2610-K7Q3X",
								children: (p) => /* @__PURE__ */ jsx(Input, {
									...p,
									value: store.data.order_prefix,
									onChange: (e) => store.setData("order_prefix", e.target.value.toUpperCase()),
									maxLength: 6
								})
							}),
							/* @__PURE__ */ jsxs("div", {
								className: "grid grid-cols-2 gap-3",
								children: [/* @__PURE__ */ jsx(Field, {
									label: "Low stock alert at",
									name: "low_stock_threshold",
									error: store.errors.low_stock_threshold,
									children: (p) => /* @__PURE__ */ jsx(Input, {
										...p,
										type: "number",
										min: 0,
										value: store.data.low_stock_threshold,
										onChange: (e) => store.setData("low_stock_threshold", Number(e.target.value))
									})
								}), /* @__PURE__ */ jsx(Field, {
									label: "Max per product",
									name: "max_quantity_per_line",
									error: store.errors.max_quantity_per_line,
									hint: "Per order line",
									children: (p) => /* @__PURE__ */ jsx(Input, {
										...p,
										type: "number",
										min: 1,
										max: 99,
										value: store.data.max_quantity_per_line,
										onChange: (e) => store.setData("max_quantity_per_line", Number(e.target.value))
									})
								})]
							})
						]
					}),
					/* @__PURE__ */ jsxs("div", {
						className: "mt-5 rounded-md border border-line p-4",
						children: [/* @__PURE__ */ jsxs("div", {
							className: "flex items-center gap-3",
							children: [/* @__PURE__ */ jsx(Switch, {
								id: "ordering",
								checked: store.data.ordering_enabled,
								onCheckedChange: (v) => store.setData("ordering_enabled", v)
							}), /* @__PURE__ */ jsx(Label, {
								htmlFor: "ordering",
								children: "Accept online orders"
							})]
						}), /* @__PURE__ */ jsx(Field, {
							label: "Message shown when ordering is paused",
							name: "closed_message",
							error: store.errors.closed_message,
							className: "mt-4",
							children: (p) => /* @__PURE__ */ jsx(Textarea, {
								...p,
								rows: 2,
								value: store.data.closed_message,
								onChange: (e) => store.setData("closed_message", e.target.value),
								maxLength: 300
							})
						})]
					}),
					/* @__PURE__ */ jsx(SaveBar, { processing: store.processing })
				]
			}),
			/* @__PURE__ */ jsxs(Section, {
				title: "Checkout and delivery",
				description: "Shown to customers at checkout and on product pages.",
				onSubmit: save(checkout, "checkout"),
				children: [/* @__PURE__ */ jsxs("div", {
					className: "space-y-4",
					children: [
						/* @__PURE__ */ jsx(Field, {
							label: "Cash on delivery instructions",
							name: "cod_instructions",
							error: checkout.errors.cod_instructions,
							required: true,
							children: (p) => /* @__PURE__ */ jsx(Textarea, {
								...p,
								rows: 2,
								value: checkout.data.cod_instructions,
								onChange: (e) => checkout.setData("cod_instructions", e.target.value),
								maxLength: 300
							})
						}),
						/* @__PURE__ */ jsx(Field, {
							label: "After ordering",
							name: "confirmation_note",
							error: checkout.errors.confirmation_note,
							hint: "e.g. We will call you to confirm your order.",
							optional: true,
							children: (p) => /* @__PURE__ */ jsx(Textarea, {
								...p,
								rows: 2,
								value: checkout.data.confirmation_note,
								onChange: (e) => checkout.setData("confirmation_note", e.target.value),
								maxLength: 300
							})
						}),
						/* @__PURE__ */ jsx(Field, {
							label: "Delivery information",
							name: "delivery_info",
							error: checkout.errors.delivery_info,
							hint: "Only state what you can guarantee.",
							optional: true,
							children: (p) => /* @__PURE__ */ jsx(Textarea, {
								...p,
								rows: 2,
								value: checkout.data.delivery_info,
								onChange: (e) => checkout.setData("delivery_info", e.target.value),
								maxLength: 300
							})
						})
					]
				}), /* @__PURE__ */ jsx(SaveBar, { processing: checkout.processing })]
			}),
			/* @__PURE__ */ jsxs(Section, {
				title: "Contact details",
				onSubmit: save(contact, "contact"),
				children: [
					/* @__PURE__ */ jsxs("div", {
						className: "grid gap-4 sm:grid-cols-3",
						children: [
							/* @__PURE__ */ jsx(Field, {
								label: "Email",
								name: "email",
								error: contact.errors.email,
								optional: true,
								children: (p) => /* @__PURE__ */ jsx(Input, {
									...p,
									type: "email",
									value: contact.data.email,
									onChange: (e) => contact.setData("email", e.target.value)
								})
							}),
							/* @__PURE__ */ jsx(Field, {
								label: "Phone",
								name: "phone",
								error: contact.errors.phone,
								optional: true,
								children: (p) => /* @__PURE__ */ jsx(Input, {
									...p,
									type: "tel",
									value: contact.data.phone,
									onChange: (e) => contact.setData("phone", e.target.value)
								})
							}),
							/* @__PURE__ */ jsx(Field, {
								label: "WhatsApp",
								name: "whatsapp",
								error: contact.errors.whatsapp,
								optional: true,
								children: (p) => /* @__PURE__ */ jsx(Input, {
									...p,
									type: "tel",
									value: contact.data.whatsapp,
									onChange: (e) => contact.setData("whatsapp", e.target.value)
								})
							}),
							/* @__PURE__ */ jsx(Field, {
								label: "Opening hours",
								name: "hours",
								error: contact.errors.hours,
								optional: true,
								className: "sm:col-span-3",
								children: (p) => /* @__PURE__ */ jsx(Input, {
									...p,
									value: contact.data.hours,
									onChange: (e) => contact.setData("hours", e.target.value),
									maxLength: 120
								})
							})
						]
					}),
					/* @__PURE__ */ jsxs("fieldset", {
						className: "mt-4",
						children: [/* @__PURE__ */ jsx("legend", {
							className: "text-sm font-medium",
							children: "Locations"
						}), /* @__PURE__ */ jsxs("div", {
							className: "mt-2 flex flex-wrap gap-2",
							children: [contact.data.locations.map((l, i) => /* @__PURE__ */ jsxs("div", {
								className: "flex items-center gap-1",
								children: [/* @__PURE__ */ jsx(Input, {
									"aria-label": `Location ${i + 1}`,
									value: l,
									onChange: (e) => contact.setData("locations", contact.data.locations.map((x, j) => j === i ? e.target.value : x)),
									className: "w-40"
								}), /* @__PURE__ */ jsx(Button, {
									type: "button",
									variant: "ghost",
									size: "icon-sm",
									"aria-label": `Remove location ${i + 1}`,
									onClick: () => contact.setData("locations", contact.data.locations.filter((_, j) => j !== i)),
									children: /* @__PURE__ */ jsx(Trash2, { "aria-hidden": "true" })
								})]
							}, i)), contact.data.locations.length < 6 && /* @__PURE__ */ jsxs(Button, {
								type: "button",
								variant: "ghost",
								size: "sm",
								onClick: () => contact.setData("locations", [...contact.data.locations, ""]),
								children: [/* @__PURE__ */ jsx(Plus, { "aria-hidden": "true" }), " Add"]
							})]
						})]
					}),
					/* @__PURE__ */ jsx(SaveBar, { processing: contact.processing })
				]
			}),
			/* @__PURE__ */ jsxs(Section, {
				title: "Social media",
				description: "Full https:// links. Leave empty to hide.",
				onSubmit: save(social, "social"),
				children: [/* @__PURE__ */ jsx("div", {
					className: "grid gap-4 sm:grid-cols-2",
					children: [
						"instagram",
						"facebook",
						"tiktok",
						"youtube"
					].map((k) => /* @__PURE__ */ jsx(Field, {
						label: k[0].toUpperCase() + k.slice(1),
						name: k,
						error: social.errors[k],
						optional: true,
						children: (p) => /* @__PURE__ */ jsx(Input, {
							...p,
							type: "url",
							value: social.data[k],
							onChange: (e) => social.setData(k, e.target.value),
							placeholder: "https://"
						})
					}, k))
				}), /* @__PURE__ */ jsx(SaveBar, { processing: social.processing })]
			}),
			/* @__PURE__ */ jsxs(Section, {
				title: "Search engines",
				description: "Default title and description for the home page and pages without their own.",
				onSubmit: save(seo, "seo"),
				children: [/* @__PURE__ */ jsxs("div", {
					className: "space-y-4",
					children: [/* @__PURE__ */ jsx(Field, {
						label: "Title",
						name: "title",
						error: seo.errors.title,
						hint: `${seo.data.title.length}/70`,
						required: true,
						children: (p) => /* @__PURE__ */ jsx(Input, {
							...p,
							value: seo.data.title,
							onChange: (e) => seo.setData("title", e.target.value),
							maxLength: 70
						})
					}), /* @__PURE__ */ jsx(Field, {
						label: "Description",
						name: "description",
						error: seo.errors.description,
						hint: `${seo.data.description.length}/170`,
						required: true,
						children: (p) => /* @__PURE__ */ jsx(Textarea, {
							...p,
							rows: 2,
							value: seo.data.description,
							onChange: (e) => seo.setData("description", e.target.value),
							maxLength: 170
						})
					})]
				}), /* @__PURE__ */ jsx(SaveBar, { processing: seo.processing })]
			})
		]
	})] });
}
//#endregion
export { Settings as default };
