import { t as cn } from "./utils-BqvNF826.js";
import { t as useShared } from "./use-shared-BMnpkZPP.js";
import { t as formatMoney } from "./money-CcsjAkm_.js";
import { a as Panel, c as Stat, d as th, l as Table, n as OrderStatusBadge, r as PageHeader, t as EmptyState, u as td } from "./ui-DQeK8Yrd.js";
import { n as formatDateTime } from "./date-x_Fsbx42.js";
import { Link, router } from "@inertiajs/react";
import { useState } from "react";
import { Fragment, jsx, jsxs } from "react/jsx-runtime";
import { AlertTriangle, CheckCircle2, Circle } from "lucide-react";
//#region resources/js/components/admin/daily-chart.tsx
/**
* Daily order value as columns: one series, one hue, rounded data ends on a
* shared baseline, a 2px gap between bars, hover/focus tooltip, and a table
* for screen readers.
*/
function DailyChart({ series, currency }) {
	const [active, setActive] = useState(null);
	const max = Math.max(1, ...series.map((p) => p.value_minor));
	const height = 160;
	const n = series.length;
	const gap = 2;
	const width = 720;
	const barWidth = Math.max(2, (width - gap * (n - 1)) / n);
	const labelEvery = n > 31 ? 14 : n > 8 ? 7 : 1;
	const short = new Intl.DateTimeFormat("en-GB", {
		day: "numeric",
		month: "short",
		timeZone: "UTC"
	});
	const fmt = (d) => short.format(/* @__PURE__ */ new Date(`${d}T00:00:00Z`));
	const current = active !== null ? series[active] : void 0;
	return /* @__PURE__ */ jsxs("figure", { children: [/* @__PURE__ */ jsxs("div", {
		className: "relative",
		children: [/* @__PURE__ */ jsxs("svg", {
			viewBox: `0 0 ${width} 184`,
			className: "h-48 w-full",
			role: "img",
			"aria-label": "Order value per day",
			preserveAspectRatio: "none",
			children: [/* @__PURE__ */ jsx("line", {
				x1: "0",
				x2: width,
				y1: height,
				y2: height,
				stroke: "var(--color-line)",
				strokeWidth: "1",
				vectorEffect: "non-scaling-stroke"
			}), series.map((p, i) => {
				const h = p.value_minor === 0 ? 0 : Math.max(3, p.value_minor / max * 152);
				const x = i * (barWidth + gap);
				return /* @__PURE__ */ jsxs("g", { children: [
					/* @__PURE__ */ jsx("rect", {
						x,
						y: 0,
						width: barWidth + gap,
						height,
						fill: "transparent",
						tabIndex: 0,
						onMouseEnter: () => setActive(i),
						onMouseLeave: () => setActive(null),
						onFocus: () => setActive(i),
						onBlur: () => setActive(null),
						"aria-label": `${fmt(p.date)}: ${p.orders} orders, ${formatMoney(p.value_minor, currency)}`
					}),
					h > 0 && /* @__PURE__ */ jsx("path", {
						d: roundedTop(x, height - h, barWidth, h, Math.min(4, barWidth / 2)),
						fill: active === i ? "var(--color-ink)" : "var(--color-aloe)",
						pointerEvents: "none"
					}),
					i % labelEvery === 0 && /* @__PURE__ */ jsx("text", {
						x: x + barWidth / 2,
						y: 177,
						textAnchor: "middle",
						className: "fill-stone",
						fontSize: "11",
						children: fmt(p.date)
					})
				] }, p.date);
			})]
		}), current && active !== null && /* @__PURE__ */ jsxs("div", {
			className: "pointer-events-none absolute top-0 rounded-md bg-ink px-3 py-2 text-xs text-ivory shadow-overlay",
			style: { left: `${Math.min(80, Math.max(0, active / n * 100))}%` },
			role: "status",
			children: [/* @__PURE__ */ jsx("p", {
				className: "font-medium",
				children: fmt(current.date)
			}), /* @__PURE__ */ jsxs("p", { children: [
				current.orders,
				" ",
				current.orders === 1 ? "order" : "orders",
				", ",
				formatMoney(current.value_minor, currency)
			] })]
		})]
	}), /* @__PURE__ */ jsx("figcaption", {
		className: "sr-only",
		children: /* @__PURE__ */ jsxs("table", { children: [
			/* @__PURE__ */ jsx("caption", { children: "Order value per day" }),
			/* @__PURE__ */ jsx("thead", { children: /* @__PURE__ */ jsxs("tr", { children: [
				/* @__PURE__ */ jsx("th", { children: "Date" }),
				/* @__PURE__ */ jsx("th", { children: "Orders" }),
				/* @__PURE__ */ jsx("th", { children: "Value" })
			] }) }),
			/* @__PURE__ */ jsx("tbody", { children: series.map((p) => /* @__PURE__ */ jsxs("tr", { children: [
				/* @__PURE__ */ jsx("td", { children: p.date }),
				/* @__PURE__ */ jsx("td", { children: p.orders }),
				/* @__PURE__ */ jsx("td", { children: formatMoney(p.value_minor, currency) })
			] }, p.date)) })
		] })
	})] });
}
/** Bar with rounded top corners only, anchored square to the baseline. */
function roundedTop(x, y, w, h, r) {
	const rr = Math.min(r, h);
	return `M${x},${y + h} L${x},${y + rr} Q${x},${y} ${x + rr},${y} L${x + w - rr},${y} Q${x + w},${y} ${x + w},${y + rr} L${x + w},${y + h} Z`;
}
//#endregion
//#region resources/js/pages/admin/dashboard.tsx
var RANGES = [
	{
		value: "today",
		label: "Today"
	},
	{
		value: "7d",
		label: "7 days"
	},
	{
		value: "30d",
		label: "30 days"
	},
	{
		value: "90d",
		label: "90 days"
	}
];
function Dashboard({ range, currency, metrics, series, bestsellers, lowStock, recentOrders, checklist }) {
	const { store, auth } = useShared();
	const money = (v) => formatMoney(v, currency);
	const pendingChecklist = checklist.filter((c) => !c.done);
	return /* @__PURE__ */ jsxs(Fragment, { children: [
		/* @__PURE__ */ jsx(PageHeader, {
			title: `Hello, ${auth?.user?.name.split(" ")[0] ?? ""}`,
			description: "What needs your attention, and how the shop is doing."
		}),
		pendingChecklist.length > 0 && /* @__PURE__ */ jsx(Panel, {
			title: "Before you launch",
			description: `${checklist.length - pendingChecklist.length} of ${checklist.length} done`,
			className: "mb-6",
			children: /* @__PURE__ */ jsx("ul", {
				className: "grid gap-2 sm:grid-cols-2",
				children: checklist.map((item) => /* @__PURE__ */ jsxs("li", {
					className: "flex items-start gap-2.5 text-sm",
					children: [item.done ? /* @__PURE__ */ jsx(CheckCircle2, {
						className: "mt-0.5 size-4 shrink-0 text-aloe",
						"aria-label": "Done"
					}) : /* @__PURE__ */ jsx(Circle, {
						className: "mt-0.5 size-4 shrink-0 text-stone",
						"aria-label": "To do"
					}), item.href && !item.done ? /* @__PURE__ */ jsx(Link, {
						href: item.href,
						className: "underline underline-offset-4 hover:text-aloe",
						children: item.label
					}) : /* @__PURE__ */ jsx("span", {
						className: cn(item.done && "text-stone line-through"),
						children: item.label
					})]
				}, item.label))
			})
		}),
		/* @__PURE__ */ jsx("h2", {
			className: "mb-3 text-sm font-medium text-stone",
			children: "Needs action now"
		}),
		/* @__PURE__ */ jsxs("div", {
			className: "grid grid-cols-2 gap-4 lg:grid-cols-4",
			children: [
				/* @__PURE__ */ jsx(Stat, {
					label: "Orders today",
					value: metrics.orders_today
				}),
				/* @__PURE__ */ jsx(Stat, {
					label: "Awaiting confirmation",
					value: metrics.awaiting_confirmation,
					href: "/admin/orders?status=PENDING_CONFIRMATION"
				}),
				/* @__PURE__ */ jsx(Stat, {
					label: "To prepare and send",
					value: metrics.awaiting_fulfilment,
					href: "/admin/orders?status=to_fulfil"
				}),
				/* @__PURE__ */ jsx(Stat, {
					label: "Out for delivery",
					value: metrics.out_for_delivery,
					href: "/admin/orders?status=SHIPPED"
				})
			]
		}),
		/* @__PURE__ */ jsxs("div", {
			className: "mt-10 mb-3 flex flex-wrap items-center justify-between gap-3",
			children: [/* @__PURE__ */ jsx("h2", {
				className: "text-sm font-medium text-stone",
				children: "Performance"
			}), /* @__PURE__ */ jsx("div", {
				role: "group",
				"aria-label": "Date range",
				className: "inline-flex rounded-full border border-line bg-white p-0.5",
				children: RANGES.map((r) => /* @__PURE__ */ jsx("button", {
					type: "button",
					onClick: () => router.get("/admin", { range: r.value }, {
						preserveScroll: true,
						preserveState: true
					}),
					"aria-pressed": range === r.value,
					className: cn("rounded-full px-3.5 py-1.5 text-sm", range === r.value ? "bg-ink text-ivory" : "hover:bg-panel"),
					children: r.label
				}, r.value))
			})]
		}),
		/* @__PURE__ */ jsxs("div", {
			className: "grid grid-cols-2 gap-4 lg:grid-cols-4",
			children: [
				/* @__PURE__ */ jsx(Stat, {
					label: "Cash collected",
					value: money(metrics.collected_minor),
					hint: "Delivered orders with payment recorded. This is your revenue."
				}),
				/* @__PURE__ */ jsx(Stat, {
					label: "Order value",
					value: money(metrics.order_value_minor),
					hint: `${metrics.orders_in_range} orders placed, excluding cancelled. Not yet revenue.`
				}),
				/* @__PURE__ */ jsx(Stat, {
					label: "Delivered",
					value: metrics.delivered,
					hint: `${metrics.cancelled} cancelled in the same period`
				}),
				/* @__PURE__ */ jsx(Stat, {
					label: "Delivered, cash not recorded",
					value: money(metrics.awaiting_collection_minor),
					hint: "Record collected cash on each delivered order.",
					href: "/admin/orders?status=DELIVERED&payment=pending"
				})
			]
		}),
		/* @__PURE__ */ jsx(Panel, {
			title: "Order value per day",
			description: "Orders placed, excluding cancelled",
			className: "mt-6",
			children: /* @__PURE__ */ jsx(DailyChart, {
				series,
				currency
			})
		}),
		/* @__PURE__ */ jsxs("div", {
			className: "mt-6 grid gap-6 lg:grid-cols-2",
			children: [/* @__PURE__ */ jsx(Panel, {
				title: "Bestsellers",
				description: "Units ordered in this period",
				padded: false,
				children: bestsellers.length === 0 ? /* @__PURE__ */ jsx(EmptyState, { title: "No orders in this period yet." }) : /* @__PURE__ */ jsxs(Table, { children: [/* @__PURE__ */ jsx("thead", { children: /* @__PURE__ */ jsxs("tr", { children: [
					/* @__PURE__ */ jsx("th", {
						className: th,
						children: "Product"
					}),
					/* @__PURE__ */ jsx("th", {
						className: cn(th, "text-right"),
						children: "Units"
					}),
					/* @__PURE__ */ jsx("th", {
						className: cn(th, "text-right"),
						children: "Value"
					})
				] }) }), /* @__PURE__ */ jsx("tbody", { children: bestsellers.map((b) => /* @__PURE__ */ jsxs("tr", { children: [
					/* @__PURE__ */ jsx("td", {
						className: td,
						children: b.name
					}),
					/* @__PURE__ */ jsx("td", {
						className: cn(td, "text-right tabular-nums"),
						children: b.units
					}),
					/* @__PURE__ */ jsx("td", {
						className: cn(td, "text-right tabular-nums"),
						children: money(b.value_minor)
					})
				] }, b.product_id)) })] })
			}), /* @__PURE__ */ jsx(Panel, {
				title: "Low stock",
				description: "Published products at or below their alert level",
				padded: false,
				actions: /* @__PURE__ */ jsx(Link, {
					href: "/admin/inventory?level=low",
					className: "text-sm underline underline-offset-4",
					children: "All stock"
				}),
				children: lowStock.length === 0 ? /* @__PURE__ */ jsx(EmptyState, { title: "Stock levels look fine." }) : /* @__PURE__ */ jsx("ul", {
					className: "divide-y divide-line",
					children: lowStock.map((v) => /* @__PURE__ */ jsxs("li", {
						className: "flex items-center justify-between gap-3 px-5 py-3 text-sm",
						children: [/* @__PURE__ */ jsx(Link, {
							href: `/admin/products/${v.product_id}/edit`,
							className: "hover:underline",
							children: v.name
						}), /* @__PURE__ */ jsxs("span", {
							className: cn("inline-flex items-center gap-1.5 tabular-nums", v.stock === 0 ? "text-clay" : "text-dune-deep"),
							children: [v.stock === 0 && /* @__PURE__ */ jsx(AlertTriangle, {
								className: "size-3.5",
								"aria-hidden": "true"
							}), v.stock === 0 ? "Out of stock" : `${v.stock} left`]
						})]
					}, v.id))
				})
			})]
		}),
		/* @__PURE__ */ jsx(Panel, {
			title: "Latest orders",
			padded: false,
			className: "mt-6",
			actions: /* @__PURE__ */ jsx(Link, {
				href: "/admin/orders",
				className: "text-sm underline underline-offset-4",
				children: "All orders"
			}),
			children: recentOrders.length === 0 ? /* @__PURE__ */ jsx(EmptyState, {
				title: "No orders yet.",
				children: "Orders placed on the shop will appear here."
			}) : /* @__PURE__ */ jsxs(Table, { children: [/* @__PURE__ */ jsx("thead", { children: /* @__PURE__ */ jsxs("tr", { children: [
				/* @__PURE__ */ jsx("th", {
					className: th,
					children: "Order"
				}),
				/* @__PURE__ */ jsx("th", {
					className: th,
					children: "Customer"
				}),
				/* @__PURE__ */ jsx("th", {
					className: th,
					children: "Status"
				}),
				/* @__PURE__ */ jsx("th", {
					className: cn(th, "text-right"),
					children: "Total"
				}),
				/* @__PURE__ */ jsx("th", {
					className: th,
					children: "Placed"
				})
			] }) }), /* @__PURE__ */ jsx("tbody", { children: recentOrders.map((o) => /* @__PURE__ */ jsxs("tr", {
				className: "hover:bg-panel/50",
				children: [
					/* @__PURE__ */ jsxs("td", {
						className: td,
						children: [/* @__PURE__ */ jsx(Link, {
							href: `/admin/orders/${o.reference}`,
							className: "font-medium underline-offset-4 hover:underline",
							children: o.reference
						}), o.risk && /* @__PURE__ */ jsx(AlertTriangle, {
							className: "ml-1.5 inline size-3.5 text-dune-deep",
							"aria-label": "Flagged for review"
						})]
					}),
					/* @__PURE__ */ jsxs("td", {
						className: td,
						children: [o.customer_name, /* @__PURE__ */ jsx("span", {
							className: "block text-xs text-stone",
							children: o.city
						})]
					}),
					/* @__PURE__ */ jsx("td", {
						className: td,
						children: /* @__PURE__ */ jsx(OrderStatusBadge, {
							status: o.status,
							label: o.status_label
						})
					}),
					/* @__PURE__ */ jsx("td", {
						className: cn(td, "text-right tabular-nums"),
						children: formatMoney(o.total_minor, o.currency)
					}),
					/* @__PURE__ */ jsx("td", {
						className: cn(td, "whitespace-nowrap text-stone"),
						children: formatDateTime(o.created_at, store.timezone)
					})
				]
			}, o.reference)) })] })
		})
	] });
}
//#endregion
export { Dashboard as default };
