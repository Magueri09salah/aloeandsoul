import { t as useShared } from "./use-shared-BMnpkZPP.js";
import { r as Select } from "../ssr.js";
import { a as Panel, d as th, i as Pagination, l as Table, r as PageHeader, t as EmptyState, u as td } from "./ui-DQeK8Yrd.js";
import { n as formatDateTime } from "./date-x_Fsbx42.js";
import { router } from "@inertiajs/react";
import { Fragment, jsx, jsxs } from "react/jsx-runtime";
//#region resources/js/pages/admin/audit-log.tsx
function AuditLog({ entries, filters, actions }) {
	const { store } = useShared();
	return /* @__PURE__ */ jsxs(Fragment, { children: [/* @__PURE__ */ jsx(PageHeader, {
		title: "Activity log",
		description: "Who changed what in the admin. Kept for two years."
	}), /* @__PURE__ */ jsxs(Panel, {
		padded: false,
		children: [
			/* @__PURE__ */ jsxs("div", {
				className: "border-b border-line p-4",
				children: [/* @__PURE__ */ jsx("label", {
					htmlFor: "action",
					className: "sr-only",
					children: "Filter by action"
				}), /* @__PURE__ */ jsxs(Select, {
					id: "action",
					value: filters.action ?? "",
					onChange: (e) => router.get("/admin/audit-log", e.target.value ? { action: e.target.value } : {}, { preserveState: true }),
					className: "h-10 max-w-xs",
					children: [/* @__PURE__ */ jsx("option", {
						value: "",
						children: "All actions"
					}), actions.map((a) => /* @__PURE__ */ jsx("option", {
						value: a,
						children: a
					}, a))]
				})]
			}),
			entries.data.length === 0 ? /* @__PURE__ */ jsx(EmptyState, { title: "Nothing recorded yet." }) : /* @__PURE__ */ jsxs(Table, { children: [/* @__PURE__ */ jsx("thead", { children: /* @__PURE__ */ jsxs("tr", { children: [
				/* @__PURE__ */ jsx("th", {
					className: th,
					children: "When"
				}),
				/* @__PURE__ */ jsx("th", {
					className: th,
					children: "Who"
				}),
				/* @__PURE__ */ jsx("th", {
					className: th,
					children: "Action"
				}),
				/* @__PURE__ */ jsx("th", {
					className: th,
					children: "Details"
				})
			] }) }), /* @__PURE__ */ jsx("tbody", { children: entries.data.map((e) => /* @__PURE__ */ jsxs("tr", {
				className: "align-top",
				children: [
					/* @__PURE__ */ jsx("td", {
						className: `${td} whitespace-nowrap text-stone`,
						children: formatDateTime(e.created_at, store.timezone)
					}),
					/* @__PURE__ */ jsxs("td", {
						className: td,
						children: [e.user ?? "System", e.ip_address && /* @__PURE__ */ jsx("span", {
							className: "block text-xs text-stone",
							children: e.ip_address
						})]
					}),
					/* @__PURE__ */ jsxs("td", {
						className: td,
						children: [/* @__PURE__ */ jsx("code", {
							className: "text-xs",
							children: e.action
						}), e.subject && /* @__PURE__ */ jsx("span", {
							className: "block text-xs text-stone",
							children: e.subject
						})]
					}),
					/* @__PURE__ */ jsx("td", {
						className: td,
						children: e.properties && /* @__PURE__ */ jsxs("details", { children: [/* @__PURE__ */ jsx("summary", {
							className: "cursor-pointer text-xs text-stone",
							children: "Show"
						}), /* @__PURE__ */ jsx("pre", {
							className: "mt-2 max-w-md overflow-x-auto rounded bg-panel p-2 text-xs",
							children: JSON.stringify(e.properties, null, 2)
						})] })
					})
				]
			}, e.id)) })] }),
			/* @__PURE__ */ jsx(Pagination, { page: entries })
		]
	})] });
}
//#endregion
export { AuditLog as default };
