import { t as Input, v as Button } from "../ssr.js";
import { router, useForm } from "@inertiajs/react";
import { jsx, jsxs } from "react/jsx-runtime";
//#region resources/js/components/store/coupon-form.tsx
/** Apply or remove a discount code. The discount itself is always computed on the server. */
function CouponForm({ code, error }) {
	const form = useForm({ code: "" });
	const submit = (e) => {
		e.preventDefault();
		form.post("/cart/coupon", {
			preserveScroll: true,
			onSuccess: () => form.reset()
		});
	};
	if (code) return /* @__PURE__ */ jsxs("div", {
		className: "rounded-(--radius-control) border border-line bg-white px-4 py-3 text-sm",
		children: [/* @__PURE__ */ jsxs("div", {
			className: "flex items-center justify-between gap-3",
			children: [/* @__PURE__ */ jsxs("span", { children: ["Code ", /* @__PURE__ */ jsx("strong", {
				className: "font-semibold",
				children: code
			})] }), /* @__PURE__ */ jsx("button", {
				type: "button",
				className: "text-stone underline underline-offset-4 hover:text-clay",
				onClick: () => router.delete("/cart/coupon", { preserveScroll: true }),
				children: "Remove"
			})]
		}), error && /* @__PURE__ */ jsx("p", {
			className: "mt-1.5 text-clay",
			role: "alert",
			children: error
		})]
	});
	return /* @__PURE__ */ jsxs("form", {
		onSubmit: submit,
		className: "flex flex-col gap-1.5",
		children: [
			/* @__PURE__ */ jsx("label", {
				htmlFor: "coupon",
				className: "text-sm font-medium",
				children: "Discount code"
			}),
			/* @__PURE__ */ jsxs("div", {
				className: "flex gap-2",
				children: [/* @__PURE__ */ jsx(Input, {
					id: "coupon",
					value: form.data.code,
					onChange: (e) => form.setData("code", e.target.value),
					autoComplete: "off",
					autoCapitalize: "characters",
					maxLength: 40,
					"aria-invalid": form.errors.code ? true : void 0,
					"aria-describedby": form.errors.code ? "coupon-error" : void 0
				}), /* @__PURE__ */ jsx(Button, {
					type: "submit",
					variant: "secondary",
					loading: form.processing,
					disabled: !form.data.code.trim(),
					children: "Apply"
				})]
			}),
			form.errors.code && /* @__PURE__ */ jsx("p", {
				id: "coupon-error",
				className: "text-sm text-clay",
				role: "alert",
				children: form.errors.code
			})
		]
	});
}
//#endregion
export { CouponForm as t };
