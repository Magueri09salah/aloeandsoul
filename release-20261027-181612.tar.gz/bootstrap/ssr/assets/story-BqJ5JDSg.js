import { p as ResponsiveImage, v as Button } from "../ssr.js";
import { Link } from "@inertiajs/react";
import { jsx, jsxs } from "react/jsx-runtime";
//#region resources/js/pages/story.tsx
/** The founder's own words, set as a long-form editorial feature. */
function Story({ story }) {
	return /* @__PURE__ */ jsxs("article", { children: [
		/* @__PURE__ */ jsxs("header", {
			className: "container-page grid items-end gap-10 pt-10 pb-16 lg:grid-cols-12 lg:gap-8 lg:pt-16 lg:pb-24",
			children: [/* @__PURE__ */ jsxs("div", {
				className: "lg:col-span-7",
				children: [/* @__PURE__ */ jsx("h1", {
					className: "font-display text-display-xl text-balance",
					children: story.heading
				}), story.intro && /* @__PURE__ */ jsx("p", {
					className: "mt-8 max-w-xl border-l border-dune pl-6 font-serif text-xl leading-relaxed italic sm:text-2xl",
					children: story.intro
				})]
			}), /* @__PURE__ */ jsx("div", {
				className: "mx-auto w-full max-w-sm lg:col-span-4 lg:col-start-9 lg:max-w-none",
				children: /* @__PURE__ */ jsx("div", {
					className: "arch aspect-[3/4] bg-sand",
					children: /* @__PURE__ */ jsx(ResponsiveImage, {
						image: story.image,
						sizes: "(min-width: 1024px) 30vw, 90vw",
						priority: true
					})
				})
			})]
		}),
		story.milestones.length > 0 && /* @__PURE__ */ jsx("section", {
			"aria-label": "Journey",
			className: "bg-sand",
			children: /* @__PURE__ */ jsx("ol", {
				className: "container-page grid gap-8 py-12 sm:grid-cols-3 sm:gap-6",
				children: story.milestones.map((m, i) => /* @__PURE__ */ jsxs("li", {
					className: "relative sm:pt-8",
					children: [
						/* @__PURE__ */ jsx("span", {
							"aria-hidden": "true",
							className: "absolute top-3 right-0 left-0 hidden h-px bg-dune/50 sm:block"
						}),
						/* @__PURE__ */ jsx("span", {
							"aria-hidden": "true",
							className: "absolute top-1.5 left-0 hidden size-3 rounded-full border border-dune bg-ivory sm:block"
						}),
						/* @__PURE__ */ jsxs("p", {
							className: "font-display text-2xl",
							children: [/* @__PURE__ */ jsxs("span", {
								className: "sr-only",
								children: [
									"Step ",
									i + 1,
									": "
								]
							}), m.place]
						}),
						/* @__PURE__ */ jsx("p", {
							className: "mt-2 max-w-xs text-stone",
							children: m.text
						})
					]
				}, m.place))
			})
		}),
		story.chapters.map((chapter) => /* @__PURE__ */ jsxs("section", {
			id: chapter.key,
			"aria-labelledby": `${chapter.key}-title`,
			className: "container-page grid gap-8 border-b border-line py-16 lg:grid-cols-12 lg:py-24",
			children: [/* @__PURE__ */ jsx("div", {
				className: "lg:col-span-4",
				children: /* @__PURE__ */ jsx("h2", {
					id: `${chapter.key}-title`,
					className: "font-display text-display-sm lg:sticky lg:top-28",
					children: chapter.title
				})
			}), /* @__PURE__ */ jsx("div", {
				className: "prose-editorial lg:col-span-7 lg:col-start-6",
				children: chapter.paragraphs.map((p, i) => /* @__PURE__ */ jsx("p", {
					className: i === 0 ? "font-display text-[1.6rem] leading-snug sm:text-[1.85rem]" : void 0,
					children: p
				}, i))
			})]
		}, chapter.key)),
		/* @__PURE__ */ jsxs("section", {
			className: "container-page py-20 text-center lg:py-28",
			children: [
				/* @__PURE__ */ jsx("p", {
					className: "mx-auto max-w-4xl font-display text-display text-balance",
					children: story.tagline
				}),
				story.closing && /* @__PURE__ */ jsx("p", {
					className: "mx-auto mt-6 max-w-2xl font-serif text-editorial text-stone",
					children: story.closing
				}),
				/* @__PURE__ */ jsxs("div", {
					className: "mt-10 flex flex-wrap justify-center gap-3",
					children: [/* @__PURE__ */ jsx(Button, {
						asChild: true,
						size: "lg",
						children: /* @__PURE__ */ jsx(Link, {
							href: "/shop",
							children: "Visit the shop"
						})
					}), /* @__PURE__ */ jsx(Button, {
						asChild: true,
						size: "lg",
						variant: "secondary",
						children: /* @__PURE__ */ jsx(Link, {
							href: "/contact",
							children: "Get in touch"
						})
					})]
				}),
				story.disclaimer && /* @__PURE__ */ jsx("p", {
					className: "mx-auto mt-16 max-w-2xl text-sm text-stone",
					children: story.disclaimer
				})
			]
		})
	] });
}
//#endregion
export { Story as default };
