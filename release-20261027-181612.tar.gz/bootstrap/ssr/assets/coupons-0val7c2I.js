import { a as ConfirmDialog, c as Checkbox, l as Switch, n as Label, o as Dialog, r as Select, s as DialogContent, t as Input, v as Button } from "../ssr.js";
import { t as Badge } from "./badge-ChM6xC7L.js";
import { a as Panel, d as th, l as Table, r as PageHeader, t as EmptyState, u as td } from "./ui-DQeK8Yrd.js";
import { t as Field } from "./field-BVcOZvwI.js";
import { router, useForm } from "@inertiajs/react";
import { useState } from "react";
import { Fragment, jsx, jsxs } from "react/jsx-runtime";
import { Plus } from "lucide-react";
//#region resources/js/pages/admin/coupons/index.tsx
function Coupons({ coupons, currency }) {
	const [editing, setEditing] = useState(null);
	return /* @__PURE__ */ jsxs(Fragment, { children: [
		/* @__PURE__ */ jsx(PageHeader, {
			title: "Discount codes",
			description: "Customers enter a code in the cart or at checkout. Discounts are always recalculated on the server.",
			actions: /* @__PURE__ */ jsxs(Button, {
				onClick: () => setEditing("new"),
				children: [/* @__PURE__ */ jsx(Plus, { "aria-hidden": "true" }), " New code"]
			})
		}),
		/* @__PURE__ */ jsx(Panel, {
			padded: false,
			children: coupons.length === 0 ? /* @__PURE__ */ jsx(EmptyState, { title: "No discount codes yet." }) : /* @__PURE__ */ jsxs(Table, { children: [/* @__PURE__ */ jsx("thead", { children: /* @__PURE__ */ jsxs("tr", { children: [
				/* @__PURE__ */ jsx("th", {
					className: th,
					children: "Code"
				}),
				/* @__PURE__ */ jsx("th", {
					className: th,
					children: "Discount"
				}),
				/* @__PURE__ */ jsx("th", {
					className: th,
					children: "Used"
				}),
				/* @__PURE__ */ jsx("th", {
					className: th,
					children: "Valid"
				}),
				/* @__PURE__ */ jsx("th", {
					className: th,
					children: /* @__PURE__ */ jsx("span", {
						className: "sr-only",
						children: "Actions"
					})
				})
			] }) }), /* @__PURE__ */ jsx("tbody", { children: coupons.map((c) => /* @__PURE__ */ jsxs("tr", { children: [
				/* @__PURE__ */ jsxs("td", {
					className: td,
					children: [/* @__PURE__ */ jsx("span", {
						className: "font-mono font-medium",
						children: c.code
					}), c.description && /* @__PURE__ */ jsx("span", {
						className: "block text-xs text-stone",
						children: c.description
					})]
				}),
				/* @__PURE__ */ jsxs("td", {
					className: td,
					children: [c.type === "percent" ? `${c.value}%` : `${c.value} ${currency}`, c.min_subtotal && /* @__PURE__ */ jsxs("span", {
						className: "block text-xs text-stone",
						children: [
							"min. ",
							c.min_subtotal,
							" ",
							currency
						]
					})]
				}),
				/* @__PURE__ */ jsxs("td", {
					className: `${td} tabular-nums`,
					children: [c.uses_count, c.max_uses !== null && ` / ${c.max_uses}`]
				}),
				/* @__PURE__ */ jsx("td", {
					className: td,
					children: !c.is_active ? /* @__PURE__ */ jsx(Badge, {
						tone: "neutral",
						children: "Off"
					}) : c.expired ? /* @__PURE__ */ jsx(Badge, {
						tone: "warning",
						children: "Expired"
					}) : /* @__PURE__ */ jsx(Badge, {
						tone: "success",
						children: "Active"
					})
				}),
				/* @__PURE__ */ jsx("td", {
					className: `${td} text-right`,
					children: /* @__PURE__ */ jsx(Button, {
						size: "sm",
						variant: "ghost",
						onClick: () => setEditing(c),
						children: "Edit"
					})
				})
			] }, c.id)) })] })
		}),
		/* @__PURE__ */ jsx(Dialog, {
			open: editing !== null,
			onOpenChange: (o) => !o && setEditing(null),
			children: editing !== null && /* @__PURE__ */ jsx(DialogContent, {
				title: editing === "new" ? "New discount code" : `Edit ${editing.code}`,
				className: "max-w-xl",
				children: /* @__PURE__ */ jsx(CouponForm, {
					coupon: editing === "new" ? null : editing,
					currency,
					onDone: () => setEditing(null)
				})
			})
		})
	] });
}
function CouponForm({ coupon, currency, onDone }) {
	const form = useForm({
		code: coupon?.code ?? "",
		description: coupon?.description ?? "",
		type: coupon?.type ?? "percent",
		value: coupon?.value ?? "",
		min_subtotal: coupon?.min_subtotal ?? "",
		max_uses: coupon?.max_uses ?? "",
		once_per_customer: coupon?.once_per_customer ?? false,
		starts_at: coupon?.starts_at ?? "",
		ends_at: coupon?.ends_at ?? "",
		is_active: coupon?.is_active ?? true
	});
	const submit = (e) => {
		e.preventDefault();
		form.transform((d) => ({
			...d,
			max_uses: d.max_uses === "" ? null : d.max_uses
		}));
		const opts = {
			preserveScroll: true,
			onSuccess: onDone
		};
		if (coupon) form.put(`/admin/coupons/${coupon.id}`, opts);
		else form.post("/admin/coupons", opts);
	};
	return /* @__PURE__ */ jsxs("form", {
		onSubmit: submit,
		noValidate: true,
		className: "space-y-4",
		children: [
			/* @__PURE__ */ jsxs("div", {
				className: "grid gap-4 sm:grid-cols-2",
				children: [/* @__PURE__ */ jsx(Field, {
					label: "Code",
					name: "code",
					error: form.errors.code,
					required: true,
					children: (p) => /* @__PURE__ */ jsx(Input, {
						...p,
						value: form.data.code,
						onChange: (e) => form.setData("code", e.target.value.toUpperCase()),
						className: "font-mono",
						maxLength: 40
					})
				}), /* @__PURE__ */ jsx(Field, {
					label: "Internal description",
					name: "description",
					error: form.errors.description,
					optional: true,
					children: (p) => /* @__PURE__ */ jsx(Input, {
						...p,
						value: form.data.description,
						onChange: (e) => form.setData("description", e.target.value),
						maxLength: 160
					})
				})]
			}),
			/* @__PURE__ */ jsxs("div", {
				className: "grid gap-4 sm:grid-cols-2",
				children: [/* @__PURE__ */ jsx(Field, {
					label: "Type",
					name: "type",
					error: form.errors.type,
					children: (p) => /* @__PURE__ */ jsxs(Select, {
						...p,
						value: form.data.type,
						onChange: (e) => form.setData("type", e.target.value),
						children: [/* @__PURE__ */ jsx("option", {
							value: "percent",
							children: "Percentage off"
						}), /* @__PURE__ */ jsx("option", {
							value: "fixed",
							children: "Fixed amount off"
						})]
					})
				}), /* @__PURE__ */ jsx(Field, {
					label: form.data.type === "percent" ? "Percentage" : `Amount (${currency})`,
					name: "value",
					error: form.errors.value,
					required: true,
					children: (p) => /* @__PURE__ */ jsx(Input, {
						...p,
						inputMode: "decimal",
						value: form.data.value,
						onChange: (e) => form.setData("value", e.target.value)
					})
				})]
			}),
			/* @__PURE__ */ jsxs("div", {
				className: "grid gap-4 sm:grid-cols-2",
				children: [/* @__PURE__ */ jsx(Field, {
					label: `Minimum order (${currency})`,
					name: "min_subtotal",
					error: form.errors.min_subtotal,
					optional: true,
					children: (p) => /* @__PURE__ */ jsx(Input, {
						...p,
						inputMode: "decimal",
						value: form.data.min_subtotal,
						onChange: (e) => form.setData("min_subtotal", e.target.value)
					})
				}), /* @__PURE__ */ jsx(Field, {
					label: "Total uses allowed",
					name: "max_uses",
					error: form.errors.max_uses,
					optional: true,
					hint: "Leave empty for no limit.",
					children: (p) => /* @__PURE__ */ jsx(Input, {
						...p,
						type: "number",
						min: 1,
						value: form.data.max_uses,
						onChange: (e) => form.setData("max_uses", e.target.value)
					})
				})]
			}),
			/* @__PURE__ */ jsxs("div", {
				className: "grid gap-4 sm:grid-cols-2",
				children: [/* @__PURE__ */ jsx(Field, {
					label: "Starts",
					name: "starts_at",
					error: form.errors.starts_at,
					optional: true,
					children: (p) => /* @__PURE__ */ jsx(Input, {
						...p,
						type: "datetime-local",
						value: form.data.starts_at,
						onChange: (e) => form.setData("starts_at", e.target.value)
					})
				}), /* @__PURE__ */ jsx(Field, {
					label: "Ends",
					name: "ends_at",
					error: form.errors.ends_at,
					optional: true,
					children: (p) => /* @__PURE__ */ jsx(Input, {
						...p,
						type: "datetime-local",
						value: form.data.ends_at,
						onChange: (e) => form.setData("ends_at", e.target.value)
					})
				})]
			}),
			/* @__PURE__ */ jsxs("div", {
				className: "flex items-center gap-3",
				children: [/* @__PURE__ */ jsx(Checkbox, {
					id: "once",
					checked: form.data.once_per_customer,
					onCheckedChange: (v) => form.setData("once_per_customer", v === true)
				}), /* @__PURE__ */ jsx(Label, {
					htmlFor: "once",
					className: "font-normal",
					children: "Once per customer (by phone number)"
				})]
			}),
			/* @__PURE__ */ jsxs("div", {
				className: "flex items-center gap-3",
				children: [/* @__PURE__ */ jsx(Switch, {
					id: "coupon-active",
					checked: form.data.is_active,
					onCheckedChange: (v) => form.setData("is_active", v)
				}), /* @__PURE__ */ jsx(Label, {
					htmlFor: "coupon-active",
					className: "font-normal",
					children: "Active"
				})]
			}),
			/* @__PURE__ */ jsxs("div", {
				className: "flex justify-between gap-2 pt-2",
				children: [coupon && coupon.uses_count === 0 ? /* @__PURE__ */ jsx(ConfirmDialog, {
					trigger: /* @__PURE__ */ jsx(Button, {
						type: "button",
						variant: "destructive-outline",
						children: "Delete"
					}),
					title: "Delete this code?",
					description: "It has never been used.",
					confirmLabel: "Delete code",
					onConfirm: () => router.delete(`/admin/coupons/${coupon.id}`, { onSuccess: onDone })
				}) : /* @__PURE__ */ jsx("span", {}), /* @__PURE__ */ jsx(Button, {
					type: "submit",
					loading: form.processing,
					children: "Save code"
				})]
			})
		]
	});
}
//#endregion
export { Coupons as default };
