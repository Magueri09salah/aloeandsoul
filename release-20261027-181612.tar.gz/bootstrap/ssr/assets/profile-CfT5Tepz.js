import { t as Input, v as Button } from "../ssr.js";
import { t as Badge } from "./badge-ChM6xC7L.js";
import { a as Panel, r as PageHeader } from "./ui-DQeK8Yrd.js";
import { t as Field } from "./field-BVcOZvwI.js";
import { router, useForm } from "@inertiajs/react";
import { Fragment, jsx, jsxs } from "react/jsx-runtime";
//#region resources/js/pages/admin/profile.tsx
function Profile({ user, twoFactor, passwordConfirmed }) {
	const details = useForm({
		name: user.name,
		email: user.email
	});
	const password = useForm({
		current_password: "",
		password: "",
		password_confirmation: ""
	});
	const confirm = useForm({ password: "" });
	const code = useForm({ code: "" });
	const saveDetails = (e) => {
		e.preventDefault();
		details.put("/admin/user/profile-information", {
			errorBag: "updateProfileInformation",
			preserveScroll: true
		});
	};
	const savePassword = (e) => {
		e.preventDefault();
		password.put("/admin/user/password", {
			errorBag: "updatePassword",
			preserveScroll: true,
			onSuccess: () => password.reset()
		});
	};
	const confirmPassword = (e) => {
		e.preventDefault();
		confirm.post("/admin/user/confirm-password", {
			preserveScroll: true,
			onFinish: () => confirm.reset()
		});
	};
	const confirmCode = (e) => {
		e.preventDefault();
		code.post("/admin/user/confirmed-two-factor-authentication", {
			errorBag: "confirmTwoFactorAuthentication",
			preserveScroll: true
		});
	};
	return /* @__PURE__ */ jsxs(Fragment, { children: [/* @__PURE__ */ jsx(PageHeader, { title: "Your account" }), /* @__PURE__ */ jsxs("div", {
		className: "grid gap-6 lg:grid-cols-2",
		children: [
			/* @__PURE__ */ jsx(Panel, {
				title: "Details",
				children: /* @__PURE__ */ jsxs("form", {
					onSubmit: saveDetails,
					className: "space-y-4",
					noValidate: true,
					children: [
						/* @__PURE__ */ jsx(Field, {
							label: "Name",
							name: "name",
							error: details.errors.name,
							required: true,
							children: (p) => /* @__PURE__ */ jsx(Input, {
								...p,
								value: details.data.name,
								onChange: (e) => details.setData("name", e.target.value)
							})
						}),
						/* @__PURE__ */ jsx(Field, {
							label: "Email",
							name: "email",
							error: details.errors.email,
							required: true,
							children: (p) => /* @__PURE__ */ jsx(Input, {
								...p,
								type: "email",
								value: details.data.email,
								onChange: (e) => details.setData("email", e.target.value)
							})
						}),
						/* @__PURE__ */ jsx(Button, {
							type: "submit",
							loading: details.processing,
							children: "Save details"
						})
					]
				})
			}),
			/* @__PURE__ */ jsx(Panel, {
				title: "Password",
				children: /* @__PURE__ */ jsxs("form", {
					onSubmit: savePassword,
					className: "space-y-4",
					noValidate: true,
					children: [
						/* @__PURE__ */ jsx(Field, {
							label: "Current password",
							name: "current_password",
							error: password.errors.current_password,
							required: true,
							children: (p) => /* @__PURE__ */ jsx(Input, {
								...p,
								type: "password",
								autoComplete: "current-password",
								value: password.data.current_password,
								onChange: (e) => password.setData("current_password", e.target.value)
							})
						}),
						/* @__PURE__ */ jsx(Field, {
							label: "New password",
							name: "password",
							error: password.errors.password,
							hint: "At least 12 characters, with upper and lower case letters and a number.",
							required: true,
							children: (p) => /* @__PURE__ */ jsx(Input, {
								...p,
								type: "password",
								autoComplete: "new-password",
								value: password.data.password,
								onChange: (e) => password.setData("password", e.target.value)
							})
						}),
						/* @__PURE__ */ jsx(Field, {
							label: "Confirm new password",
							name: "password_confirmation",
							error: password.errors.password_confirmation,
							required: true,
							children: (p) => /* @__PURE__ */ jsx(Input, {
								...p,
								type: "password",
								autoComplete: "new-password",
								value: password.data.password_confirmation,
								onChange: (e) => password.setData("password_confirmation", e.target.value)
							})
						}),
						/* @__PURE__ */ jsx(Button, {
							type: "submit",
							loading: password.processing,
							children: "Change password"
						})
					]
				})
			}),
			/* @__PURE__ */ jsx(Panel, {
				className: "lg:col-span-2",
				title: "Two-factor authentication",
				description: "Ask for a code from an authenticator app (such as Google Authenticator or 1Password) when signing in.",
				actions: twoFactor.enabled ? /* @__PURE__ */ jsx(Badge, {
					tone: "success",
					children: "On"
				}) : /* @__PURE__ */ jsx(Badge, {
					tone: "warning",
					children: "Off"
				}),
				children: !passwordConfirmed ? /* @__PURE__ */ jsxs("form", {
					onSubmit: confirmPassword,
					className: "max-w-sm space-y-4",
					noValidate: true,
					children: [
						/* @__PURE__ */ jsx("p", {
							className: "text-sm text-stone",
							children: "Confirm your password to change two-factor settings."
						}),
						/* @__PURE__ */ jsx(Field, {
							label: "Password",
							name: "confirm_password",
							error: confirm.errors.password,
							required: true,
							children: (p) => /* @__PURE__ */ jsx(Input, {
								...p,
								type: "password",
								autoComplete: "current-password",
								value: confirm.data.password,
								onChange: (e) => confirm.setData("password", e.target.value)
							})
						}),
						/* @__PURE__ */ jsx(Button, {
							type: "submit",
							variant: "secondary",
							loading: confirm.processing,
							children: "Confirm password"
						})
					]
				}) : twoFactor.pending ? /* @__PURE__ */ jsxs("div", {
					className: "grid gap-6 sm:grid-cols-[auto_1fr]",
					children: [twoFactor.qr_code && /* @__PURE__ */ jsx("img", {
						src: twoFactor.qr_code,
						alt: "QR code to add this account to your authenticator app",
						className: "size-48 rounded border border-line bg-white p-2"
					}), /* @__PURE__ */ jsxs("div", { children: [
						/* @__PURE__ */ jsx("p", {
							className: "text-sm",
							children: "Scan the QR code with your authenticator app, or enter this key:"
						}),
						/* @__PURE__ */ jsx("p", {
							className: "mt-2 font-mono text-sm break-all select-all",
							children: twoFactor.setup_key
						}),
						/* @__PURE__ */ jsxs("form", {
							onSubmit: confirmCode,
							className: "mt-5 max-w-xs space-y-3",
							noValidate: true,
							children: [/* @__PURE__ */ jsx(Field, {
								label: "6-digit code from the app",
								name: "code",
								error: code.errors.code,
								required: true,
								children: (p) => /* @__PURE__ */ jsx(Input, {
									...p,
									inputMode: "numeric",
									autoComplete: "one-time-code",
									maxLength: 6,
									value: code.data.code,
									onChange: (e) => code.setData("code", e.target.value.replace(/\D/g, ""))
								})
							}), /* @__PURE__ */ jsxs("div", {
								className: "flex gap-2",
								children: [/* @__PURE__ */ jsx(Button, {
									type: "submit",
									loading: code.processing,
									children: "Turn on"
								}), /* @__PURE__ */ jsx(Button, {
									type: "button",
									variant: "ghost",
									onClick: () => router.delete("/admin/user/two-factor-authentication", { preserveScroll: true }),
									children: "Cancel"
								})]
							})]
						})
					] })]
				}) : twoFactor.enabled ? /* @__PURE__ */ jsxs("div", {
					className: "space-y-4",
					children: [twoFactor.recovery_codes && /* @__PURE__ */ jsxs("div", {
						className: "rounded-md border border-dune/50 bg-sand p-4",
						children: [/* @__PURE__ */ jsx("p", {
							className: "text-sm font-medium",
							children: "Save these recovery codes somewhere safe. Each can be used once if you lose your phone. They won’t be shown again."
						}), /* @__PURE__ */ jsx("ul", {
							className: "mt-3 grid grid-cols-2 gap-1 font-mono text-sm select-all sm:grid-cols-4",
							children: twoFactor.recovery_codes.map((c) => /* @__PURE__ */ jsx("li", { children: c }, c))
						})]
					}), /* @__PURE__ */ jsxs("div", {
						className: "flex flex-wrap gap-2",
						children: [/* @__PURE__ */ jsx(Button, {
							variant: "secondary",
							onClick: () => router.post("/admin/user/two-factor-recovery-codes", {}, { preserveScroll: true }),
							children: "New recovery codes"
						}), /* @__PURE__ */ jsx(Button, {
							variant: "destructive-outline",
							onClick: () => router.delete("/admin/user/two-factor-authentication", { preserveScroll: true }),
							children: "Turn off"
						})]
					})]
				}) : /* @__PURE__ */ jsx(Button, {
					onClick: () => router.post("/admin/user/two-factor-authentication", {}, { preserveScroll: true }),
					children: "Set up two-factor authentication"
				})
			})
		]
	})] });
}
//#endregion
export { Profile as default };
