import { t as useShared } from "./use-shared-BMnpkZPP.js";
import { v as Button } from "../ssr.js";
import { t as Badge } from "./badge-ChM6xC7L.js";
import { a as Panel, d as th, i as Pagination, l as Table, r as PageHeader, t as EmptyState, u as td } from "./ui-DQeK8Yrd.js";
import { t as formatDate } from "./date-x_Fsbx42.js";
import { Fragment, jsx, jsxs } from "react/jsx-runtime";
//#region resources/js/pages/admin/messages/subscribers.tsx
function Subscribers({ subscribers, activeCount }) {
	const { store } = useShared();
	return /* @__PURE__ */ jsxs(Fragment, { children: [/* @__PURE__ */ jsx(PageHeader, {
		title: "Newsletter subscribers",
		description: `${activeCount} people agreed to receive emails. The export includes the date and wording of their consent.`,
		actions: activeCount > 0 && /* @__PURE__ */ jsx(Button, {
			asChild: true,
			variant: "secondary",
			children: /* @__PURE__ */ jsx("a", {
				href: "/admin/subscribers/export",
				children: "Download CSV"
			})
		})
	}), /* @__PURE__ */ jsxs(Panel, {
		padded: false,
		children: [subscribers.data.length === 0 ? /* @__PURE__ */ jsx(EmptyState, { title: "No subscribers yet." }) : /* @__PURE__ */ jsxs(Table, { children: [/* @__PURE__ */ jsx("thead", { children: /* @__PURE__ */ jsxs("tr", { children: [
			/* @__PURE__ */ jsx("th", {
				className: th,
				children: "Email"
			}),
			/* @__PURE__ */ jsx("th", {
				className: th,
				children: "Subscribed"
			}),
			/* @__PURE__ */ jsx("th", {
				className: th,
				children: "Status"
			})
		] }) }), /* @__PURE__ */ jsx("tbody", { children: subscribers.data.map((s) => /* @__PURE__ */ jsxs("tr", { children: [
			/* @__PURE__ */ jsx("td", {
				className: td,
				children: s.email
			}),
			/* @__PURE__ */ jsx("td", {
				className: `${td} text-stone`,
				children: formatDate(s.consented_at, store.timezone)
			}),
			/* @__PURE__ */ jsx("td", {
				className: td,
				children: s.unsubscribed ? /* @__PURE__ */ jsx(Badge, { children: "Unsubscribed" }) : /* @__PURE__ */ jsx(Badge, {
					tone: "success",
					children: "Subscribed"
				})
			})
		] }, s.id)) })] }), /* @__PURE__ */ jsx(Pagination, { page: subscribers })]
	})] });
}
//#endregion
export { Subscribers as default };
