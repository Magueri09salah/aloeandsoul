import { a as ConfirmDialog, f as Motif, i as Textarea, l as Switch, n as Label, o as Dialog, r as Select, s as DialogContent, t as Input, v as Button } from "../ssr.js";
import { t as Badge } from "./badge-ChM6xC7L.js";
import { a as Panel, r as PageHeader } from "./ui-DQeK8Yrd.js";
import { t as Field } from "./field-BVcOZvwI.js";
import { router, useForm } from "@inertiajs/react";
import { useState } from "react";
import { Fragment, jsx, jsxs } from "react/jsx-runtime";
import { Plus } from "lucide-react";
//#region resources/js/pages/admin/categories/index.tsx
function Categories({ categories, motifs }) {
	const [editing, setEditing] = useState(null);
	return /* @__PURE__ */ jsxs(Fragment, { children: [
		/* @__PURE__ */ jsx(PageHeader, {
			title: "Categories",
			description: "Each category has its own page in the shop, with its colour and motif.",
			actions: /* @__PURE__ */ jsxs(Button, {
				onClick: () => setEditing("new"),
				children: [/* @__PURE__ */ jsx(Plus, { "aria-hidden": "true" }), " Add category"]
			})
		}),
		/* @__PURE__ */ jsx("div", {
			className: "grid gap-4 sm:grid-cols-2",
			children: categories.map((c) => /* @__PURE__ */ jsx(Panel, { children: /* @__PURE__ */ jsxs("div", {
				className: "flex gap-4",
				children: [/* @__PURE__ */ jsx("div", {
					className: "flex size-16 shrink-0 items-center justify-center rounded-full p-3 text-dune",
					style: { backgroundColor: c.tint },
					children: /* @__PURE__ */ jsx(Motif, { name: c.motif })
				}), /* @__PURE__ */ jsxs("div", {
					className: "min-w-0 flex-1",
					children: [
						/* @__PURE__ */ jsxs("div", {
							className: "flex flex-wrap items-center gap-2",
							children: [/* @__PURE__ */ jsx("h2", {
								className: "font-medium",
								children: c.name
							}), !c.is_active && /* @__PURE__ */ jsx(Badge, {
								tone: "warning",
								children: "Hidden"
							})]
						}),
						/* @__PURE__ */ jsxs("p", {
							className: "text-sm text-stone",
							children: ["/shop/", c.slug]
						}),
						/* @__PURE__ */ jsxs("p", {
							className: "mt-1 text-sm",
							children: [
								c.published_products_count,
								" published of ",
								c.products_count,
								" products"
							]
						}),
						/* @__PURE__ */ jsxs("div", {
							className: "mt-3 flex gap-2",
							children: [/* @__PURE__ */ jsx(Button, {
								size: "sm",
								variant: "secondary",
								onClick: () => setEditing(c),
								children: "Edit"
							}), /* @__PURE__ */ jsx(Button, {
								size: "sm",
								variant: "ghost",
								asChild: true,
								children: /* @__PURE__ */ jsx("a", {
									href: `/admin/products?category=${c.id}`,
									children: "Products"
								})
							})]
						})
					]
				})]
			}) }, c.id))
		}),
		/* @__PURE__ */ jsx(Dialog, {
			open: editing !== null,
			onOpenChange: (o) => !o && setEditing(null),
			children: editing !== null && /* @__PURE__ */ jsx(DialogContent, {
				title: editing === "new" ? "New category" : `Edit ${editing.name}`,
				className: "max-w-2xl",
				children: /* @__PURE__ */ jsx(CategoryForm, {
					category: editing === "new" ? null : editing,
					motifs,
					onDone: () => setEditing(null)
				})
			})
		})
	] });
}
function CategoryForm({ category, motifs, onDone }) {
	const form = useForm({
		name: category?.name ?? "",
		slug: category?.slug ?? "",
		tagline: category?.tagline ?? "",
		description: category?.description ?? "",
		tint: category?.tint ?? "#EDE5D8",
		motif: category?.motif ?? "leaf",
		sort_order: category?.sort_order ?? 0,
		is_active: category?.is_active ?? true,
		seo_title: category?.seo_title ?? "",
		seo_description: category?.seo_description ?? ""
	});
	const submit = (e) => {
		e.preventDefault();
		const opts = {
			preserveScroll: true,
			onSuccess: onDone
		};
		if (category) form.put(`/admin/categories/${category.id}`, opts);
		else form.post("/admin/categories", opts);
	};
	return /* @__PURE__ */ jsxs("form", {
		onSubmit: submit,
		noValidate: true,
		className: "space-y-4",
		children: [
			/* @__PURE__ */ jsxs("div", {
				className: "grid gap-4 sm:grid-cols-2",
				children: [/* @__PURE__ */ jsx(Field, {
					label: "Name",
					name: "name",
					error: form.errors.name,
					required: true,
					children: (p) => /* @__PURE__ */ jsx(Input, {
						...p,
						value: form.data.name,
						onChange: (e) => form.setData("name", e.target.value)
					})
				}), /* @__PURE__ */ jsx(Field, {
					label: "Web address",
					name: "slug",
					error: form.errors.slug,
					hint: "Changing it breaks existing links.",
					optional: true,
					children: (p) => /* @__PURE__ */ jsx(Input, {
						...p,
						value: form.data.slug,
						onChange: (e) => form.setData("slug", e.target.value)
					})
				})]
			}),
			/* @__PURE__ */ jsx(Field, {
				label: "Tagline",
				name: "tagline",
				error: form.errors.tagline,
				optional: true,
				children: (p) => /* @__PURE__ */ jsx(Input, {
					...p,
					value: form.data.tagline,
					onChange: (e) => form.setData("tagline", e.target.value),
					maxLength: 160
				})
			}),
			/* @__PURE__ */ jsx(Field, {
				label: "Description",
				name: "description",
				error: form.errors.description,
				hint: "Shown at the top of the category page. Describe the range without health claims.",
				optional: true,
				children: (p) => /* @__PURE__ */ jsx(Textarea, {
					...p,
					rows: 3,
					value: form.data.description,
					onChange: (e) => form.setData("description", e.target.value)
				})
			}),
			/* @__PURE__ */ jsxs("div", {
				className: "grid gap-4 sm:grid-cols-3",
				children: [
					/* @__PURE__ */ jsx(Field, {
						label: "Colour",
						name: "tint",
						error: form.errors.tint,
						children: (p) => /* @__PURE__ */ jsxs("div", {
							className: "flex gap-2",
							children: [/* @__PURE__ */ jsx("input", {
								type: "color",
								"aria-label": "Pick colour",
								value: form.data.tint,
								onChange: (e) => form.setData("tint", e.target.value.toUpperCase()),
								className: "h-11 w-12 rounded border border-line"
							}), /* @__PURE__ */ jsx(Input, {
								...p,
								value: form.data.tint,
								onChange: (e) => form.setData("tint", e.target.value),
								maxLength: 7
							})]
						})
					}),
					/* @__PURE__ */ jsx(Field, {
						label: "Motif",
						name: "motif",
						error: form.errors.motif,
						children: (p) => /* @__PURE__ */ jsx(Select, {
							...p,
							value: form.data.motif,
							onChange: (e) => form.setData("motif", e.target.value),
							children: motifs.map((m) => /* @__PURE__ */ jsx("option", {
								value: m,
								children: m[0]?.toUpperCase() + m.slice(1)
							}, m))
						})
					}),
					/* @__PURE__ */ jsx(Field, {
						label: "Position",
						name: "sort_order",
						error: form.errors.sort_order,
						children: (p) => /* @__PURE__ */ jsx(Input, {
							...p,
							type: "number",
							value: form.data.sort_order,
							onChange: (e) => form.setData("sort_order", Number(e.target.value))
						})
					})
				]
			}),
			/* @__PURE__ */ jsxs("div", {
				className: "grid gap-4 sm:grid-cols-2",
				children: [/* @__PURE__ */ jsx(Field, {
					label: "Search title",
					name: "seo_title",
					error: form.errors.seo_title,
					optional: true,
					children: (p) => /* @__PURE__ */ jsx(Input, {
						...p,
						value: form.data.seo_title,
						onChange: (e) => form.setData("seo_title", e.target.value),
						maxLength: 70
					})
				}), /* @__PURE__ */ jsx(Field, {
					label: "Search description",
					name: "seo_description",
					error: form.errors.seo_description,
					optional: true,
					children: (p) => /* @__PURE__ */ jsx(Input, {
						...p,
						value: form.data.seo_description,
						onChange: (e) => form.setData("seo_description", e.target.value),
						maxLength: 170
					})
				})]
			}),
			/* @__PURE__ */ jsxs("div", {
				className: "flex items-center gap-3",
				children: [/* @__PURE__ */ jsx(Switch, {
					id: "cat-active",
					checked: form.data.is_active,
					onCheckedChange: (v) => form.setData("is_active", v)
				}), /* @__PURE__ */ jsx(Label, {
					htmlFor: "cat-active",
					className: "font-normal",
					children: "Visible in the shop"
				})]
			}),
			/* @__PURE__ */ jsxs("div", {
				className: "flex flex-wrap justify-between gap-2 pt-2",
				children: [category && category.products_count === 0 ? /* @__PURE__ */ jsx(ConfirmDialog, {
					trigger: /* @__PURE__ */ jsx(Button, {
						type: "button",
						variant: "destructive-outline",
						children: "Delete"
					}),
					title: "Delete this category?",
					description: "It has no products. Its shop page will stop working.",
					confirmLabel: "Delete category",
					onConfirm: () => router.delete(`/admin/categories/${category.id}`, { onSuccess: onDone })
				}) : /* @__PURE__ */ jsx("span", {}), /* @__PURE__ */ jsx(Button, {
					type: "submit",
					loading: form.processing,
					children: "Save category"
				})]
			})
		]
	});
}
//#endregion
export { Categories as default };
