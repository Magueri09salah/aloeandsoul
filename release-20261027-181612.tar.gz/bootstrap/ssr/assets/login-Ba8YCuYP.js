import { c as Checkbox, n as Label, t as Input, v as Button } from "../ssr.js";
import { t as Field } from "./field-BVcOZvwI.js";
import { Head, Link, useForm } from "@inertiajs/react";
import { jsx, jsxs } from "react/jsx-runtime";
//#region resources/js/pages/admin/auth/login.tsx
function Login({ status }) {
	const form = useForm({
		email: "",
		password: "",
		remember: false
	});
	const submit = (e) => {
		e.preventDefault();
		form.post("/admin/login", { onFinish: () => form.reset("password") });
	};
	return /* @__PURE__ */ jsxs("div", {
		className: "rounded-lg border border-line bg-white p-8",
		children: [
			/* @__PURE__ */ jsx(Head, { title: "Sign in — Admin" }),
			/* @__PURE__ */ jsx("h1", {
				className: "font-display text-3xl",
				children: "Sign in"
			}),
			/* @__PURE__ */ jsx("p", {
				className: "mt-2 text-sm text-stone",
				children: "Shop administration"
			}),
			status && /* @__PURE__ */ jsx("p", {
				className: "mt-4 rounded-md bg-[#DDE7DA] px-3 py-2 text-sm text-[#2E4A31]",
				role: "status",
				children: status
			}),
			/* @__PURE__ */ jsxs("form", {
				onSubmit: submit,
				className: "mt-6 space-y-5",
				noValidate: true,
				children: [
					/* @__PURE__ */ jsx(Field, {
						label: "Email",
						name: "email",
						error: form.errors.email,
						required: true,
						children: (p) => /* @__PURE__ */ jsx(Input, {
							...p,
							type: "email",
							autoComplete: "username",
							autoFocus: true,
							value: form.data.email,
							onChange: (e) => form.setData("email", e.target.value)
						})
					}),
					/* @__PURE__ */ jsx(Field, {
						label: "Password",
						name: "password",
						error: form.errors.password,
						required: true,
						children: (p) => /* @__PURE__ */ jsx(Input, {
							...p,
							type: "password",
							autoComplete: "current-password",
							value: form.data.password,
							onChange: (e) => form.setData("password", e.target.value)
						})
					}),
					/* @__PURE__ */ jsxs("div", {
						className: "flex items-center justify-between gap-3",
						children: [/* @__PURE__ */ jsxs("div", {
							className: "flex items-center gap-2.5",
							children: [/* @__PURE__ */ jsx(Checkbox, {
								id: "remember",
								checked: form.data.remember,
								onCheckedChange: (v) => form.setData("remember", v === true)
							}), /* @__PURE__ */ jsx(Label, {
								htmlFor: "remember",
								className: "font-normal",
								children: "Keep me signed in"
							})]
						}), /* @__PURE__ */ jsx(Link, {
							href: "/admin/forgot-password",
							className: "text-sm underline underline-offset-4 hover:text-aloe",
							children: "Forgot password?"
						})]
					}),
					/* @__PURE__ */ jsx(Button, {
						type: "submit",
						className: "w-full",
						loading: form.processing,
						children: "Sign in"
					})
				]
			})
		]
	});
}
//#endregion
export { Login as default };
