import { t as cn } from "./utils-BqvNF826.js";
import { jsx } from "react/jsx-runtime";
//#region resources/js/components/ui/safe-html.tsx
/**
* Renders HTML produced on the server by CommonMark with raw HTML stripped
* and unsafe links removed (ProductPresenter::markdown). This is the only
* place in the app allowed to inject HTML; never pass user input here.
*/
function SafeHtml({ html, className }) {
	return /* @__PURE__ */ jsx("div", {
		className: cn(className),
		dangerouslySetInnerHTML: { __html: html }
	});
}
//#endregion
export { SafeHtml as t };
