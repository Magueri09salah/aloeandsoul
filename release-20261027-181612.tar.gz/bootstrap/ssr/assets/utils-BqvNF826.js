import { clsx } from "clsx";
import { twMerge } from "tailwind-merge";
//#region resources/js/lib/utils.ts
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
/** Pluralise a simple English noun: plural(2, 'item') → "2 items". */
function plural(count, singular, pluralForm = `${singular}s`) {
	return `${count} ${count === 1 ? singular : pluralForm}`;
}
//#endregion
export { plural as n, cn as t };
