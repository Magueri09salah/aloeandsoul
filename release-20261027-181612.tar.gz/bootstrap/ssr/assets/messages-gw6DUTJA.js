import { t as useShared } from "./use-shared-BMnpkZPP.js";
import { a as ConfirmDialog, c as Checkbox, n as Label, v as Button } from "../ssr.js";
import { t as Badge } from "./badge-ChM6xC7L.js";
import { a as Panel, i as Pagination, r as PageHeader, t as EmptyState } from "./ui-DQeK8Yrd.js";
import { n as formatDateTime } from "./date-x_Fsbx42.js";
import { router } from "@inertiajs/react";
import { Fragment, jsx, jsxs } from "react/jsx-runtime";
//#region resources/js/pages/admin/messages/index.tsx
function Messages({ messages, unreadCount, filters }) {
	const { store } = useShared();
	return /* @__PURE__ */ jsxs(Fragment, { children: [
		/* @__PURE__ */ jsx(PageHeader, {
			title: "Messages",
			description: `From the contact form. ${unreadCount} unread.`
		}),
		/* @__PURE__ */ jsxs("div", {
			className: "mb-4 flex items-center gap-2.5",
			children: [/* @__PURE__ */ jsx(Checkbox, {
				id: "unread",
				checked: filters.unread,
				onCheckedChange: (v) => router.get("/admin/messages", v === true ? { unread: 1 } : {}, { preserveState: true })
			}), /* @__PURE__ */ jsx(Label, {
				htmlFor: "unread",
				className: "font-normal",
				children: "Unread only"
			})]
		}),
		/* @__PURE__ */ jsxs(Panel, {
			padded: false,
			children: [messages.data.length === 0 ? /* @__PURE__ */ jsx(EmptyState, { title: "No messages." }) : /* @__PURE__ */ jsx("ul", {
				className: "divide-y divide-line",
				children: messages.data.map((m) => /* @__PURE__ */ jsxs("li", {
					className: "px-5 py-4",
					children: [/* @__PURE__ */ jsxs("div", {
						className: "flex flex-wrap items-start justify-between gap-3",
						children: [/* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsxs("p", {
							className: "font-medium",
							children: [
								m.name,
								" ",
								!m.read && /* @__PURE__ */ jsx(Badge, {
									tone: "info",
									children: "New"
								})
							]
						}), /* @__PURE__ */ jsxs("p", {
							className: "text-sm text-stone",
							children: [
								/* @__PURE__ */ jsx("a", {
									href: `mailto:${m.email}`,
									className: "underline underline-offset-4",
									children: m.email
								}),
								m.phone && `, ${m.phone}`,
								" · ",
								formatDateTime(m.created_at, store.timezone)
							]
						})] }), /* @__PURE__ */ jsxs("div", {
							className: "flex gap-1",
							children: [!m.read && /* @__PURE__ */ jsx(Button, {
								size: "sm",
								variant: "ghost",
								onClick: () => router.post(`/admin/messages/${m.id}/read`, {}, { preserveScroll: true }),
								children: "Mark as read"
							}), /* @__PURE__ */ jsx(ConfirmDialog, {
								trigger: /* @__PURE__ */ jsx(Button, {
									size: "sm",
									variant: "ghost",
									className: "text-clay",
									children: "Delete"
								}),
								title: "Delete this message?",
								description: `From ${m.name}.`,
								confirmLabel: "Delete",
								onConfirm: () => router.delete(`/admin/messages/${m.id}`, { preserveScroll: true })
							})]
						})]
					}), /* @__PURE__ */ jsx("p", {
						className: "mt-3 whitespace-pre-line",
						children: m.message
					})]
				}, m.id))
			}), /* @__PURE__ */ jsx(Pagination, { page: messages })]
		})
	] });
}
//#endregion
export { Messages as default };
