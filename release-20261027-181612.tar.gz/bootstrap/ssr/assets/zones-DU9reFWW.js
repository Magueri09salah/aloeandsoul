import { t as cn } from "./utils-BqvNF826.js";
import { a as ConfirmDialog, l as Switch, n as Label, o as Dialog, s as DialogContent, t as Input, v as Button } from "../ssr.js";
import { t as Badge } from "./badge-ChM6xC7L.js";
import { a as Panel, d as th, l as Table, r as PageHeader, t as EmptyState, u as td } from "./ui-DQeK8Yrd.js";
import { t as Field } from "./field-BVcOZvwI.js";
import { router, useForm } from "@inertiajs/react";
import { useState } from "react";
import { Fragment, jsx, jsxs } from "react/jsx-runtime";
import { Plus } from "lucide-react";
//#region resources/js/pages/admin/zones/index.tsx
function Zones({ zones, currency }) {
	const [editing, setEditing] = useState(null);
	return /* @__PURE__ */ jsxs(Fragment, { children: [
		/* @__PURE__ */ jsx(PageHeader, {
			title: "Delivery areas",
			description: "Customers choose an area at checkout; its fee is added to the amount paid on delivery. Checkout stays closed until at least one area is active.",
			actions: /* @__PURE__ */ jsxs(Button, {
				onClick: () => setEditing("new"),
				children: [/* @__PURE__ */ jsx(Plus, { "aria-hidden": "true" }), " Add area"]
			})
		}),
		/* @__PURE__ */ jsx(Panel, {
			padded: false,
			children: zones.length === 0 ? /* @__PURE__ */ jsx(EmptyState, {
				title: "No delivery areas yet.",
				children: "Add the cities or regions you deliver to, with their fees."
			}) : /* @__PURE__ */ jsxs(Table, { children: [/* @__PURE__ */ jsx("thead", { children: /* @__PURE__ */ jsxs("tr", { children: [
				/* @__PURE__ */ jsx("th", {
					className: th,
					children: "Area"
				}),
				/* @__PURE__ */ jsx("th", {
					className: cn(th, "text-right"),
					children: "Fee"
				}),
				/* @__PURE__ */ jsx("th", {
					className: cn(th, "text-right"),
					children: "Free from"
				}),
				/* @__PURE__ */ jsx("th", {
					className: th,
					children: "Typical time"
				}),
				/* @__PURE__ */ jsx("th", {
					className: th,
					children: /* @__PURE__ */ jsx("span", {
						className: "sr-only",
						children: "Actions"
					})
				})
			] }) }), /* @__PURE__ */ jsx("tbody", { children: zones.map((z) => /* @__PURE__ */ jsxs("tr", { children: [
				/* @__PURE__ */ jsxs("td", {
					className: td,
					children: [
						z.name,
						" ",
						!z.is_active && /* @__PURE__ */ jsx(Badge, {
							tone: "warning",
							children: "Off"
						})
					]
				}),
				/* @__PURE__ */ jsxs("td", {
					className: cn(td, "text-right tabular-nums"),
					children: [
						z.fee,
						" ",
						currency
					]
				}),
				/* @__PURE__ */ jsx("td", {
					className: cn(td, "text-right tabular-nums"),
					children: z.free_over ? `${z.free_over} ${currency}` : "—"
				}),
				/* @__PURE__ */ jsx("td", {
					className: td,
					children: z.estimate ?? "—"
				}),
				/* @__PURE__ */ jsx("td", {
					className: cn(td, "text-right"),
					children: /* @__PURE__ */ jsx(Button, {
						size: "sm",
						variant: "ghost",
						onClick: () => setEditing(z),
						children: "Edit"
					})
				})
			] }, z.id)) })] })
		}),
		/* @__PURE__ */ jsx(Dialog, {
			open: editing !== null,
			onOpenChange: (o) => !o && setEditing(null),
			children: editing !== null && /* @__PURE__ */ jsx(DialogContent, {
				title: editing === "new" ? "New delivery area" : `Edit ${editing.name}`,
				children: /* @__PURE__ */ jsx(ZoneForm, {
					zone: editing === "new" ? null : editing,
					currency,
					onDone: () => setEditing(null)
				})
			})
		})
	] });
}
function ZoneForm({ zone, currency, onDone }) {
	const form = useForm({
		name: zone?.name ?? "",
		fee: zone?.fee ?? "",
		free_over: zone?.free_over ?? "",
		estimate: zone?.estimate ?? "",
		is_active: zone?.is_active ?? true,
		sort_order: zone?.sort_order ?? 0
	});
	const submit = (e) => {
		e.preventDefault();
		const opts = {
			preserveScroll: true,
			onSuccess: onDone
		};
		if (zone) form.put(`/admin/delivery-zones/${zone.id}`, opts);
		else form.post("/admin/delivery-zones", opts);
	};
	return /* @__PURE__ */ jsxs("form", {
		onSubmit: submit,
		noValidate: true,
		className: "space-y-4",
		children: [
			/* @__PURE__ */ jsx(Field, {
				label: "Area name",
				name: "name",
				error: form.errors.name,
				hint: "For example Marrakech, or Other cities.",
				required: true,
				children: (p) => /* @__PURE__ */ jsx(Input, {
					...p,
					value: form.data.name,
					onChange: (e) => form.setData("name", e.target.value),
					maxLength: 80
				})
			}),
			/* @__PURE__ */ jsxs("div", {
				className: "grid gap-4 sm:grid-cols-2",
				children: [/* @__PURE__ */ jsx(Field, {
					label: `Delivery fee (${currency})`,
					name: "fee",
					error: form.errors.fee,
					required: true,
					children: (p) => /* @__PURE__ */ jsx(Input, {
						...p,
						inputMode: "decimal",
						value: form.data.fee,
						onChange: (e) => form.setData("fee", e.target.value)
					})
				}), /* @__PURE__ */ jsx(Field, {
					label: `Free delivery from (${currency})`,
					name: "free_over",
					error: form.errors.free_over,
					optional: true,
					children: (p) => /* @__PURE__ */ jsx(Input, {
						...p,
						inputMode: "decimal",
						value: form.data.free_over,
						onChange: (e) => form.setData("free_over", e.target.value)
					})
				})]
			}),
			/* @__PURE__ */ jsx(Field, {
				label: "Typical delivery time",
				name: "estimate",
				error: form.errors.estimate,
				hint: "Shown to customers, e.g. 1–2 days.",
				optional: true,
				children: (p) => /* @__PURE__ */ jsx(Input, {
					...p,
					value: form.data.estimate,
					onChange: (e) => form.setData("estimate", e.target.value),
					maxLength: 80
				})
			}),
			/* @__PURE__ */ jsxs("div", {
				className: "flex items-center gap-3",
				children: [/* @__PURE__ */ jsx(Switch, {
					id: "zone-active",
					checked: form.data.is_active,
					onCheckedChange: (v) => form.setData("is_active", v)
				}), /* @__PURE__ */ jsx(Label, {
					htmlFor: "zone-active",
					className: "font-normal",
					children: "Offered at checkout"
				})]
			}),
			/* @__PURE__ */ jsxs("div", {
				className: "flex justify-between gap-2 pt-2",
				children: [zone ? /* @__PURE__ */ jsx(ConfirmDialog, {
					trigger: /* @__PURE__ */ jsx(Button, {
						type: "button",
						variant: "destructive-outline",
						children: "Delete"
					}),
					title: "Delete this delivery area?",
					description: "If past orders used it, it will be turned off instead.",
					confirmLabel: "Delete",
					onConfirm: () => router.delete(`/admin/delivery-zones/${zone.id}`, { onSuccess: onDone })
				}) : /* @__PURE__ */ jsx("span", {}), /* @__PURE__ */ jsx(Button, {
					type: "submit",
					loading: form.processing,
					children: "Save"
				})]
			})
		]
	});
}
//#endregion
export { Zones as default };
