import { t as Input, v as Button } from "../ssr.js";
import { t as Field } from "./field-BVcOZvwI.js";
import { Head, useForm } from "@inertiajs/react";
import { useState } from "react";
import { jsx, jsxs } from "react/jsx-runtime";
//#region resources/js/pages/admin/auth/two-factor-challenge.tsx
function TwoFactorChallenge() {
	const [useRecovery, setUseRecovery] = useState(false);
	const form = useForm({
		code: "",
		recovery_code: ""
	});
	const submit = (e) => {
		e.preventDefault();
		form.transform((d) => useRecovery ? { recovery_code: d.recovery_code } : { code: d.code });
		form.post("/admin/two-factor-challenge", { onFinish: () => form.reset() });
	};
	return /* @__PURE__ */ jsxs("div", {
		className: "rounded-lg border border-line bg-white p-8",
		children: [
			/* @__PURE__ */ jsx(Head, { title: "Two-factor authentication — Admin" }),
			/* @__PURE__ */ jsx("h1", {
				className: "font-display text-3xl",
				children: "Confirm it’s you"
			}),
			/* @__PURE__ */ jsx("p", {
				className: "mt-2 text-sm text-stone",
				children: useRecovery ? "Enter one of your recovery codes." : "Enter the 6-digit code from your authenticator app."
			}),
			/* @__PURE__ */ jsxs("form", {
				onSubmit: submit,
				className: "mt-6 space-y-5",
				noValidate: true,
				children: [useRecovery ? /* @__PURE__ */ jsx(Field, {
					label: "Recovery code",
					name: "recovery_code",
					error: form.errors.recovery_code,
					required: true,
					children: (p) => /* @__PURE__ */ jsx(Input, {
						...p,
						autoComplete: "one-time-code",
						autoFocus: true,
						value: form.data.recovery_code,
						onChange: (e) => form.setData("recovery_code", e.target.value)
					})
				}) : /* @__PURE__ */ jsx(Field, {
					label: "Authentication code",
					name: "code",
					error: form.errors.code,
					required: true,
					children: (p) => /* @__PURE__ */ jsx(Input, {
						...p,
						inputMode: "numeric",
						autoComplete: "one-time-code",
						autoFocus: true,
						maxLength: 6,
						value: form.data.code,
						onChange: (e) => form.setData("code", e.target.value.replace(/\D/g, ""))
					})
				}), /* @__PURE__ */ jsx(Button, {
					type: "submit",
					className: "w-full",
					loading: form.processing,
					children: "Continue"
				})]
			}),
			/* @__PURE__ */ jsx("button", {
				type: "button",
				onClick: () => setUseRecovery(!useRecovery),
				className: "mt-6 text-sm underline underline-offset-4",
				children: useRecovery ? "Use an authentication code" : "Use a recovery code instead"
			})
		]
	});
}
//#endregion
export { TwoFactorChallenge as default };
