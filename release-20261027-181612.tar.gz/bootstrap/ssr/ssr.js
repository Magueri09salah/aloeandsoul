import { t as cn } from "./assets/utils-BqvNF826.js";
import { t as useShared } from "./assets/use-shared-BMnpkZPP.js";
import { t as formatMoney } from "./assets/money-CcsjAkm_.js";
import { Head, Link, createInertiaApp, router, useForm, usePage } from "@inertiajs/react";
import createServer from "@inertiajs/react/server";
import ReactDOMServer from "react-dom/server";
import { Suspense, createContext, lazy, useContext, useEffect, useId, useMemo, useRef, useState } from "react";
import { Fragment, jsx, jsxs } from "react/jsx-runtime";
import { Toaster, toast } from "sonner";
import { cva } from "class-variance-authority";
import { AlertDialog, Checkbox, Dialog, NavigationMenu, Slot, Switch } from "radix-ui";
import { ChevronDown, Menu, Minus, Plus, Search, ShoppingBag, X } from "lucide-react";
//#region resources/js/components/brand/logo.tsx
/** The circular aloe-and-figure mark (from the client's logo) with the wordmark set in type. */
function Logo({ className, compact = false, href = "/" }) {
	return /* @__PURE__ */ jsxs(Link, {
		href,
		className: cn("group inline-flex items-center gap-3 text-ink", className),
		"aria-label": "Aloe & Soul, home",
		children: [/* @__PURE__ */ jsx("img", {
			src: "/brand/logo-mark-96.png",
			srcSet: "/brand/logo-mark-96.png 1x, /brand/logo-mark-192.png 2x",
			alt: "",
			width: 40,
			height: 40,
			className: "size-10 shrink-0"
		}), !compact && /* @__PURE__ */ jsx("span", {
			className: "font-display text-[1.15rem] leading-none tracking-[0.16em] whitespace-nowrap text-[#55554F]",
			children: "ALOE & SOUL"
		})]
	});
}
//#endregion
//#region resources/js/components/ui/flash-toaster.tsx
function show(flash) {
	if (flash?.success) toast.success(flash.success);
	if (flash?.error) toast.error(flash.error);
}
/**
* Shows the server's flash messages as toasts: once for the first page load,
* then once per successful navigation.
*/
function FlashToaster() {
	const initial = usePage().props.flash;
	const shownInitial = useRef(false);
	useEffect(() => {
		if (!shownInitial.current) {
			shownInitial.current = true;
			show(initial);
		}
		return router.on("success", (event) => show(event.detail.page.props.flash));
	}, []);
	return /* @__PURE__ */ jsx(Toaster, {
		position: "bottom-center",
		toastOptions: { classNames: {
			toast: "!rounded-lg !border-line !bg-ink !text-ivory !font-sans !shadow-overlay",
			description: "!text-ivory/80"
		} }
	});
}
//#endregion
//#region resources/js/layouts/auth-layout.tsx
/** Minimal shell for admin sign-in, password reset and two-factor pages. */
function AuthLayout({ children }) {
	return /* @__PURE__ */ jsxs("div", {
		className: "flex min-h-dvh flex-col items-center justify-center bg-ivory px-4 py-12",
		children: [
			/* @__PURE__ */ jsx(Head, { children: /* @__PURE__ */ jsx("meta", {
				"head-key": "robots",
				name: "robots",
				content: "noindex,nofollow"
			}) }),
			/* @__PURE__ */ jsx(Logo, {
				href: "/",
				className: "mb-10"
			}),
			/* @__PURE__ */ jsx("main", {
				className: "w-full max-w-md",
				children
			}),
			/* @__PURE__ */ jsx(FlashToaster, {})
		]
	});
}
//#endregion
//#region resources/js/components/store/cart-context.tsx
var CartUiContext = createContext(null);
/** Cart drawer state, kept by the persistent storefront layout across visits. */
function CartUiProvider({ children }) {
	const [isOpen, setOpen] = useState(false);
	const value = useMemo(() => ({
		isOpen,
		setOpen,
		open: () => setOpen(true)
	}), [isOpen]);
	return /* @__PURE__ */ jsx(CartUiContext.Provider, {
		value,
		children
	});
}
function useCartUi() {
	const ctx = useContext(CartUiContext);
	if (!ctx) throw new Error("useCartUi must be used inside <CartUiProvider>");
	return ctx;
}
//#endregion
//#region resources/js/components/ui/spinner.tsx
function Spinner({ className, label }) {
	return /* @__PURE__ */ jsxs("span", {
		role: label ? "status" : void 0,
		className: cn("inline-flex", className),
		children: [/* @__PURE__ */ jsxs("svg", {
			className: "size-4 animate-spin motion-reduce:animate-none",
			viewBox: "0 0 24 24",
			fill: "none",
			"aria-hidden": "true",
			children: [/* @__PURE__ */ jsx("circle", {
				cx: "12",
				cy: "12",
				r: "9",
				stroke: "currentColor",
				strokeOpacity: "0.25",
				strokeWidth: "2.5"
			}), /* @__PURE__ */ jsx("path", {
				d: "M21 12a9 9 0 0 0-9-9",
				stroke: "currentColor",
				strokeWidth: "2.5",
				strokeLinecap: "round"
			})]
		}), label && /* @__PURE__ */ jsx("span", {
			className: "sr-only",
			children: label
		})]
	});
}
//#endregion
//#region resources/js/components/ui/button.tsx
var buttonVariants = cva("inline-flex shrink-0 items-center justify-center gap-2 rounded-full font-sans font-medium whitespace-nowrap transition-[background-color,color,border-color,transform] duration-150 ease-(--ease-out-soft) select-none active:scale-[0.98] disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:shrink-0", {
	variants: {
		variant: {
			primary: "bg-ink text-ivory hover:bg-aloe",
			secondary: "border border-ink bg-transparent text-ink hover:bg-ink hover:text-ivory",
			quiet: "bg-sand text-ink hover:bg-line",
			ghost: "text-ink hover:bg-sand",
			link: "rounded-none px-0 text-ink underline decoration-1 underline-offset-4 hover:text-aloe",
			destructive: "bg-clay text-white hover:bg-clay/90",
			"destructive-outline": "border border-clay text-clay hover:bg-clay-soft"
		},
		size: {
			sm: "h-9 px-4 text-sm [&_svg]:size-4",
			md: "h-11 px-6 text-[0.95rem] [&_svg]:size-4",
			lg: "h-13 px-8 text-base [&_svg]:size-5",
			icon: "size-11 [&_svg]:size-5",
			"icon-sm": "size-9 [&_svg]:size-4"
		}
	},
	compoundVariants: [{
		variant: "link",
		className: "h-auto px-0"
	}],
	defaultVariants: {
		variant: "primary",
		size: "md"
	}
});
function Button({ className, variant, size, asChild = false, loading = false, disabled, children, ...props }) {
	const Comp = asChild ? Slot.Root : "button";
	return /* @__PURE__ */ jsx(Comp, {
		"data-slot": "button",
		className: cn(buttonVariants({
			variant,
			size,
			className
		})),
		disabled: asChild ? void 0 : disabled || loading,
		"aria-busy": loading || void 0,
		...props,
		children: asChild ? children : /* @__PURE__ */ jsxs(Fragment, { children: [loading && /* @__PURE__ */ jsx(Spinner, {}), children] })
	});
}
//#endregion
//#region resources/js/components/ui/sheet.tsx
var Sheet = Dialog.Root;
Dialog.Trigger;
Dialog.Close;
var sheetVariants = cva("fixed z-50 flex flex-col bg-ivory shadow-overlay outline-none data-[state=closed]:duration-300 data-[state=open]:duration-400 data-[state=open]:animate-in data-[state=closed]:animate-out", {
	variants: { side: {
		right: "inset-y-0 right-0 h-full w-full max-w-[26rem] data-[state=closed]:slide-out-to-right data-[state=open]:slide-in-from-right",
		left: "inset-y-0 left-0 h-full w-[88%] max-w-sm data-[state=closed]:slide-out-to-left data-[state=open]:slide-in-from-left",
		bottom: "inset-x-0 bottom-0 max-h-[88dvh] rounded-t-2xl data-[state=closed]:slide-out-to-bottom data-[state=open]:slide-in-from-bottom"
	} },
	defaultVariants: { side: "right" }
});
function SheetContent({ side, className, children, title, description, hideTitle, ...props }) {
	return /* @__PURE__ */ jsxs(Dialog.Portal, { children: [/* @__PURE__ */ jsx(Dialog.Overlay, { className: "fixed inset-0 z-50 bg-ink/35 data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:animate-in data-[state=open]:fade-in-0" }), /* @__PURE__ */ jsxs(Dialog.Content, {
		className: cn(sheetVariants({ side }), className),
		...props,
		children: [
			/* @__PURE__ */ jsxs("div", {
				className: cn("flex items-center justify-between gap-4 border-b border-line px-5 py-4", hideTitle && "sr-only"),
				children: [/* @__PURE__ */ jsx(Dialog.Title, {
					className: "font-display text-2xl",
					children: title
				}), /* @__PURE__ */ jsxs(Dialog.Close, {
					className: "-mr-2 inline-flex size-10 items-center justify-center rounded-full hover:bg-sand",
					children: [/* @__PURE__ */ jsx(X, {
						className: "size-5",
						"aria-hidden": "true"
					}), /* @__PURE__ */ jsx("span", {
						className: "sr-only",
						children: "Close"
					})]
				})]
			}),
			description ? /* @__PURE__ */ jsx(Dialog.Description, {
				className: "sr-only",
				children: description
			}) : /* @__PURE__ */ jsx(Dialog.Description, {
				className: "sr-only",
				children: title
			}),
			children
		]
	})] });
}
//#endregion
//#region resources/js/components/ui/price.tsx
/** Price with optional struck-through regular price, read out clearly by screen readers. */
function Price({ amount, regular, from = false, currency, className }) {
	const shared = useShared();
	const code = currency ?? shared.store.currency;
	if (amount === null) return /* @__PURE__ */ jsx("span", {
		className: cn("text-stone", className),
		children: "Price on request"
	});
	const onSale = regular !== void 0 && regular !== null && regular > amount;
	return /* @__PURE__ */ jsxs("span", {
		className: cn("inline-flex flex-wrap items-baseline gap-x-2 tabular-nums", className),
		children: [from && /* @__PURE__ */ jsx("span", {
			className: "text-[0.85em] text-stone",
			children: "From"
		}), onSale ? /* @__PURE__ */ jsxs(Fragment, { children: [
			/* @__PURE__ */ jsx("span", {
				className: "sr-only",
				children: "Sale price"
			}),
			/* @__PURE__ */ jsx("span", {
				className: "text-dune-deep",
				children: formatMoney(amount, code)
			}),
			/* @__PURE__ */ jsx("span", {
				className: "sr-only",
				children: ", was"
			}),
			/* @__PURE__ */ jsx("s", {
				className: "text-[0.85em] text-stone decoration-1",
				children: formatMoney(regular, code)
			})
		] }) : /* @__PURE__ */ jsx("span", { children: formatMoney(amount, code) })]
	});
}
//#endregion
//#region resources/js/components/ui/quantity-stepper.tsx
/** Pill-shaped −/+ control with 44px targets. Announces the current value. */
function QuantityStepper({ value, min = 1, max, onChange, label, disabled, size = "md", className }) {
	const button = "inline-flex items-center justify-center rounded-full text-ink transition-colors hover:bg-sand disabled:cursor-not-allowed disabled:opacity-35 disabled:hover:bg-transparent";
	const dims = size === "sm" ? "size-9" : "size-11";
	return /* @__PURE__ */ jsxs("div", {
		role: "group",
		"aria-label": label,
		className: cn("inline-flex items-center rounded-full border border-line bg-white", className),
		children: [
			/* @__PURE__ */ jsx("button", {
				type: "button",
				className: cn(button, dims),
				onClick: () => onChange(Math.max(min, value - 1)),
				disabled: disabled || value <= min,
				"aria-label": `Decrease ${label.toLowerCase()}`,
				children: /* @__PURE__ */ jsx(Minus, {
					className: "size-4",
					"aria-hidden": "true"
				})
			}),
			/* @__PURE__ */ jsx("output", {
				"aria-live": "polite",
				className: cn("min-w-8 text-center tabular-nums", size === "sm" ? "text-sm" : "text-base"),
				children: value
			}),
			/* @__PURE__ */ jsx("button", {
				type: "button",
				className: cn(button, dims),
				onClick: () => onChange(Math.min(max, value + 1)),
				disabled: disabled || value >= max,
				"aria-label": `Increase ${label.toLowerCase()}`,
				children: /* @__PURE__ */ jsx(Plus, {
					className: "size-4",
					"aria-hidden": "true"
				})
			})
		]
	});
}
//#endregion
//#region resources/js/components/ui/responsive-image.tsx
/** srcset/sizes with intrinsic dimensions so the layout never shifts. */
function ResponsiveImage({ image, sizes, priority = false, className, alt }) {
	return /* @__PURE__ */ jsx("img", {
		src: image.src,
		srcSet: image.srcset,
		sizes,
		width: image.width,
		height: image.height,
		alt: alt ?? image.alt,
		loading: priority ? "eager" : "lazy",
		decoding: priority ? "sync" : "async",
		fetchPriority: priority ? "high" : "auto",
		className: cn("h-full w-full object-cover", className)
	});
}
//#endregion
//#region resources/js/components/brand/motif.tsx
/**
* Line motifs that give each category a recognisable mark: a desert horizon,
* the logo's circle, an Essaouira wave, an aloe leaf. Decorative only.
*/
function Motif({ name, className }) {
	const common = {
		viewBox: "0 0 120 120",
		fill: "none",
		stroke: "currentColor",
		strokeWidth: 1.25,
		strokeLinecap: "round",
		"aria-hidden": true,
		className: cn("size-full", className)
	};
	switch (name) {
		case "horizon": return /* @__PURE__ */ jsxs("svg", {
			...common,
			children: [/* @__PURE__ */ jsx("circle", {
				cx: "60",
				cy: "62",
				r: "20"
			}), /* @__PURE__ */ jsx("path", { d: "M8 82h104M20 92h80M34 102h52" })]
		});
		case "circle": return /* @__PURE__ */ jsxs("svg", {
			...common,
			children: [
				/* @__PURE__ */ jsx("circle", {
					cx: "60",
					cy: "60",
					r: "44"
				}),
				/* @__PURE__ */ jsx("circle", {
					cx: "60",
					cy: "60",
					r: "30"
				}),
				/* @__PURE__ */ jsx("circle", {
					cx: "60",
					cy: "60",
					r: "16"
				})
			]
		});
		case "wave": return /* @__PURE__ */ jsxs("svg", {
			...common,
			children: [
				/* @__PURE__ */ jsx("path", { d: "M10 48c12-10 22-10 34 0s22 10 34 0 22-10 32 0" }),
				/* @__PURE__ */ jsx("path", { d: "M10 64c12-10 22-10 34 0s22 10 34 0 22-10 32 0" }),
				/* @__PURE__ */ jsx("path", { d: "M10 80c12-10 22-10 34 0s22 10 34 0 22-10 32 0" })
			]
		});
		default: return /* @__PURE__ */ jsxs("svg", {
			...common,
			children: [/* @__PURE__ */ jsx("path", { d: "M62 12C48 34 38 58 40 82c1 12 7 21 16 26-3-14-3-32 0-50 2-16 4-32 6-46Z" }), /* @__PURE__ */ jsx("path", { d: "M62 12c4 22 10 46 8 66-1 12-5 22-12 30" })]
		});
	}
}
//#endregion
//#region resources/js/components/store/product-placeholder.tsx
/** Shown until the client uploads an official product photograph. Never a fake packshot. */
function ProductPlaceholder({ tint, motif = "leaf", className }) {
	return /* @__PURE__ */ jsx("div", {
		className: cn("flex h-full w-full items-center justify-center", className),
		style: { backgroundColor: tint },
		children: /* @__PURE__ */ jsx("div", {
			className: "w-2/5 max-w-36 text-dune",
			children: /* @__PURE__ */ jsx(Motif, { name: motif })
		})
	});
}
//#endregion
//#region resources/js/components/store/cart-lines.tsx
/** Cart lines with quantity controls; used by the drawer and the cart page. */
function CartLines({ lines, compact = false }) {
	const { store, errors } = useShared();
	const [busy, setBusy] = useState(null);
	const update = (line, quantity) => {
		const options = {
			preserveScroll: true,
			preserveState: true,
			onStart: () => setBusy(line.id),
			onFinish: () => setBusy(null)
		};
		if (quantity < 1) router.delete(`/cart/items/${line.id}`, options);
		else router.patch(`/cart/items/${line.id}`, { quantity }, options);
	};
	return /* @__PURE__ */ jsxs("ul", {
		className: "divide-y divide-line",
		children: [lines.map((line) => /* @__PURE__ */ jsxs("li", {
			className: cn("flex gap-4 py-5", busy === line.id && "opacity-60"),
			"aria-busy": busy === line.id || void 0,
			children: [/* @__PURE__ */ jsx(Link, {
				href: `/products/${line.product_slug}`,
				className: cn("shrink-0 overflow-hidden", compact ? "h-24 w-20" : "h-32 w-26"),
				style: { backgroundColor: line.tint },
				tabIndex: -1,
				"aria-hidden": "true",
				children: line.image ? /* @__PURE__ */ jsx(ResponsiveImage, {
					image: line.image,
					sizes: "104px",
					alt: ""
				}) : /* @__PURE__ */ jsx(ProductPlaceholder, { tint: line.tint })
			}), /* @__PURE__ */ jsxs("div", {
				className: "flex min-w-0 flex-1 flex-col",
				children: [
					/* @__PURE__ */ jsxs("div", {
						className: "flex items-start justify-between gap-3",
						children: [/* @__PURE__ */ jsxs("div", {
							className: "min-w-0",
							children: [
								/* @__PURE__ */ jsx(Link, {
									href: `/products/${line.product_slug}`,
									className: "font-medium hover:text-aloe",
									children: line.product_name
								}),
								line.variant_name && /* @__PURE__ */ jsxs("p", {
									className: "text-sm text-stone",
									children: [line.option_label ? `${line.option_label}: ` : "", line.variant_name]
								}),
								line.unit_price_minor !== null && /* @__PURE__ */ jsxs("p", {
									className: "mt-0.5 text-sm text-stone",
									children: [/* @__PURE__ */ jsx(Price, {
										amount: line.unit_price_minor,
										regular: line.regular_price_minor
									}), " each"]
								})
							]
						}), /* @__PURE__ */ jsx("p", {
							className: "shrink-0 tabular-nums",
							children: line.issue ? "—" : formatMoney(line.line_total_minor, store.currency)
						})]
					}),
					line.issue && /* @__PURE__ */ jsx("p", {
						className: "mt-2 text-sm text-clay",
						role: "status",
						children: line.issue
					}),
					/* @__PURE__ */ jsxs("div", {
						className: "mt-auto flex items-center justify-between gap-3 pt-3",
						children: [line.max_quantity > 0 ? /* @__PURE__ */ jsx(QuantityStepper, {
							size: "sm",
							label: `Quantity of ${line.product_name}`,
							value: line.quantity,
							min: 1,
							max: line.max_quantity,
							disabled: busy === line.id,
							onChange: (q) => update(line, q)
						}) : /* @__PURE__ */ jsx("span", {}), /* @__PURE__ */ jsxs("button", {
							type: "button",
							onClick: () => update(line, 0),
							disabled: busy === line.id,
							className: "text-sm text-stone underline underline-offset-4 hover:text-clay",
							children: ["Remove", /* @__PURE__ */ jsxs("span", {
								className: "sr-only",
								children: [" ", line.product_name]
							})]
						})]
					})
				]
			})]
		}, line.id)), errors.quantity && /* @__PURE__ */ jsx("li", {
			className: "py-3 text-sm text-clay",
			role: "alert",
			children: errors.quantity
		})]
	});
}
//#endregion
//#region resources/js/components/store/cart-drawer.tsx
function CartDrawer() {
	const { isOpen, setOpen } = useCartUi();
	const { cart, store, navigation } = useShared();
	const lines = cart?.lines ?? [];
	return /* @__PURE__ */ jsx(Sheet, {
		open: isOpen,
		onOpenChange: setOpen,
		children: /* @__PURE__ */ jsx(SheetContent, {
			title: "Your cart",
			side: "right",
			children: lines.length === 0 ? /* @__PURE__ */ jsxs("div", {
				className: "flex flex-1 flex-col justify-center px-6 pb-16",
				children: [
					/* @__PURE__ */ jsx("p", {
						className: "font-display text-3xl leading-tight",
						children: "Your cart is empty."
					}),
					/* @__PURE__ */ jsx("p", {
						className: "mt-3 text-stone",
						children: "Start with one of our collections."
					}),
					/* @__PURE__ */ jsx("ul", {
						className: "mt-6 space-y-2",
						children: navigation?.map((c) => /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsx(Link, {
							href: `/shop/${c.slug}`,
							onClick: () => setOpen(false),
							className: "text-lg underline-offset-4 hover:underline",
							children: c.name
						}) }, c.slug))
					})
				]
			}) : /* @__PURE__ */ jsxs(Fragment, { children: [/* @__PURE__ */ jsx("div", {
				className: "flex-1 overflow-y-auto px-5",
				children: /* @__PURE__ */ jsx(CartLines, {
					lines,
					compact: true
				})
			}), /* @__PURE__ */ jsxs("div", {
				className: "border-t border-line bg-white px-5 pt-5 pb-[max(1.25rem,env(safe-area-inset-bottom))]",
				children: [
					/* @__PURE__ */ jsxs("div", {
						className: "flex items-baseline justify-between",
						children: [/* @__PURE__ */ jsx("span", {
							className: "text-stone",
							children: "Subtotal"
						}), /* @__PURE__ */ jsx("span", {
							className: "text-lg tabular-nums",
							children: formatMoney(cart?.subtotal_minor ?? 0, store.currency)
						})]
					}),
					/* @__PURE__ */ jsx("p", {
						className: "mt-1 text-sm text-stone",
						children: "Delivery is added at checkout. You pay in cash when your order arrives."
					}),
					/* @__PURE__ */ jsxs("div", {
						className: "mt-4 grid gap-2",
						children: [/* @__PURE__ */ jsx(Button, {
							asChild: true,
							size: "lg",
							className: cart?.has_issues ? "pointer-events-none opacity-50" : void 0,
							children: /* @__PURE__ */ jsx(Link, {
								href: "/checkout",
								onClick: () => setOpen(false),
								"aria-disabled": cart?.has_issues || void 0,
								children: "Go to checkout"
							})
						}), /* @__PURE__ */ jsx(Button, {
							asChild: true,
							variant: "ghost",
							children: /* @__PURE__ */ jsx(Link, {
								href: "/cart",
								onClick: () => setOpen(false),
								children: "View cart"
							})
						})]
					})
				]
			})] })
		})
	});
}
//#endregion
//#region resources/js/components/ui/checkbox.tsx
function Checkbox$1({ className, ...props }) {
	return /* @__PURE__ */ jsx(Checkbox.Root, {
		"data-slot": "checkbox",
		className: cn("peer size-5 shrink-0 rounded-[4px] border border-stone/60 bg-white transition-colors focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-aloe disabled:opacity-50 aria-invalid:border-clay data-[state=checked]:border-ink data-[state=checked]:bg-ink data-[state=checked]:text-ivory", className),
		...props,
		children: /* @__PURE__ */ jsx(Checkbox.Indicator, {
			className: "flex items-center justify-center",
			children: /* @__PURE__ */ jsx("svg", {
				viewBox: "0 0 16 16",
				className: "size-3.5",
				fill: "none",
				"aria-hidden": "true",
				children: /* @__PURE__ */ jsx("path", {
					d: "m3.5 8.5 3 3 6-7",
					stroke: "currentColor",
					strokeWidth: "2",
					strokeLinecap: "round",
					strokeLinejoin: "round"
				})
			})
		})
	});
}
function Switch$1({ className, ...props }) {
	return /* @__PURE__ */ jsx(Switch.Root, {
		"data-slot": "switch",
		className: cn("inline-flex h-6 w-11 shrink-0 items-center rounded-full border border-transparent bg-line transition-colors focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-aloe disabled:opacity-50 data-[state=checked]:bg-aloe", className),
		...props,
		children: /* @__PURE__ */ jsx(Switch.Thumb, { className: "block size-5 translate-x-0.5 rounded-full bg-white shadow-sm transition-transform data-[state=checked]:translate-x-[1.375rem]" })
	});
}
//#endregion
//#region resources/js/components/store/newsletter-form.tsx
/** Email opt-in with explicit, unticked consent. */
function NewsletterForm({ tone = "dark" }) {
	const id = useId();
	const form = useForm({
		email: "",
		consent: false,
		website: ""
	});
	const submit = (e) => {
		e.preventDefault();
		form.post("/newsletter", {
			preserveScroll: true,
			onSuccess: () => form.reset()
		});
	};
	const dark = tone === "dark";
	return /* @__PURE__ */ jsxs("form", {
		onSubmit: submit,
		noValidate: true,
		className: "w-full max-w-md",
		children: [
			/* @__PURE__ */ jsxs("div", {
				className: "flex gap-2",
				children: [
					/* @__PURE__ */ jsx("label", {
						htmlFor: `${id}-email`,
						className: "sr-only",
						children: "Email address"
					}),
					/* @__PURE__ */ jsx("input", {
						id: `${id}-email`,
						type: "email",
						autoComplete: "email",
						value: form.data.email,
						onChange: (e) => form.setData("email", e.target.value),
						placeholder: "Your email address",
						"aria-invalid": form.errors.email ? true : void 0,
						"aria-describedby": form.errors.email ? `${id}-error` : void 0,
						className: dark ? "h-11 w-full rounded-full border border-ivory/30 bg-transparent px-5 text-ivory placeholder:text-ivory/50 focus-visible:border-ivory focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ivory" : "h-11 w-full rounded-full border border-line bg-white px-5 placeholder:text-stone/70"
					}),
					/* @__PURE__ */ jsx("input", {
						type: "text",
						name: "website",
						tabIndex: -1,
						autoComplete: "off",
						value: form.data.website,
						onChange: (e) => form.setData("website", e.target.value),
						className: "hidden",
						"aria-hidden": "true"
					}),
					/* @__PURE__ */ jsx(Button, {
						type: "submit",
						loading: form.processing,
						variant: dark ? "quiet" : "primary",
						className: "shrink-0",
						children: "Subscribe"
					})
				]
			}),
			/* @__PURE__ */ jsxs("div", {
				className: "mt-3 flex items-start gap-3",
				children: [/* @__PURE__ */ jsx(Checkbox$1, {
					id: `${id}-consent`,
					checked: form.data.consent,
					onCheckedChange: (v) => form.setData("consent", v === true),
					"aria-invalid": form.errors.consent ? true : void 0,
					className: dark ? "border-ivory/50 bg-transparent data-[state=checked]:border-ivory data-[state=checked]:bg-ivory data-[state=checked]:text-ink" : void 0
				}), /* @__PURE__ */ jsx("label", {
					htmlFor: `${id}-consent`,
					className: dark ? "text-sm text-ivory/75" : "text-sm text-stone",
					children: "I agree to receive occasional emails from Aloe & Soul. I can unsubscribe at any time."
				})]
			}),
			(form.errors.email || form.errors.consent || form.errors.website) && /* @__PURE__ */ jsx("p", {
				id: `${id}-error`,
				role: "alert",
				className: dark ? "mt-2 text-sm text-[#F2B8AC]" : "mt-2 text-sm text-clay",
				children: form.errors.email ?? form.errors.consent ?? form.errors.website
			})
		]
	});
}
//#endregion
//#region resources/js/components/store/site-footer.tsx
var SOCIAL_LABELS = {
	instagram: "Instagram",
	facebook: "Facebook",
	tiktok: "TikTok",
	youtube: "YouTube"
};
function SiteFooter() {
	const { store, contact, social = {}, navigation = [], newsletter_enabled } = useShared();
	const year = (/* @__PURE__ */ new Date()).getFullYear();
	const linkClass = "text-ivory/80 hover:text-ivory hover:underline hover:underline-offset-4";
	return /* @__PURE__ */ jsxs("footer", {
		className: "mt-24 bg-ink text-ivory lg:mt-32",
		children: [/* @__PURE__ */ jsxs("div", {
			className: "container-page grid gap-12 pt-16 pb-10 lg:grid-cols-12 lg:gap-8 lg:pt-20",
			children: [
				/* @__PURE__ */ jsxs("div", {
					className: "lg:col-span-5",
					children: [/* @__PURE__ */ jsx("p", {
						className: "font-display text-3xl leading-tight sm:text-4xl",
						children: store.tagline
					}), newsletter_enabled && /* @__PURE__ */ jsxs("div", {
						className: "mt-8",
						children: [/* @__PURE__ */ jsx("p", {
							className: "mb-3 text-ivory/80",
							children: "News about new products and the occasional story, by email."
						}), /* @__PURE__ */ jsx(NewsletterForm, { tone: "dark" })]
					})]
				}),
				/* @__PURE__ */ jsxs("nav", {
					"aria-label": "Shop",
					className: "lg:col-span-2 lg:col-start-7",
					children: [/* @__PURE__ */ jsx("h2", {
						className: "text-sm text-dune",
						children: "Shop"
					}), /* @__PURE__ */ jsxs("ul", {
						className: "mt-4 space-y-2.5",
						children: [navigation.map((c) => /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsx(Link, {
							href: `/shop/${c.slug}`,
							className: linkClass,
							children: c.name
						}) }, c.slug)), /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsx(Link, {
							href: "/shop",
							className: linkClass,
							children: "All products"
						}) })]
					})]
				}),
				/* @__PURE__ */ jsxs("nav", {
					"aria-label": "Help",
					className: "lg:col-span-2",
					children: [/* @__PURE__ */ jsx("h2", {
						className: "text-sm text-dune",
						children: "Help"
					}), /* @__PURE__ */ jsxs("ul", {
						className: "mt-4 space-y-2.5",
						children: [
							/* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsx(Link, {
								href: "/track-order",
								className: linkClass,
								children: "Track an order"
							}) }),
							/* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsx(Link, {
								href: "/faq",
								className: linkClass,
								children: "FAQ"
							}) }),
							/* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsx(Link, {
								href: "/shipping-returns",
								className: linkClass,
								children: "Shipping and returns"
							}) }),
							/* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsx(Link, {
								href: "/contact",
								className: linkClass,
								children: "Contact"
							}) })
						]
					})]
				}),
				/* @__PURE__ */ jsxs("div", {
					className: "lg:col-span-2",
					children: [/* @__PURE__ */ jsx("h2", {
						className: "text-sm text-dune",
						children: "Aloe & Soul"
					}), /* @__PURE__ */ jsxs("ul", {
						className: "mt-4 space-y-2.5",
						children: [
							/* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsx(Link, {
								href: "/our-story",
								className: linkClass,
								children: "Our story"
							}) }),
							contact?.email && /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsx("a", {
								href: `mailto:${contact.email}`,
								className: linkClass,
								children: contact.email
							}) }),
							contact?.phone_display && /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsx("a", {
								href: `tel:${contact.phone}`,
								className: linkClass,
								children: contact.phone_display
							}) }),
							contact?.whatsapp && /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsx("a", {
								href: `https://wa.me/${contact.whatsapp}`,
								target: "_blank",
								rel: "noopener noreferrer",
								className: linkClass,
								children: "WhatsApp"
							}) }),
							Object.entries(social).map(([network, href]) => /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsx("a", {
								href,
								target: "_blank",
								rel: "noopener noreferrer",
								className: linkClass,
								children: SOCIAL_LABELS[network] ?? network
							}) }, network))
						]
					})]
				})
			]
		}), /* @__PURE__ */ jsxs("div", {
			className: "container-page flex flex-col gap-4 border-t border-ivory/15 py-6 text-sm text-ivory/65 lg:flex-row lg:items-center lg:justify-between",
			children: [/* @__PURE__ */ jsxs("p", { children: [
				"© ",
				year,
				" ",
				store.name,
				contact?.locations?.length ? `. ${contact.locations.join(", ")}.` : ".",
				" Payment in cash on delivery."
			] }), /* @__PURE__ */ jsxs("ul", {
				className: "flex flex-wrap gap-x-5 gap-y-2",
				children: [
					/* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsx(Link, {
						href: "/privacy-policy",
						className: "hover:text-ivory",
						children: "Privacy"
					}) }),
					/* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsx(Link, {
						href: "/terms",
						className: "hover:text-ivory",
						children: "Terms of sale"
					}) }),
					/* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsx(Link, {
						href: "/legal-notice",
						className: "hover:text-ivory",
						children: "Legal notice"
					}) })
				]
			})]
		})]
	});
}
//#endregion
//#region resources/js/components/ui/dialog.tsx
var overlay = "fixed inset-0 z-50 bg-ink/35 data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:animate-in data-[state=open]:fade-in-0";
var panel = "fixed top-1/2 left-1/2 z-50 w-[calc(100%-2rem)] max-w-lg -translate-x-1/2 -translate-y-1/2 rounded-lg bg-white p-6 shadow-overlay outline-none data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=closed]:zoom-out-95 data-[state=open]:animate-in data-[state=open]:fade-in-0 data-[state=open]:zoom-in-95";
var Dialog$1 = Dialog.Root;
Dialog.Trigger;
Dialog.Close;
function DialogContent({ title, description, className, children, ...props }) {
	return /* @__PURE__ */ jsxs(Dialog.Portal, { children: [/* @__PURE__ */ jsx(Dialog.Overlay, { className: overlay }), /* @__PURE__ */ jsxs(Dialog.Content, {
		className: cn(panel, "max-h-[90dvh] overflow-y-auto", className),
		...props,
		children: [/* @__PURE__ */ jsxs("div", {
			className: "mb-4 flex items-start justify-between gap-4",
			children: [/* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx(Dialog.Title, {
				className: "font-display text-2xl leading-tight",
				children: title
			}), /* @__PURE__ */ jsx(Dialog.Description, {
				className: cn("mt-1 text-sm text-stone", !description && "sr-only"),
				children: description ?? title
			})] }), /* @__PURE__ */ jsxs(Dialog.Close, {
				className: "-mt-1 -mr-2 inline-flex size-9 items-center justify-center rounded-full hover:bg-sand",
				children: [/* @__PURE__ */ jsx(X, {
					className: "size-4",
					"aria-hidden": "true"
				}), /* @__PURE__ */ jsx("span", {
					className: "sr-only",
					children: "Close"
				})]
			})]
		}), children]
	})] });
}
/** Confirmation before destructive or irreversible admin actions. */
function ConfirmDialog({ trigger, title, description, confirmLabel, destructive = true, onConfirm, processing }) {
	return /* @__PURE__ */ jsxs(AlertDialog.Root, { children: [/* @__PURE__ */ jsx(AlertDialog.Trigger, {
		asChild: true,
		children: trigger
	}), /* @__PURE__ */ jsxs(AlertDialog.Portal, { children: [/* @__PURE__ */ jsx(AlertDialog.Overlay, { className: overlay }), /* @__PURE__ */ jsxs(AlertDialog.Content, {
		className: panel,
		children: [
			/* @__PURE__ */ jsx(AlertDialog.Title, {
				className: "font-display text-2xl leading-tight",
				children: title
			}),
			/* @__PURE__ */ jsx(AlertDialog.Description, {
				asChild: true,
				children: /* @__PURE__ */ jsx("div", {
					className: "mt-2 text-[0.95rem] text-stone",
					children: description
				})
			}),
			/* @__PURE__ */ jsxs("div", {
				className: "mt-6 flex flex-col-reverse gap-2 sm:flex-row sm:justify-end",
				children: [/* @__PURE__ */ jsx(AlertDialog.Cancel, {
					asChild: true,
					children: /* @__PURE__ */ jsx(Button, {
						variant: "ghost",
						children: "Keep it"
					})
				}), /* @__PURE__ */ jsx(AlertDialog.Action, {
					asChild: true,
					children: /* @__PURE__ */ jsx(Button, {
						variant: destructive ? "destructive" : "primary",
						loading: processing,
						onClick: onConfirm,
						children: confirmLabel
					})
				})]
			})
		]
	})] })] });
}
//#endregion
//#region resources/js/components/ui/input.tsx
var controlClasses = "w-full rounded-(--radius-control) border border-line bg-white px-3.5 text-[0.95rem] text-ink transition-colors duration-150 placeholder:text-stone/70 hover:border-stone/50 focus-visible:border-aloe focus-visible:outline-2 focus-visible:outline-offset-1 focus-visible:outline-aloe disabled:cursor-not-allowed disabled:bg-panel disabled:text-stone aria-invalid:border-clay aria-invalid:focus-visible:outline-clay";
function Input({ className, type = "text", ...props }) {
	return /* @__PURE__ */ jsx("input", {
		type,
		"data-slot": "input",
		className: cn(controlClasses, "h-11", className),
		...props
	});
}
function Textarea({ className, ...props }) {
	return /* @__PURE__ */ jsx("textarea", {
		"data-slot": "textarea",
		className: cn(controlClasses, "min-h-24 py-2.5 leading-relaxed", className),
		...props
	});
}
/** Native select: the most reliable control on mobile and with screen readers. */
function Select({ className, children, ...props }) {
	return /* @__PURE__ */ jsxs("div", {
		className: "relative",
		children: [/* @__PURE__ */ jsx("select", {
			"data-slot": "select",
			className: cn(controlClasses, "h-11 appearance-none pr-10", className),
			...props,
			children
		}), /* @__PURE__ */ jsx("svg", {
			className: "pointer-events-none absolute top-1/2 right-3.5 size-4 -translate-y-1/2 text-stone",
			viewBox: "0 0 16 16",
			fill: "none",
			"aria-hidden": "true",
			children: /* @__PURE__ */ jsx("path", {
				d: "m4 6 4 4 4-4",
				stroke: "currentColor",
				strokeWidth: "1.5",
				strokeLinecap: "round"
			})
		})]
	});
}
function Label({ className, ...props }) {
	return /* @__PURE__ */ jsx("label", {
		"data-slot": "label",
		className: cn("text-sm font-medium text-ink", className),
		...props
	});
}
//#endregion
//#region resources/js/components/store/site-header.tsx
var LINKS = [
	{
		href: "/our-story",
		label: "Our story"
	},
	{
		href: "/faq",
		label: "FAQ"
	},
	{
		href: "/contact",
		label: "Contact"
	}
];
function SiteHeader() {
	const { navigation = [], cart, contact } = useShared();
	const { url } = usePage();
	const cartUi = useCartUi();
	const [mobileOpen, setMobileOpen] = useState(false);
	const [searchOpen, setSearchOpen] = useState(false);
	const count = cart?.count ?? 0;
	const [pulse, setPulse] = useState(false);
	const previous = useRef(count);
	useEffect(() => {
		if (count > previous.current) {
			setPulse(true);
			const t = setTimeout(() => setPulse(false), 500);
			previous.current = count;
			return () => clearTimeout(t);
		}
		previous.current = count;
	}, [count]);
	const isActive = (href) => url === href || url.startsWith(`${href}/`) || url.startsWith(`${href}?`);
	return /* @__PURE__ */ jsxs("header", {
		className: "sticky top-0 z-40 border-b border-line/70 bg-ivory/95 backdrop-blur supports-[backdrop-filter]:bg-ivory/85",
		children: [
			/* @__PURE__ */ jsxs("div", {
				className: "container-page flex h-[4.5rem] items-center gap-4",
				children: [
					/* @__PURE__ */ jsx("button", {
						type: "button",
						className: "-ml-2 inline-flex size-11 items-center justify-center rounded-full hover:bg-sand lg:hidden",
						onClick: () => setMobileOpen(true),
						"aria-label": "Open menu",
						children: /* @__PURE__ */ jsx(Menu, {
							className: "size-5",
							"aria-hidden": "true"
						})
					}),
					/* @__PURE__ */ jsx(Logo, { className: "mr-auto lg:mr-0" }),
					/* @__PURE__ */ jsx(NavigationMenu.Root, {
						className: "relative ml-10 hidden flex-1 lg:block",
						"aria-label": "Main",
						children: /* @__PURE__ */ jsxs(NavigationMenu.List, {
							className: "flex items-center gap-1",
							children: [/* @__PURE__ */ jsxs(NavigationMenu.Item, { children: [/* @__PURE__ */ jsxs(NavigationMenu.Trigger, {
								className: cn("group inline-flex h-10 items-center gap-1 rounded-full px-4 text-[0.95rem] hover:bg-sand data-[state=open]:bg-sand", isActive("/shop") && "text-aloe"),
								children: ["Shop", /* @__PURE__ */ jsx(ChevronDown, {
									className: "size-4 transition-transform group-data-[state=open]:rotate-180",
									"aria-hidden": "true"
								})]
							}), /* @__PURE__ */ jsxs(NavigationMenu.Content, {
								className: "absolute top-full left-0 mt-3 w-[min(46rem,80vw)] rounded-lg border border-line bg-ivory p-3 shadow-overlay data-[motion^=from-]:animate-in data-[motion^=from-]:fade-in data-[motion^=to-]:animate-out data-[motion^=to-]:fade-out",
								children: [/* @__PURE__ */ jsx("ul", {
									className: "grid grid-cols-2 gap-1",
									children: navigation.map((category) => /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsx(NavigationMenu.Link, {
										asChild: true,
										children: /* @__PURE__ */ jsxs(Link, {
											href: `/shop/${category.slug}`,
											className: "flex items-start gap-4 rounded-md p-3 transition-colors hover:bg-sand focus-visible:bg-sand",
											children: [/* @__PURE__ */ jsx("span", {
												className: "flex size-14 shrink-0 items-center justify-center rounded-full p-2.5 text-dune",
												style: { backgroundColor: category.tint },
												children: /* @__PURE__ */ jsx(Motif, { name: category.motif })
											}), /* @__PURE__ */ jsxs("span", { children: [/* @__PURE__ */ jsx("span", {
												className: "block font-medium",
												children: category.name
											}), category.tagline && /* @__PURE__ */ jsx("span", {
												className: "mt-0.5 block text-sm text-stone",
												children: category.tagline
											})] })]
										})
									}) }, category.slug))
								}), /* @__PURE__ */ jsx("div", {
									className: "mt-2 border-t border-line px-3 pt-3 pb-1",
									children: /* @__PURE__ */ jsx(NavigationMenu.Link, {
										asChild: true,
										children: /* @__PURE__ */ jsx(Link, {
											href: "/shop",
											className: "text-sm font-medium underline underline-offset-4 hover:text-aloe",
											children: "See all products"
										})
									})
								})]
							})] }), LINKS.map((link) => /* @__PURE__ */ jsx(NavigationMenu.Item, { children: /* @__PURE__ */ jsx(NavigationMenu.Link, {
								asChild: true,
								active: isActive(link.href),
								children: /* @__PURE__ */ jsx(Link, {
									href: link.href,
									className: cn("inline-flex h-10 items-center rounded-full px-4 text-[0.95rem] hover:bg-sand", isActive(link.href) && "text-aloe"),
									"aria-current": isActive(link.href) ? "page" : void 0,
									children: link.label
								})
							}) }, link.href))]
						})
					}),
					/* @__PURE__ */ jsxs("div", {
						className: "flex items-center gap-1",
						children: [/* @__PURE__ */ jsx("button", {
							type: "button",
							onClick: () => setSearchOpen(true),
							className: "inline-flex size-11 items-center justify-center rounded-full hover:bg-sand",
							"aria-label": "Search products",
							children: /* @__PURE__ */ jsx(Search, {
								className: "size-5",
								"aria-hidden": "true"
							})
						}), /* @__PURE__ */ jsxs("button", {
							type: "button",
							onClick: cartUi.open,
							className: "relative -mr-2 inline-flex size-11 items-center justify-center rounded-full hover:bg-sand",
							"aria-label": `Open cart, ${count} ${count === 1 ? "item" : "items"}`,
							children: [/* @__PURE__ */ jsx(ShoppingBag, {
								className: "size-5",
								"aria-hidden": "true"
							}), count > 0 && /* @__PURE__ */ jsx("span", {
								className: cn("absolute top-1 right-0.5 flex h-5 min-w-5 items-center justify-center rounded-full bg-ink px-1 text-[0.7rem] font-semibold text-ivory tabular-nums", pulse && "motion-safe:animate-count-pulse"),
								"aria-hidden": "true",
								children: count
							})]
						})]
					})
				]
			}),
			/* @__PURE__ */ jsx(SearchDialog, {
				open: searchOpen,
				onOpenChange: setSearchOpen
			}),
			/* @__PURE__ */ jsx(Sheet, {
				open: mobileOpen,
				onOpenChange: setMobileOpen,
				children: /* @__PURE__ */ jsxs(SheetContent, {
					side: "left",
					title: "Menu",
					children: [/* @__PURE__ */ jsxs("nav", {
						"aria-label": "Main",
						className: "flex-1 overflow-y-auto px-5 py-4",
						children: [
							/* @__PURE__ */ jsx("p", {
								className: "text-sm text-stone",
								children: "Shop"
							}),
							/* @__PURE__ */ jsxs("ul", {
								className: "mt-2 border-b border-line pb-4",
								children: [navigation.map((c) => /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsxs(Link, {
									href: `/shop/${c.slug}`,
									onClick: () => setMobileOpen(false),
									className: "flex items-center gap-3 py-2.5 text-lg",
									children: [/* @__PURE__ */ jsx("span", {
										className: "size-3 rounded-full",
										style: { backgroundColor: c.tint },
										"aria-hidden": "true"
									}), c.name]
								}) }, c.slug)), /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsx(Link, {
									href: "/shop",
									onClick: () => setMobileOpen(false),
									className: "block py-2.5 text-lg underline underline-offset-4",
									children: "All products"
								}) })]
							}),
							/* @__PURE__ */ jsx("ul", {
								className: "mt-4 space-y-1",
								children: [...LINKS, {
									href: "/track-order",
									label: "Track an order"
								}].map((l) => /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsx(Link, {
									href: l.href,
									onClick: () => setMobileOpen(false),
									className: "block py-2 font-display text-2xl",
									children: l.label
								}) }, l.href))
							})
						]
					}), contact?.whatsapp && /* @__PURE__ */ jsx("div", {
						className: "border-t border-line p-5",
						children: /* @__PURE__ */ jsx(Button, {
							asChild: true,
							variant: "secondary",
							className: "w-full",
							children: /* @__PURE__ */ jsx("a", {
								href: `https://wa.me/${contact.whatsapp}`,
								target: "_blank",
								rel: "noopener noreferrer",
								children: "Message us on WhatsApp"
							})
						})
					})]
				})
			})
		]
	});
}
function SearchDialog({ open, onOpenChange }) {
	const [q, setQ] = useState("");
	const submit = (e) => {
		e.preventDefault();
		const term = q.trim();
		onOpenChange(false);
		router.get("/shop", term ? { q: term } : {});
	};
	return /* @__PURE__ */ jsx(Dialog$1, {
		open,
		onOpenChange,
		children: /* @__PURE__ */ jsx(DialogContent, {
			title: "Search",
			description: "Find a product by name.",
			className: "top-24 translate-y-0 sm:top-32",
			children: /* @__PURE__ */ jsxs("form", {
				onSubmit: submit,
				role: "search",
				className: "flex gap-2",
				children: [
					/* @__PURE__ */ jsx("label", {
						htmlFor: "site-search",
						className: "sr-only",
						children: "Search products"
					}),
					/* @__PURE__ */ jsx(Input, {
						id: "site-search",
						type: "search",
						value: q,
						onChange: (e) => setQ(e.target.value),
						placeholder: "Aloe vera gel, shampoo…",
						maxLength: 100,
						autoFocus: true
					}),
					/* @__PURE__ */ jsx(Button, {
						type: "submit",
						children: "Search"
					})
				]
			})
		})
	});
}
//#endregion
//#region resources/js/layouts/store-layout.tsx
/** Persistent storefront layout: header, footer, cart drawer survive navigations. */
function StoreLayout({ children }) {
	const { announcement, seo } = useShared();
	return /* @__PURE__ */ jsxs(CartUiProvider, { children: [
		seo && /* @__PURE__ */ jsxs(Head, { children: [
			/* @__PURE__ */ jsx("title", { children: seo.title }),
			/* @__PURE__ */ jsx("meta", {
				"head-key": "description",
				name: "description",
				content: seo.description
			}),
			/* @__PURE__ */ jsx("meta", {
				"head-key": "robots",
				name: "robots",
				content: seo.robots
			}),
			seo.canonical && /* @__PURE__ */ jsx("link", {
				"head-key": "canonical",
				rel: "canonical",
				href: seo.canonical
			})
		] }),
		/* @__PURE__ */ jsx("a", {
			href: "#main",
			className: "sr-only z-50 rounded-full bg-ink px-4 py-2 text-ivory focus:not-sr-only focus:fixed focus:top-3 focus:left-3",
			children: "Skip to content"
		}),
		announcement && /* @__PURE__ */ jsx("div", {
			className: "bg-aloe text-ivory",
			children: /* @__PURE__ */ jsxs("p", {
				className: "container-page py-2.5 text-center text-sm",
				children: [announcement.text, announcement.link_url && announcement.link_label && /* @__PURE__ */ jsxs(Fragment, { children: [" ", announcement.link_url.startsWith("/") ? /* @__PURE__ */ jsx(Link, {
					href: announcement.link_url,
					className: "underline underline-offset-4 hover:text-white",
					children: announcement.link_label
				}) : /* @__PURE__ */ jsx("a", {
					href: announcement.link_url,
					rel: "noopener noreferrer",
					className: "underline underline-offset-4 hover:text-white",
					children: announcement.link_label
				})] })]
			})
		}),
		/* @__PURE__ */ jsx(SiteHeader, {}),
		/* @__PURE__ */ jsx("main", {
			id: "main",
			tabIndex: -1,
			className: "outline-none",
			children
		}),
		/* @__PURE__ */ jsx(SiteFooter, {}),
		/* @__PURE__ */ jsx(CartDrawer, {}),
		/* @__PURE__ */ jsx(FlashToaster, {})
	] });
}
//#endregion
//#region resources/js/pages-registry.tsx
var pages = /* #__PURE__ */ Object.assign({
	"./pages/admin/audit-log.tsx": () => import("./assets/audit-log-BkTHSVmt.js"),
	"./pages/admin/auth/confirm-password.tsx": () => import("./assets/confirm-password-BEgdJzcw.js"),
	"./pages/admin/auth/forgot-password.tsx": () => import("./assets/forgot-password-CI3UOYkf.js"),
	"./pages/admin/auth/login.tsx": () => import("./assets/login-Ba8YCuYP.js"),
	"./pages/admin/auth/reset-password.tsx": () => import("./assets/reset-password-0U_qLagB.js"),
	"./pages/admin/auth/two-factor-challenge.tsx": () => import("./assets/two-factor-challenge-NoEsm3nz.js"),
	"./pages/admin/categories/index.tsx": () => import("./assets/categories-BpYYm0GF.js"),
	"./pages/admin/content/home.tsx": () => import("./assets/home-SxVGSNbj.js"),
	"./pages/admin/content/story.tsx": () => import("./assets/story-DooFilrc.js"),
	"./pages/admin/coupons/index.tsx": () => import("./assets/coupons-0val7c2I.js"),
	"./pages/admin/customers/index.tsx": () => import("./assets/customers-dKvozne5.js"),
	"./pages/admin/customers/show.tsx": () => import("./assets/show-Bh0g_tGW.js"),
	"./pages/admin/dashboard.tsx": () => import("./assets/dashboard-DNnLCAEB.js"),
	"./pages/admin/faqs/index.tsx": () => import("./assets/faqs-DD8yZW01.js"),
	"./pages/admin/inventory/history.tsx": () => import("./assets/history-5qoBmpEu.js"),
	"./pages/admin/inventory/index.tsx": () => import("./assets/inventory-CFyj1eYU.js"),
	"./pages/admin/messages/index.tsx": () => import("./assets/messages-gw6DUTJA.js"),
	"./pages/admin/messages/subscribers.tsx": () => import("./assets/subscribers-BDeRiccH.js"),
	"./pages/admin/orders/index.tsx": () => import("./assets/orders-C9kL_Rp3.js"),
	"./pages/admin/orders/show.tsx": () => import("./assets/show-DXTCdGI_.js"),
	"./pages/admin/pages/edit.tsx": () => import("./assets/edit-DV95_iqP.js"),
	"./pages/admin/pages/index.tsx": () => import("./assets/pages-DMhHR7Ph.js"),
	"./pages/admin/products/form.tsx": () => import("./assets/form-CVuEM9bB.js"),
	"./pages/admin/products/index.tsx": () => import("./assets/products-A3zdF5Au.js"),
	"./pages/admin/profile.tsx": () => import("./assets/profile-CfT5Tepz.js"),
	"./pages/admin/settings.tsx": () => import("./assets/settings-wPGAxg3n.js"),
	"./pages/admin/users/index.tsx": () => import("./assets/users-DCY0tHMC.js"),
	"./pages/admin/zones/index.tsx": () => import("./assets/zones-DU9reFWW.js"),
	"./pages/cart.tsx": () => import("./assets/cart-Djh9FOLN.js"),
	"./pages/checkout/confirmation.tsx": () => import("./assets/confirmation-By4mBWr8.js"),
	"./pages/checkout/index.tsx": () => import("./assets/checkout-BblPRNYE.js"),
	"./pages/contact.tsx": () => import("./assets/contact-Dy3Ae7Tz.js"),
	"./pages/error.tsx": () => import("./assets/error-jmLY_Pau.js"),
	"./pages/faq.tsx": () => import("./assets/faq-a-eX4YPd.js"),
	"./pages/home.tsx": () => import("./assets/home-Cyg66emR.js"),
	"./pages/page.tsx": () => import("./assets/page-G9E7tjUO.js"),
	"./pages/product/show.tsx": () => import("./assets/show-Br0I9eBk.js"),
	"./pages/product/unavailable.tsx": () => import("./assets/unavailable-CMTOw-Yx.js"),
	"./pages/shop/index.tsx": () => import("./assets/shop-Diu5Ystw.js"),
	"./pages/story.tsx": () => import("./assets/story-BqJ5JDSg.js"),
	"./pages/track-order.tsx": () => import("./assets/track-order-C2MikRTW.js")
});
var LazyAdminLayout = lazy(() => import("./assets/admin-layout-C8jbH1_X.js"));
function AdminShell({ children }) {
	return /* @__PURE__ */ jsx(Suspense, {
		fallback: null,
		children: /* @__PURE__ */ jsx(LazyAdminLayout, { children })
	});
}
async function resolvePage(name) {
	const loader = pages[`./pages/${name}.tsx`];
	if (!loader) throw new Error(`Page not found: ${name}`);
	return (await loader()).default;
}
/** Admin pages get the admin shell, sign-in pages a minimal one, everything else the storefront. */
function resolveLayout(name, page) {
	if (name.startsWith("admin/auth/")) return AuthLayout;
	if (name.startsWith("admin/")) return AdminShell;
	if (name === "error" && page?.url.startsWith("/admin")) return AuthLayout;
	return StoreLayout;
}
//#endregion
//#region resources/js/ssr.tsx
/**
* Optional server-side rendering entry. Only used when the host can run a
* persistent Node process (INERTIA_SSR_ENABLED=true + `php artisan inertia:start-ssr`).
* SEO-critical meta tags are rendered by Blade either way.
*/
createServer((page) => createInertiaApp({
	page,
	render: ReactDOMServer.renderToString,
	resolve: resolvePage,
	layout: resolveLayout,
	setup: ({ App, props }) => /* @__PURE__ */ jsx(App, { ...props })
}));
//#endregion
export { SheetContent as _, ConfirmDialog as a, useCartUi as b, Checkbox$1 as c, ProductPlaceholder as d, Motif as f, Sheet as g, Price as h, Textarea as i, Switch$1 as l, QuantityStepper as m, Label as n, Dialog$1 as o, ResponsiveImage as p, Select as r, DialogContent as s, Input as t, CartLines as u, Button as v, FlashToaster as x, Spinner as y };
